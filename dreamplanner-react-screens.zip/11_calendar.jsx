import { useState, useEffect, useRef, useCallback } from "react";
import {
  ArrowLeft, ChevronLeft, ChevronRight, Plus, Clock,
  Target, CheckCircle, Circle, X, Check, Calendar,
  Zap, MoreVertical, Edit3, Trash2
} from "lucide-react";

/* ═══════════════════════════════════════════════════════════════════
 * DreamPlanner — Calendar Screen v1
 * Custom month grid, event dots, tasks per day, add event modal
 * ═══════════════════════════════════════════════════════════════════ */

const NOW=new Date();const TODAY={y:NOW.getFullYear(),m:NOW.getMonth(),d:NOW.getDate()};
const DAYS=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];

const EVENTS = {
  [`${TODAY.y}-${TODAY.m}-${TODAY.d}`]:[
    {id:"e1",title:"Morning Run (8km)",time:"6:30 AM",color:"#5DE5A8",type:"task",done:false,dream:"Half Marathon"},
    {id:"e2",title:"AI Coach Check-in",time:"12:00 PM",color:"#C4B5FD",type:"event",dream:"Half Marathon"},
    {id:"e3",title:"Piano Practice",time:"7:00 PM",color:"#FCD34D",type:"task",done:false,dream:"Learn Piano"},
  ],
  [`${TODAY.y}-${TODAY.m}-${TODAY.d-1}`]:[
    {id:"e4",title:"Complete Coursera Module",time:"10:00 AM",color:"#C4B5FD",type:"task",done:true,dream:"Launch SaaS"},
    {id:"e5",title:"Stretching Routine",time:"6:00 PM",color:"#5DE5A8",type:"task",done:true,dream:"Half Marathon"},
  ],
  [`${TODAY.y}-${TODAY.m}-${TODAY.d+1}`]:[
    {id:"e6",title:"Long Run (10km)",time:"7:00 AM",color:"#5DE5A8",type:"task",done:false,dream:"Half Marathon"},
    {id:"e7",title:"Budget Review",time:"3:00 PM",color:"#5EEAD4",type:"event",dream:"Save $15K"},
  ],
  [`${TODAY.y}-${TODAY.m}-${TODAY.d+3}`]:[
    {id:"e8",title:"Buddy Chat with Alex",time:"5:00 PM",color:"#14B8A6",type:"event",dream:"Half Marathon"},
  ],
  [`${TODAY.y}-${TODAY.m}-${TODAY.d+5}`]:[
    {id:"e9",title:"Race Day Registration Deadline",time:"All Day",color:"#F69A9A",type:"event",dream:"Half Marathon"},
  ],
  [`${TODAY.y}-${TODAY.m}-${TODAY.d-3}`]:[
    {id:"e10",title:"5km Easy Run",time:"6:30 AM",color:"#5DE5A8",type:"task",done:true,dream:"Half Marathon"},
  ],
};

function getKey(y,m,d){return `${y}-${m}-${d}`;}
function getDaysInMonth(y,m){return new Date(y,m+1,0).getDate();}
function getFirstDow(y,m){const d=new Date(y,m,1).getDay();return d===0?6:d-1;}

// ─── COSMIC BG ───
const STAR_LAYERS=[{count:300,sizeRange:[0.3,1.0],opacity:0.35,parallax:0.008},{count:200,sizeRange:[0.8,1.8],opacity:0.55,parallax:0.02},{count:100,sizeRange:[1.2,2.8],opacity:0.85,parallax:0.045}];
const STAR_COLORS=[[230,225,255],[200,210,255],[255,220,200],[180,200,255],[255,200,220],[220,240,255],[255,240,230]];
const SMOKE_CYCLE=[[255,120,160],[255,80,180],[220,60,220],[180,70,255],[130,80,255],[80,100,255],[60,140,255],[80,180,240],[100,200,220],[160,120,255],[220,100,200],[255,120,160]];
const SMOKE_CONFIGS=[{size:350,opacity:0.09,speedMult:1.0,colorSpeed:0.015,colorOffset:0,pfx:[0.13,0.31],pfy:[0.17,0.23],pax:[0.38,0.12],pay:[0.35,0.10]},{size:300,opacity:0.07,speedMult:1.3,colorSpeed:0.02,colorOffset:3,pfx:[0.19,0.41],pfy:[0.23,0.29],pax:[0.35,0.15],pay:[0.32,0.08]},{size:250,opacity:0.06,speedMult:1.7,colorSpeed:0.025,colorOffset:6,pfx:[0.29,0.53],pfy:[0.31,0.37],pax:[0.33,0.18],pay:[0.30,0.12]},{size:420,opacity:0.05,speedMult:0.6,colorSpeed:0.01,colorOffset:9,pfx:[0.07,0.19],pfy:[0.11,0.17],pax:[0.40,0.10],pay:[0.38,0.14]},{size:280,opacity:0.065,speedMult:1.1,colorSpeed:0.018,colorOffset:4.5,pfx:[0.17,0.37],pfy:[0.21,0.43],pax:[0.36,0.14],pay:[0.33,0.11]}];
const NEBULAE=[{x:"8%",y:"15%",c1:"rgba(80,120,255,0.06)",c2:"rgba(60,80,200,0.015)",s:500,b:90,sp:35},{x:"88%",y:"20%",c1:"rgba(100,140,255,0.05)",c2:"rgba(70,100,220,0.015)",s:450,b:85,sp:28},{x:"12%",y:"75%",c1:"rgba(140,80,220,0.06)",c2:"rgba(100,50,180,0.015)",s:430,b:80,sp:32},{x:"82%",y:"78%",c1:"rgba(120,70,200,0.05)",c2:"rgba(90,40,170,0.015)",s:410,b:85,sp:26},{x:"50%",y:"92%",c1:"rgba(60,100,200,0.04)",c2:"rgba(40,70,160,0.01)",s:550,b:100,sp:40},{x:"50%",y:"5%",c1:"rgba(90,60,180,0.04)",c2:"rgba(70,40,150,0.01)",s:500,b:90,sp:22}];
function lerp(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}function smokeCol(t){const l=SMOKE_CYCLE.length,i=t%l,f=Math.floor(i);return lerp(SMOKE_CYCLE[f%l],SMOKE_CYCLE[(f+1)%l],i-f);}function mkStars(layer,w,h){const s=[];for(let i=0;i<layer.count;i++)s.push({x:Math.random()*w,y:Math.random()*h,sz:layer.sizeRange[0]+Math.random()*(layer.sizeRange[1]-layer.sizeRange[0]),op:layer.opacity*(0.4+Math.random()*0.6),ts:0.3+Math.random()*2.5,to:Math.random()*Math.PI*2,c:STAR_COLORS[Math.floor(Math.random()*STAR_COLORS.length)]});return s;}function mkShoot(w,h){const e=Math.floor(Math.random()*3);let x,y,a;if(e===0){x=Math.random()*w;y=-20;a=Math.PI*0.3+Math.random()*Math.PI*0.4;}else if(e===1){x=-20;y=Math.random()*h*0.6;a=Math.PI*0.05+Math.random()*Math.PI*0.3;}else{x=w*0.5+Math.random()*w*0.5;y=-20;a=Math.PI*0.4+Math.random()*Math.PI*0.3;}const sp=5+Math.random()*8;return{x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,ln:80+Math.random()*140,life:1,dc:0.005+Math.random()*0.01,sz:0.8+Math.random()*1.8,w:Math.random()};}

export default function CalendarScreen(){
  const[mounted,setMounted]=useState(false);
  const[viewY,setViewY]=useState(TODAY.y);
  const[viewM,setViewM]=useState(TODAY.m);
  const[selDay,setSelDay]=useState(null);
  const[events,setEvents]=useState(EVENTS);
  const[addEvt,setAddEvt]=useState(false);
  const[newTitle,setNewTitle]=useState("");
  const[newTime,setNewTime]=useState("9:00 AM");
  const[confirmDel,setConfirmDel]=useState(null);
  const scRef=useRef(null);const mkRef=useRef(null);
  const stRef=useRef([]);const shRef=useRef([]);
  const drRef=useRef({x:0,y:0,a:0});const msRef=useRef({x:0,y:0,tx:0,ty:0});
  const tRef=useRef(0);const szRef=useRef({w:0,h:0});const afRef=useRef(null);

  useEffect(()=>{setTimeout(()=>setMounted(true),100);},[]);

  const prevMonth=()=>{if(viewM===0){setViewM(11);setViewY(viewY-1);}else setViewM(viewM-1);setSelDay(1);};
  const nextMonth=()=>{if(viewM===11){setViewM(0);setViewY(viewY+1);}else setViewM(viewM+1);setSelDay(1);};
  const goToday=()=>{setViewY(TODAY.y);setViewM(TODAY.m);setSelDay(null);};
  const toggleTask=(evtKey,evtId)=>{setEvents(p=>{const up={...p};up[evtKey]=up[evtKey].map(e=>e.id===evtId?{...e,done:!e.done}:e);return up;});};
  const deleteEvent=(evtKey,evtId)=>{setEvents(p=>{const up={...p};up[evtKey]=up[evtKey].filter(e=>e.id!==evtId);if(up[evtKey].length===0)delete up[evtKey];return up;});setConfirmDel(null);};
  const handleAddEvt=()=>{if(!newTitle.trim())return;const day=selDay||TODAY.d;const k=getKey(viewY,viewM,day);setEvents(p=>{const up={...p};if(!up[k])up[k]=[];up[k]=[...up[k],{id:`e${Date.now()}`,title:newTitle.trim(),time:newTime,color:"#C4B5FD",type:"event",done:false,dream:""}];return up;});setNewTitle("");setAddEvt(false);};

  const daysInMonth=getDaysInMonth(viewY,viewM);

  const renderEventCard=(evt,evtKey)=>(
    <div className="dp-g" style={{marginBottom:8,overflow:"hidden"}}>
      <div style={{padding:14,display:"flex",alignItems:"center",gap:12}}>
        <div style={{width:4,alignSelf:"stretch",minHeight:40,borderRadius:2,background:evt.color,flexShrink:0,boxShadow:`0 0 8px ${evt.color}30`}}/>
        {evt.type==="task"?(
          <button onClick={()=>toggleTask(evtKey,evt.id)} style={{width:24,height:24,borderRadius:8,border:evt.done?"none":"2px solid rgba(255,255,255,0.15)",background:evt.done?"rgba(93,229,168,0.2)":"transparent",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",flexShrink:0,transition:"all 0.2s"}}>
            {evt.done&&<Check size={13} color="#5DE5A8" strokeWidth={3}/>}
          </button>
        ):(
          <div style={{width:24,height:24,borderRadius:8,background:`${evt.color}15`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <Clock size={12} color={evt.color} strokeWidth={2.5}/>
          </div>
        )}
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:14,fontWeight:500,color:evt.done?"rgba(255,255,255,0.4)":"#fff",textDecoration:evt.done?"line-through":"none",transition:"all 0.2s"}}>{evt.title}</div>
          <div style={{display:"flex",alignItems:"center",gap:8,marginTop:2}}>
            <span style={{fontSize:11,color:"rgba(255,255,255,0.5)"}}>{evt.time}</span>
            {evt.dream&&<span style={{fontSize:10,color:evt.color,fontWeight:500}}>{evt.dream}</span>}
          </div>
        </div>
        <button onClick={()=>setConfirmDel({key:evtKey,id:evt.id,title:evt.title})} style={{width:30,height:30,borderRadius:9,border:"none",background:"rgba(239,68,68,0.06)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",flexShrink:0,transition:"all 0.15s",opacity:0.5}}
          onMouseEnter={e=>{e.currentTarget.style.opacity="1";e.currentTarget.style.background="rgba(239,68,68,0.12)";}}
          onMouseLeave={e=>{e.currentTarget.style.opacity="0.5";e.currentTarget.style.background="rgba(239,68,68,0.06)";}}>
          <Trash2 size={14} color="rgba(239,68,68,0.8)" strokeWidth={2}/>
        </button>
      </div>
    </div>
  );

  const firstDow=getFirstDow(viewY,viewM);
  const isToday=(d)=>d===TODAY.d&&viewM===TODAY.m&&viewY===TODAY.y;
  const isSel=(d)=>selDay!==null&&d===selDay;
  const todayKey=getKey(TODAY.y,TODAY.m,TODAY.d);
  const tomorrowD=new Date(TODAY.y,TODAY.m,TODAY.d+1);
  const tomorrowKey=getKey(tomorrowD.getFullYear(),tomorrowD.getMonth(),tomorrowD.getDate());
  const todayEvents=events[todayKey]||[];
  const tomorrowEvents=events[tomorrowKey]||[];
  const selKey=selDay?getKey(viewY,viewM,selDay):null;
  const selEvents=selKey?(events[selKey]||[]):[];

  // build calendar grid
  const cells=[];
  for(let i=0;i<firstDow;i++)cells.push(null);
  for(let d=1;d<=daysInMonth;d++)cells.push(d);

  // BG
  const init=useCallback((w,h)=>{stRef.current=STAR_LAYERS.map(l=>({c:l,s:mkStars(l,w*1.3,h*1.3)}));},[]);
  useEffect(()=>{const sc=scRef.current,mk=mkRef.current;if(!sc||!mk)return;const sx=sc.getContext("2d"),mx=mk.getContext("2d"),d=window.devicePixelRatio||1;const rs=()=>{const w=window.innerWidth,h=window.innerHeight;[sc,mk].forEach(c=>{c.width=w*d;c.height=h*d;c.style.width=w+"px";c.style.height=h+"px";});sx.setTransform(d,0,0,d,0,0);mx.setTransform(d,0,0,d,0,0);szRef.current={w,h};init(w,h);};rs();window.addEventListener("resize",rs);const mm=e=>{const cx=window.innerWidth/2,cy=window.innerHeight/2;msRef.current.tx=(e.clientX-cx)/cx;msRef.current.ty=(e.clientY-cy)/cy;};window.addEventListener("mousemove",mm);const go=()=>{const{w,h}=szRef.current;tRef.current+=0.016;const t=tRef.current;const dr=drRef.current;dr.a+=0.0008;dr.x=Math.sin(dr.a*0.7)*0.15;dr.y=Math.cos(dr.a*0.5)*0.12;const m=msRef.current;m.x+=(m.tx-m.x)*0.03;m.y+=(m.ty-m.y)*0.03;const mvx=dr.x+m.x*0.4,mvy=dr.y+m.y*0.4;mx.clearRect(0,0,w,h);SMOKE_CONFIGS.forEach(c=>{const st=t*c.speedMult;const px=0.5+c.pax[0]*Math.sin(st*c.pfx[0])+c.pax[1]*Math.sin(st*c.pfx[1]);const py=0.5+c.pay[0]*Math.cos(st*c.pfy[0])+c.pay[1]*Math.cos(st*c.pfy[1]);const x=px*w,y=py*h;const[r,g,b]=smokeCol(c.colorOffset+t*c.colorSpeed);const gr=mx.createRadialGradient(x,y,0,x,y,c.size);gr.addColorStop(0,`rgba(${r|0},${g|0},${b|0},${c.opacity})`);gr.addColorStop(0.6,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.2})`);gr.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=gr;mx.beginPath();mx.arc(x,y,c.size,0,Math.PI*2);mx.fill();});sx.clearRect(0,0,w,h);stRef.current.forEach(({c:cfg,s:stars})=>{const ox=mvx*cfg.parallax*w+(w*0.15),oy=mvy*cfg.parallax*h+(h*0.15),fw=w*1.3,fh=h*1.3;stars.forEach(s=>{const tw=Math.sin(t*s.ts+s.to)*0.35+0.65,a=s.op*tw,px=((s.x-ox)%fw+fw)%fw-w*0.15,py=((s.y-oy)%fh+fh)%fh-h*0.15;if(px<-10||px>w+10||py<-10||py>h+10)return;const[r,g,b]=s.c;sx.fillStyle=`rgba(${r},${g},${b},${a})`;sx.beginPath();sx.arc(px,py,s.sz,0,Math.PI*2);sx.fill();});});if(Math.random()<0.02)shRef.current.push(mkShoot(w,h));shRef.current=shRef.current.filter(s=>{s.x+=s.vx;s.y+=s.vy;s.life-=s.dc;if(s.life<=0)return false;const a=s.life*s.life,mg=Math.sqrt(s.vx*s.vx+s.vy*s.vy),dx=s.vx/mg,dy=s.vy/mg,tx=s.x-dx*s.ln*a,ty=s.y-dy*s.ln*a;const gr=sx.createLinearGradient(tx,ty,s.x,s.y);gr.addColorStop(0,"rgba(200,210,255,0)");gr.addColorStop(1,`rgba(255,255,255,${a*0.9})`);sx.strokeStyle=gr;sx.lineWidth=s.sz;sx.lineCap="round";sx.beginPath();sx.moveTo(tx,ty);sx.lineTo(s.x,s.y);sx.stroke();return true;});afRef.current=requestAnimationFrame(go);};afRef.current=requestAnimationFrame(go);return()=>{cancelAnimationFrame(afRef.current);window.removeEventListener("resize",rs);window.removeEventListener("mousemove",mm);};
  },[init]);

  return(
    <div style={{width:"100%",height:"100vh",overflow:"hidden",fontFamily:"'Inter',-apple-system,BlinkMacSystemFont,sans-serif",display:"flex",flexDirection:"column",position:"relative"}}>
      <div style={{position:"fixed",inset:0,background:"radial-gradient(ellipse at 50% 50%,#0c081a 0%,#070412 35%,#03010a 70%,#000005 100%)",zIndex:0}}>
        {NEBULAE.map((n,i)=><div key={i} className={`dp-n-${i}`} style={{position:"absolute",left:n.x,top:n.y,width:n.s,height:n.s,transform:"translate(-50%,-50%)",background:`radial-gradient(circle,${n.c1} 0%,${n.c2} 40%,transparent 70%)`,filter:`blur(${n.b}px)`,pointerEvents:"none"}}/>)}
        <canvas ref={mkRef} style={{position:"absolute",inset:0,pointerEvents:"none",mixBlendMode:"screen"}}/>
        <canvas ref={scRef} style={{position:"absolute",inset:0,pointerEvents:"none"}}/>
      </div>

      <header style={{position:"relative",zIndex:100,height:64,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",background:"rgba(255,255,255,0.03)",backdropFilter:"blur(40px) saturate(1.4)",WebkitBackdropFilter:"blur(40px) saturate(1.4)",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button className="dp-ib"><ArrowLeft size={20} strokeWidth={2}/></button>
          <Calendar size={18} color="#C4B5FD" strokeWidth={2}/>
          <span style={{fontSize:17,fontWeight:700,color:"#fff"}}>Calendar</span>
        </div>
        <div style={{display:"flex",gap:6}}>
          <button onClick={goToday} style={{padding:"6px 12px",borderRadius:10,border:"1px solid rgba(139,92,246,0.2)",background:"rgba(139,92,246,0.08)",color:"#C4B5FD",fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>Today</button>
          <button className="dp-ib" onClick={()=>{setNewTitle("");setAddEvt(true);}}><Plus size={18} strokeWidth={2}/></button>
        </div>
      </header>

      <main style={{flex:1,overflowY:"auto",overflowX:"hidden",zIndex:10,padding:"16px 16px 32px"}}>
        <div style={{maxWidth:480,margin:"0 auto"}}>

          {/* ── Month Nav ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"0ms"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
              <button onClick={prevMonth} className="dp-ib" style={{width:36,height:36}}><ChevronLeft size={18} strokeWidth={2}/></button>
              <span style={{fontSize:18,fontWeight:700,color:"#fff"}}>{MONTHS[viewM]} {viewY}</span>
              <button onClick={nextMonth} className="dp-ib" style={{width:36,height:36}}><ChevronRight size={18} strokeWidth={2}/></button>
            </div>
          </div>

          {/* ── Calendar Grid ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"80ms"}}>
            <div className="dp-g" style={{padding:12,marginBottom:16}}>
              {/* Day headers */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2,marginBottom:6}}>
                {DAYS.map(d=><div key={d} style={{textAlign:"center",fontSize:11,fontWeight:600,color:"rgba(255,255,255,0.4)",padding:"4px 0"}}>{d}</div>)}
              </div>
              {/* Date cells */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2}}>
                {cells.map((d,i)=>{
                  if(d===null)return <div key={`e${i}`}/>;
                  const k=getKey(viewY,viewM,d);
                  const hasEvt=events[k]&&events[k].length>0;
                  const evtColors=(events[k]||[]).slice(0,3).map(e=>e.color);
                  return(
                    <button key={d} onClick={()=>setSelDay(d)} style={{
                      position:"relative",aspectRatio:"1",borderRadius:12,border:"none",cursor:"pointer",
                      background:isSel(d)?"rgba(139,92,246,0.2)":isToday(d)?"rgba(93,229,168,0.08)":"transparent",
                      outline:isSel(d)?"2px solid rgba(139,92,246,0.4)":isToday(d)?"1px solid rgba(93,229,168,0.15)":"none",
                      display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:2,
                      transition:"all 0.15s",
                    }}
                      onMouseEnter={e=>{if(!isSel(d))e.currentTarget.style.background="rgba(255,255,255,0.04)";}}
                      onMouseLeave={e=>{if(!isSel(d)&&!isToday(d))e.currentTarget.style.background="transparent";else if(isToday(d)&&!isSel(d))e.currentTarget.style.background="rgba(93,229,168,0.08)";}}>
                      <span style={{fontSize:14,fontWeight:isToday(d)||isSel(d)?700:400,color:isSel(d)?"#C4B5FD":isToday(d)?"#5DE5A8":"rgba(255,255,255,0.85)"}}>{d}</span>
                      {hasEvt&&(
                        <div style={{display:"flex",gap:2}}>
                          {evtColors.map((c,j)=><div key={j} style={{width:4,height:4,borderRadius:2,background:c}}/>)}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ── Events Section ── */}
          {selDay===null?(
            /* ── DEFAULT: Today + Tomorrow ── */
            <>
              {[{label:"Today",evts:todayEvents,key:todayKey,dayNum:TODAY.d},{label:"Tomorrow",evts:tomorrowEvents,key:tomorrowKey,dayNum:tomorrowD.getDate()}].map(({label,evts,key,dayNum},si)=>(
                <div key={label}>
                  <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${160+si*120}ms`}}>
                    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8,marginTop:si>0?8:0}}>
                      <div style={{display:"flex",alignItems:"center",gap:6}}>
                        <div style={{width:8,height:8,borderRadius:4,background:label==="Today"?"#5DE5A8":"#C4B5FD"}}/>
                        <span style={{fontSize:15,fontWeight:700,color:"#fff"}}>{label}</span>
                        <span style={{fontSize:12,color:"rgba(255,255,255,0.4)"}}>{new Date(label==="Today"?Date.now():Date.now()+86400000).toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})}</span>
                      </div>
                      <span style={{fontSize:12,color:"rgba(255,255,255,0.5)"}}>{evts.length} item{evts.length!==1?"s":""}</span>
                    </div>
                  </div>
                  {evts.length===0?(
                    <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${200+si*120}ms`}}>
                      <div style={{padding:"16px 20px",borderRadius:14,background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.04)",textAlign:"center",marginBottom:8}}>
                        <span style={{fontSize:13,color:"rgba(255,255,255,0.4)"}}>No events scheduled</span>
                      </div>
                    </div>
                  ):(
                    evts.map((evt,i)=>(
                      <div key={evt.id} className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${200+si*120+i*50}ms`}}>
                        {renderEventCard(evt,key)}
                      </div>
                    ))
                  )}
                </div>
              ))}
            </>
          ):(
            /* ── SELECTED DAY VIEW ── */
            <>
              <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"160ms"}}>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span style={{fontSize:15,fontWeight:700,color:"#fff"}}>
                      {isToday(selDay)?"Today":new Date(viewY,viewM,selDay).toLocaleDateString("en-US",{weekday:"long",month:"short",day:"numeric"})}
                    </span>
                    {selDay!==null&&<button onClick={()=>setSelDay(null)} style={{padding:"3px 8px",borderRadius:6,border:"1px solid rgba(255,255,255,0.08)",background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.6)",fontSize:11,fontWeight:500,cursor:"pointer",fontFamily:"inherit"}}>Clear</button>}
                  </div>
                  <span style={{fontSize:12,color:"rgba(255,255,255,0.5)"}}>{selEvents.length} item{selEvents.length!==1?"s":""}</span>
                </div>
              </div>
              {selEvents.length===0?(
                <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"240ms"}}>
                  <div className="dp-g" style={{padding:32,textAlign:"center"}}>
                    <Calendar size={32} color="rgba(255,255,255,0.15)" strokeWidth={1.5} style={{margin:"0 auto 10px"}}/>
                    <div style={{fontSize:14,color:"rgba(255,255,255,0.5)"}}>No events for this day</div>
                    <button onClick={()=>{setNewTitle("");setAddEvt(true);}} style={{marginTop:12,padding:"8px 16px",borderRadius:10,border:"1px solid rgba(139,92,246,0.2)",background:"rgba(139,92,246,0.08)",color:"#C4B5FD",fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit",display:"inline-flex",alignItems:"center",gap:4}}>
                      <Plus size={13} strokeWidth={2}/>Add Event
                    </button>
                  </div>
                </div>
              ):(
                selEvents.map((evt,i)=>(
                  <div key={evt.id} className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${240+i*60}ms`}}>
                    {renderEventCard(evt,selKey)}
                  </div>
                ))
              )}
            </>
          )}

        </div>
      </main>

      {/* ═══ DELETE CONFIRM ═══ */}
      {confirmDel&&(
        <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div onClick={()=>setConfirmDel(null)} style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.6)",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)"}}/>
          <div style={{position:"relative",width:"85%",maxWidth:340,background:"rgba(12,8,26,0.97)",backdropFilter:"blur(40px)",WebkitBackdropFilter:"blur(40px)",borderRadius:22,border:"1px solid rgba(239,68,68,0.12)",boxShadow:"0 20px 60px rgba(0,0,0,0.5)",padding:24,animation:"dpFS 0.2s ease-out"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
              <div style={{width:36,height:36,borderRadius:12,background:"rgba(239,68,68,0.08)",display:"flex",alignItems:"center",justifyContent:"center"}}>
                <Trash2 size={18} color="rgba(239,68,68,0.8)" strokeWidth={2}/>
              </div>
              <div style={{fontSize:15,fontWeight:600,color:"#fff"}}>Delete Event?</div>
            </div>
            <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginBottom:16,lineHeight:1.5}}>
              Are you sure you want to delete "<span style={{color:"#fff",fontWeight:500}}>{confirmDel.title}</span>"? This cannot be undone.
            </div>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>setConfirmDel(null)} style={{flex:1,padding:"11px",borderRadius:12,border:"1px solid rgba(255,255,255,0.08)",background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.7)",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>Cancel</button>
              <button onClick={()=>deleteEvent(confirmDel.key,confirmDel.id)} style={{flex:1,padding:"11px",borderRadius:12,border:"none",background:"rgba(239,68,68,0.15)",color:"rgba(239,68,68,0.9)",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit",transition:"all 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.background="rgba(239,68,68,0.25)"}
                onMouseLeave={e=>e.currentTarget.style.background="rgba(239,68,68,0.15)"}>Delete</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══ ADD EVENT MODAL ═══ */}
      {addEvt&&(
        <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div onClick={()=>setAddEvt(false)} style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.6)",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)"}}/>
          <div style={{position:"relative",width:"90%",maxWidth:380,background:"rgba(12,8,26,0.97)",backdropFilter:"blur(40px)",WebkitBackdropFilter:"blur(40px)",borderRadius:22,border:"1px solid rgba(255,255,255,0.08)",boxShadow:"0 20px 60px rgba(0,0,0,0.5)",padding:24,animation:"dpFS 0.25s ease-out"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
              <span style={{fontSize:16,fontWeight:600,color:"#fff"}}>New Event</span>
              <button className="dp-ib" style={{width:32,height:32}} onClick={()=>setAddEvt(false)}><X size={16} strokeWidth={2}/></button>
            </div>
            <div style={{marginBottom:12}}>
              <label style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.7)",marginBottom:6,display:"block"}}>Title</label>
              <input value={newTitle} onChange={e=>setNewTitle(e.target.value)} autoFocus placeholder="Event name..." style={{width:"100%",padding:"10px 14px",borderRadius:12,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",color:"#fff",fontSize:14,fontFamily:"inherit",outline:"none"}}/>
            </div>
            <div style={{marginBottom:12}}>
              <label style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.7)",marginBottom:6,display:"block"}}>Date</label>
              <div style={{padding:"10px 14px",borderRadius:12,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",color:"rgba(255,255,255,0.85)",fontSize:14,display:"flex",alignItems:"center",gap:8}}>
                <Calendar size={14} color="#C4B5FD" strokeWidth={2}/>
                {new Date(viewY,viewM,selDay||TODAY.d).toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric",year:"numeric"})}
              </div>
            </div>
            <div style={{marginBottom:16}}>
              <label style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.7)",marginBottom:6,display:"block"}}>Time</label>
              <input value={newTime} onChange={e=>setNewTime(e.target.value)} placeholder="9:00 AM" style={{width:"100%",padding:"10px 14px",borderRadius:12,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",color:"#fff",fontSize:14,fontFamily:"inherit",outline:"none"}}/>
            </div>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>setAddEvt(false)} style={{flex:1,padding:"12px",borderRadius:12,border:"1px solid rgba(255,255,255,0.08)",background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.7)",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>Cancel</button>
              <button onClick={handleAddEvt} disabled={!newTitle.trim()} style={{flex:1,padding:"12px",borderRadius:12,border:"none",background:newTitle.trim()?"linear-gradient(135deg,#8B5CF6,#6D28D9)":"rgba(255,255,255,0.04)",color:newTitle.trim()?"#fff":"rgba(255,255,255,0.25)",fontSize:14,fontWeight:600,cursor:newTitle.trim()?"pointer":"not-allowed",fontFamily:"inherit"}}>Create</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        *{margin:0;padding:0;box-sizing:border-box;}::-webkit-scrollbar{width:0;}
        input::placeholder{color:rgba(255,255,255,0.3);}
        .dp-ib{width:40px;height:40px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.05);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;}
        .dp-ib:hover{background:rgba(255,255,255,0.1);}
        .dp-g{background:rgba(255,255,255,0.04);backdrop-filter:blur(40px) saturate(1.3);-webkit-backdrop-filter:blur(40px) saturate(1.3);border-radius:18px;border:1px solid rgba(255,255,255,0.06);box-shadow:0 4px 24px rgba(0,0,0,0.12),inset 0 1px 0 rgba(255,255,255,0.03);transition:all 0.3s cubic-bezier(0.16,1,0.3,1);}
        .dp-gh:hover{background:rgba(255,255,255,0.07);border-color:rgba(255,255,255,0.1);transform:translateY(-1px);}
        .dp-a{opacity:0;transform:translateY(16px);transition:opacity 0.5s cubic-bezier(0.16,1,0.3,1),transform 0.5s cubic-bezier(0.16,1,0.3,1);}
        .dp-a.dp-s{opacity:1;transform:translateY(0);}
        @keyframes dpFS{from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);}}
        ${NEBULAE.map((n,i)=>`
          .dp-n-${i}{animation:dpNF${i} ${n.sp}s ease-in-out infinite;}
          @keyframes dpNF${i}{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:1;}33%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1+Math.random()*0.06});opacity:${0.8+Math.random()*0.2};}66%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1-Math.random()*0.04});opacity:${0.85+Math.random()*0.15};}}
        `).join("")}
      `}</style>
    </div>
  );
}
