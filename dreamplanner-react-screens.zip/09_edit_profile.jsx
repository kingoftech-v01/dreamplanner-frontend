import { useState, useEffect, useRef, useCallback } from "react";
import {
  ArrowLeft, Camera, User, Mail, Clock, MapPin,
  FileText, Check, X, Image, Loader
} from "lucide-react";

/* ═══════════════════════════════════════════════════════════════════
 * DreamPlanner — Edit Profile Screen v1
 *
 * From Flutter: avatar upload, display name, timezone fields, save
 * UX Upgrades: bio field, avatar picker bottom sheet (camera/gallery),
 *   inline validation, success toast, unsaved changes warning
 * ═══════════════════════════════════════════════════════════════════ */

const USER = {
  name:"Stephane", initial:"S", email:"stephane@rhematek.com",
  timezone:"America/Toronto", bio:"Full-stack dev at Rhematek Solutions. Building dreams one line of code at a time.",
  avatarUrl:null,
};

// ─── COSMIC BG (compact) ───
const STAR_LAYERS=[{count:300,sizeRange:[0.3,1.0],opacity:0.35,parallax:0.008},{count:200,sizeRange:[0.8,1.8],opacity:0.55,parallax:0.02},{count:100,sizeRange:[1.2,2.8],opacity:0.85,parallax:0.045}];
const STAR_COLORS=[[230,225,255],[200,210,255],[255,220,200],[180,200,255],[255,200,220],[220,240,255],[255,240,230]];
const SMOKE_CYCLE=[[255,120,160],[255,80,180],[220,60,220],[180,70,255],[130,80,255],[80,100,255],[60,140,255],[80,180,240],[100,200,220],[160,120,255],[220,100,200],[255,120,160]];
const SMOKE_CONFIGS=[{size:350,opacity:0.09,speedMult:1.0,colorSpeed:0.015,colorOffset:0,pfx:[0.13,0.31],pfy:[0.17,0.23],pax:[0.38,0.12],pay:[0.35,0.10]},{size:300,opacity:0.07,speedMult:1.3,colorSpeed:0.02,colorOffset:3,pfx:[0.19,0.41],pfy:[0.23,0.29],pax:[0.35,0.15],pay:[0.32,0.08]},{size:250,opacity:0.06,speedMult:1.7,colorSpeed:0.025,colorOffset:6,pfx:[0.29,0.53],pfy:[0.31,0.37],pax:[0.33,0.18],pay:[0.30,0.12]},{size:420,opacity:0.05,speedMult:0.6,colorSpeed:0.01,colorOffset:9,pfx:[0.07,0.19],pfy:[0.11,0.17],pax:[0.40,0.10],pay:[0.38,0.14]},{size:280,opacity:0.065,speedMult:1.1,colorSpeed:0.018,colorOffset:4.5,pfx:[0.17,0.37],pfy:[0.21,0.43],pax:[0.36,0.14],pay:[0.33,0.11]}];
const NEBULAE=[{x:"8%",y:"15%",c1:"rgba(80,120,255,0.06)",c2:"rgba(60,80,200,0.015)",s:500,b:90,sp:35},{x:"88%",y:"20%",c1:"rgba(100,140,255,0.05)",c2:"rgba(70,100,220,0.015)",s:450,b:85,sp:28},{x:"12%",y:"75%",c1:"rgba(140,80,220,0.06)",c2:"rgba(100,50,180,0.015)",s:430,b:80,sp:32},{x:"82%",y:"78%",c1:"rgba(120,70,200,0.05)",c2:"rgba(90,40,170,0.015)",s:410,b:85,sp:26},{x:"50%",y:"92%",c1:"rgba(60,100,200,0.04)",c2:"rgba(40,70,160,0.01)",s:550,b:100,sp:40},{x:"50%",y:"5%",c1:"rgba(90,60,180,0.04)",c2:"rgba(70,40,150,0.01)",s:500,b:90,sp:22}];
function lerp(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}function smokeCol(t){const l=SMOKE_CYCLE.length,i=t%l,f=Math.floor(i);return lerp(SMOKE_CYCLE[f%l],SMOKE_CYCLE[(f+1)%l],i-f);}function mkStars(layer,w,h){const s=[];for(let i=0;i<layer.count;i++)s.push({x:Math.random()*w,y:Math.random()*h,sz:layer.sizeRange[0]+Math.random()*(layer.sizeRange[1]-layer.sizeRange[0]),op:layer.opacity*(0.4+Math.random()*0.6),ts:0.3+Math.random()*2.5,to:Math.random()*Math.PI*2,c:STAR_COLORS[Math.floor(Math.random()*STAR_COLORS.length)]});return s;}function mkShoot(w,h){const e=Math.floor(Math.random()*3);let x,y,a;if(e===0){x=Math.random()*w;y=-20;a=Math.PI*0.3+Math.random()*Math.PI*0.4;}else if(e===1){x=-20;y=Math.random()*h*0.6;a=Math.PI*0.05+Math.random()*Math.PI*0.3;}else{x=w*0.5+Math.random()*w*0.5;y=-20;a=Math.PI*0.4+Math.random()*Math.PI*0.3;}const sp=5+Math.random()*8;return{x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,ln:80+Math.random()*140,life:1,dc:0.005+Math.random()*0.01,sz:0.8+Math.random()*1.8,w:Math.random()};}

// ═══════════════════════════════════════════════════════════════════
export default function EditProfileScreen(){
  const[mounted,setMounted]=useState(false);
  const[name,setName]=useState(USER.name);
  const[bio,setBio]=useState(USER.bio);
  const[timezone,setTimezone]=useState(USER.timezone);
  const[avatarPreview,setAvatarPreview]=useState(null);
  const[showPicker,setShowPicker]=useState(false);
  const[saving,setSaving]=useState(false);
  const[saved,setSaved]=useState(false);
  const[errors,setErrors]=useState({});
  const[focused,setFocused]=useState(null);
  const fileRef=useRef(null);
  const scRef=useRef(null);const mkRef=useRef(null);
  const stRef=useRef([]);const shRef=useRef([]);
  const drRef=useRef({x:0,y:0,a:0});const msRef=useRef({x:0,y:0,tx:0,ty:0});
  const tRef=useRef(0);const szRef=useRef({w:0,h:0});const afRef=useRef(null);

  useEffect(()=>{setTimeout(()=>setMounted(true),100);},[]);

  const hasChanges=name!==USER.name||bio!==USER.bio||timezone!==USER.timezone||avatarPreview;

  const handleFileSelect=(e)=>{
    const file=e.target.files?.[0];
    if(!file)return;
    const reader=new FileReader();
    reader.onload=(ev)=>{setAvatarPreview(ev.target.result);setShowPicker(false);};
    reader.readAsDataURL(file);
  };

  const validate=()=>{
    const e={};
    if(!name.trim())e.name="Display name is required";
    if(name.trim().length>0&&name.trim().length<2)e.name="Name must be at least 2 characters";
    if(bio.length>200)e.bio="Bio must be under 200 characters";
    setErrors(e);return Object.keys(e).length===0;
  };

  const handleSave=()=>{
    if(!validate())return;
    setSaving(true);
    setTimeout(()=>{setSaving(false);setSaved(true);setTimeout(()=>setSaved(false),2500);},1200);
  };

  // BG
  const init=useCallback((w,h)=>{stRef.current=STAR_LAYERS.map(l=>({c:l,s:mkStars(l,w*1.3,h*1.3)}));},[]);
  useEffect(()=>{const sc=scRef.current,mk=mkRef.current;if(!sc||!mk)return;const sx=sc.getContext("2d"),mx=mk.getContext("2d"),d=window.devicePixelRatio||1;const rs=()=>{const w=window.innerWidth,h=window.innerHeight;[sc,mk].forEach(c=>{c.width=w*d;c.height=h*d;c.style.width=w+"px";c.style.height=h+"px";});sx.setTransform(d,0,0,d,0,0);mx.setTransform(d,0,0,d,0,0);szRef.current={w,h};init(w,h);};rs();window.addEventListener("resize",rs);const mm=e=>{const cx=window.innerWidth/2,cy=window.innerHeight/2;msRef.current.tx=(e.clientX-cx)/cx;msRef.current.ty=(e.clientY-cy)/cy;};window.addEventListener("mousemove",mm);const go=()=>{const{w,h}=szRef.current;tRef.current+=0.016;const t=tRef.current;const dr=drRef.current;dr.a+=0.0008;dr.x=Math.sin(dr.a*0.7)*0.15+Math.sin(dr.a*1.3)*0.08;dr.y=Math.cos(dr.a*0.5)*0.12+Math.cos(dr.a*1.1)*0.06;const m=msRef.current;m.x+=(m.tx-m.x)*0.03;m.y+=(m.ty-m.y)*0.03;const mvx=dr.x+m.x*0.4,mvy=dr.y+m.y*0.4;mx.clearRect(0,0,w,h);SMOKE_CONFIGS.forEach(c=>{const st=t*c.speedMult;const px=0.5+c.pax[0]*Math.sin(st*c.pfx[0])+c.pax[1]*Math.sin(st*c.pfx[1]);const py=0.5+c.pay[0]*Math.cos(st*c.pfy[0])+c.pay[1]*Math.cos(st*c.pfy[1]);const x=px*w,y=py*h;const[r,g,b]=smokeCol(c.colorOffset+t*c.colorSpeed);const gr=mx.createRadialGradient(x,y,0,x,y,c.size);gr.addColorStop(0,`rgba(${r|0},${g|0},${b|0},${c.opacity})`);gr.addColorStop(0.3,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.6})`);gr.addColorStop(0.6,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.2})`);gr.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=gr;mx.beginPath();mx.arc(x,y,c.size,0,Math.PI*2);mx.fill();const ig=mx.createRadialGradient(x,y,0,x,y,c.size*0.4);ig.addColorStop(0,`rgba(${Math.min(r+40,255)|0},${Math.min(g+30,255)|0},${Math.min(b+30,255)|0},${c.opacity*0.8})`);ig.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=ig;mx.beginPath();mx.arc(x,y,c.size*0.4,0,Math.PI*2);mx.fill();});sx.clearRect(0,0,w,h);stRef.current.forEach(({c:cfg,s:stars})=>{const ox=mvx*cfg.parallax*w+(w*0.15),oy=mvy*cfg.parallax*h+(h*0.15),fw=w*1.3,fh=h*1.3;stars.forEach(s=>{const tw=Math.sin(t*s.ts+s.to)*0.35+0.65,a=s.op*tw,px=((s.x-ox)%fw+fw)%fw-w*0.15,py=((s.y-oy)%fh+fh)%fh-h*0.15;if(px<-10||px>w+10||py<-10||py>h+10)return;const[r,g,b]=s.c;if(s.sz>1.5){const gr=sx.createRadialGradient(px,py,0,px,py,s.sz*4);gr.addColorStop(0,`rgba(${r},${g},${b},${a*0.25})`);gr.addColorStop(1,`rgba(${r},${g},${b},0)`);sx.fillStyle=gr;sx.beginPath();sx.arc(px,py,s.sz*4,0,Math.PI*2);sx.fill();}if(s.sz>2.2){sx.strokeStyle=`rgba(${r},${g},${b},${a*0.15})`;sx.lineWidth=0.5;const fl=s.sz*6*tw;sx.beginPath();sx.moveTo(px-fl,py);sx.lineTo(px+fl,py);sx.moveTo(px,py-fl);sx.lineTo(px,py+fl);sx.stroke();}sx.fillStyle=`rgba(${r},${g},${b},${a})`;sx.beginPath();sx.arc(px,py,s.sz,0,Math.PI*2);sx.fill();});});if(Math.random()<0.025)shRef.current.push(mkShoot(w,h));if(Math.random()<0.003){for(let i=0;i<2+Math.floor(Math.random()*2);i++)shRef.current.push(mkShoot(w,h));}shRef.current=shRef.current.filter(s=>{s.x+=s.vx;s.y+=s.vy;s.life-=s.dc;if(s.life<=0)return false;const a=s.life*s.life,mg=Math.sqrt(s.vx*s.vx+s.vy*s.vy),dx=s.vx/mg,dy=s.vy/mg,tx=s.x-dx*s.ln*a,ty=s.y-dy*s.ln*a;const cr=s.w>0.5?255:200,cg=s.w>0.5?220:210,cb=s.w>0.5?200:255;const gr=sx.createLinearGradient(tx,ty,s.x,s.y);gr.addColorStop(0,`rgba(${cr},${cg},${cb},0)`);gr.addColorStop(0.5,`rgba(${cr},${cg},${cb},${a*0.25})`);gr.addColorStop(1,`rgba(255,255,255,${a*0.9})`);sx.strokeStyle=gr;sx.lineWidth=s.sz;sx.lineCap="round";sx.beginPath();sx.moveTo(tx,ty);sx.lineTo(s.x,s.y);sx.stroke();const hg=sx.createRadialGradient(s.x,s.y,0,s.x,s.y,5);hg.addColorStop(0,`rgba(255,255,255,${a*0.9})`);hg.addColorStop(1,`rgba(${cr},${cg},${cb},0)`);sx.fillStyle=hg;sx.beginPath();sx.arc(s.x,s.y,5,0,Math.PI*2);sx.fill();return true;});afRef.current=requestAnimationFrame(go);};afRef.current=requestAnimationFrame(go);return()=>{cancelAnimationFrame(afRef.current);window.removeEventListener("resize",rs);window.removeEventListener("mousemove",mm);};
  },[init]);

  const Field=({icon:I,label,value,onChange,error,placeholder,disabled,multiline,maxLen,name:fName})=>(
    <div style={{marginBottom:16}}>
      <label style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.7)",marginBottom:6,display:"block",paddingLeft:4}}>{label}</label>
      <div style={{display:"flex",alignItems:"flex-start",gap:10,padding:multiline?"12px 14px":"0 14px",borderRadius:14,background:"rgba(255,255,255,0.03)",border:`1px solid ${error?"rgba(239,68,68,0.3)":focused===fName?"rgba(139,92,246,0.3)":"rgba(255,255,255,0.06)"}`,transition:"all 0.2s",boxShadow:focused===fName?"0 0 0 3px rgba(139,92,246,0.08)":"none"}}>
        {!multiline&&<div style={{display:"flex",alignItems:"center",height:46}}><I size={16} color={error?"rgba(239,68,68,0.7)":"#C4B5FD"} strokeWidth={2}/></div>}
        {multiline?(
          <textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} disabled={disabled}
            onFocus={()=>setFocused(fName)} onBlur={()=>setFocused(null)}
            rows={3} style={{flex:1,background:"none",border:"none",outline:"none",color:disabled?"rgba(255,255,255,0.4)":"#fff",fontSize:14,fontFamily:"inherit",resize:"none",lineHeight:1.5}}/>
        ):(
          <input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} disabled={disabled}
            onFocus={()=>setFocused(fName)} onBlur={()=>setFocused(null)}
            style={{flex:1,height:46,background:"none",border:"none",outline:"none",color:disabled?"rgba(255,255,255,0.4)":"#fff",fontSize:14,fontFamily:"inherit"}}/>
        )}
      </div>
      <div style={{display:"flex",justifyContent:"space-between",paddingLeft:4,marginTop:4}}>
        {error?<span style={{fontSize:11,color:"rgba(239,68,68,0.8)"}}>{error}</span>:<span/>}
        {maxLen&&<span style={{fontSize:11,color:value.length>maxLen?"rgba(239,68,68,0.8)":"rgba(255,255,255,0.4)"}}>{value.length}/{maxLen}</span>}
      </div>
    </div>
  );

  return(
    <div style={{width:"100%",height:"100vh",overflow:"hidden",fontFamily:"'Inter',-apple-system,BlinkMacSystemFont,sans-serif",display:"flex",flexDirection:"column",position:"relative"}}>
      <div style={{position:"fixed",inset:0,background:"radial-gradient(ellipse at 50% 50%,#0c081a 0%,#070412 35%,#03010a 70%,#000005 100%)",zIndex:0}}>
        {NEBULAE.map((n,i)=><div key={i} className={`dp-n-${i}`} style={{position:"absolute",left:n.x,top:n.y,width:n.s,height:n.s,transform:"translate(-50%,-50%)",background:`radial-gradient(circle,${n.c1} 0%,${n.c2} 40%,transparent 70%)`,filter:`blur(${n.b}px)`,pointerEvents:"none"}}/>)}
        <canvas ref={mkRef} style={{position:"absolute",inset:0,pointerEvents:"none",mixBlendMode:"screen"}}/>
        <canvas ref={scRef} style={{position:"absolute",inset:0,pointerEvents:"none"}}/>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at center,transparent 30%,rgba(3,1,10,0.5) 70%,rgba(0,0,5,0.8) 100%)",pointerEvents:"none"}}/>
      </div>

      {/* APPBAR */}
      <header style={{position:"relative",zIndex:100,height:64,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",background:"rgba(255,255,255,0.03)",backdropFilter:"blur(40px) saturate(1.4)",WebkitBackdropFilter:"blur(40px) saturate(1.4)",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button className="dp-ib"><ArrowLeft size={20} strokeWidth={2}/></button>
          <span style={{fontSize:17,fontWeight:700,color:"#fff",letterSpacing:"-0.3px"}}>Edit Profile</span>
        </div>
        {hasChanges&&!saved&&<span style={{fontSize:12,color:"#FCD34D",fontWeight:500}}>Unsaved changes</span>}
        {saved&&<span style={{fontSize:12,color:"#5DE5A8",fontWeight:600,display:"flex",alignItems:"center",gap:4}}><Check size={14} strokeWidth={2.5}/>Saved!</span>}
      </header>

      <main style={{flex:1,overflowY:"auto",overflowX:"hidden",zIndex:10,padding:"24px 16px 32px"}}>
        <div style={{maxWidth:440,margin:"0 auto"}}>

          {/* ── Avatar ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"0ms",textAlign:"center",marginBottom:32}}>
            <div style={{position:"relative",width:120,height:120,margin:"0 auto"}}>
              {/* Gradient ring */}
              <div style={{position:"absolute",inset:-4,borderRadius:"50%",background:"conic-gradient(from 0deg,#8B5CF6,#C4B5FD,#5DE5A8,#14B8A6,#8B5CF6)",opacity:0.6,filter:"blur(1px)"}}/>
              <div style={{position:"absolute",inset:-4,borderRadius:"50%",background:"conic-gradient(from 0deg,#8B5CF6,#C4B5FD,#5DE5A8,#14B8A6,#8B5CF6)",animation:"dpSpin 6s linear infinite",opacity:0.3}}/>
              {/* Avatar circle */}
              <div style={{position:"relative",width:120,height:120,borderRadius:"50%",background:"#0c081a",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",border:"4px solid #0c081a"}}>
                {avatarPreview?(
                  <img src={avatarPreview} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                ):(
                  <span style={{fontSize:42,fontWeight:700,color:"#C4B5FD"}}>{USER.initial}</span>
                )}
              </div>
              {/* Camera button */}
              <button onClick={()=>setShowPicker(true)} style={{position:"absolute",bottom:0,right:0,width:38,height:38,borderRadius:"50%",background:"linear-gradient(135deg,#8B5CF6,#6D28D9)",border:"3px solid #0c081a",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",boxShadow:"0 4px 12px rgba(139,92,246,0.4)",transition:"all 0.2s"}}
                onMouseEnter={e=>e.currentTarget.style.transform="scale(1.1)"}
                onMouseLeave={e=>e.currentTarget.style.transform="scale(1)"}>
                <Camera size={16} strokeWidth={2.5}/>
              </button>
            </div>
            <div style={{marginTop:12,fontSize:12,color:"rgba(255,255,255,0.5)"}}>Tap the camera to change your photo</div>
          </div>

          {/* ── Form ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"100ms"}}>
            <div className="dp-g" style={{padding:20}}>
              <Field icon={User} label="Display Name" name="name" value={name} onChange={setName} error={errors.name} placeholder="Your name"/>
              <Field icon={Mail} label="Email" name="email" value={USER.email} onChange={()=>{}} disabled placeholder="" />
              <Field icon={Clock} label="Timezone" name="tz" value={timezone} onChange={setTimezone} placeholder="e.g. America/New_York"/>
              <Field icon={FileText} label="Bio" name="bio" value={bio} onChange={setBio} placeholder="Tell others about yourself..." multiline maxLen={200}/>
            </div>
          </div>

          {/* ── Save Button ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"200ms"}}>
            <button onClick={handleSave} disabled={saving||!hasChanges} style={{
              width:"100%",marginTop:24,padding:"15px 0",borderRadius:16,border:"none",
              background:hasChanges&&!saving?"linear-gradient(135deg,#8B5CF6,#6D28D9)":"rgba(255,255,255,0.04)",
              color:hasChanges&&!saving?"#fff":"rgba(255,255,255,0.25)",
              fontSize:15,fontWeight:600,cursor:hasChanges&&!saving?"pointer":"not-allowed",
              fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:8,
              boxShadow:hasChanges&&!saving?"0 4px 20px rgba(139,92,246,0.3)":"none",
              transition:"all 0.3s cubic-bezier(0.16,1,0.3,1)",
            }}
              onMouseEnter={e=>{if(hasChanges&&!saving)e.currentTarget.style.transform="translateY(-2px)";}}
              onMouseLeave={e=>{if(hasChanges&&!saving)e.currentTarget.style.transform="translateY(0)";}}>
              {saving?(
                <><Loader size={18} strokeWidth={2} className="dp-spin"/>Saving...</>
              ):saved?(
                <><Check size={18} strokeWidth={2.5}/>Saved!</>
              ):(
                <><Check size={18} strokeWidth={2}/>Save Changes</>
              )}
            </button>
          </div>

        </div>
      </main>

      {/* ═══ IMAGE PICKER BOTTOM SHEET ═══ */}
      {showPicker&&(
        <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",alignItems:"flex-end",justifyContent:"center"}}>
          <div onClick={()=>setShowPicker(false)} style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.5)",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)"}}/>
          <div style={{position:"relative",width:"100%",maxWidth:420,background:"rgba(12,8,26,0.97)",backdropFilter:"blur(40px)",WebkitBackdropFilter:"blur(40px)",borderRadius:"22px 22px 0 0",border:"1px solid rgba(255,255,255,0.08)",borderBottom:"none",animation:"dpSlideUp 0.3s cubic-bezier(0.16,1,0.3,1)",padding:"16px 0 24px"}}>
            {/* Handle */}
            <div style={{width:40,height:4,borderRadius:2,background:"rgba(255,255,255,0.15)",margin:"0 auto 16px"}}/>
            <div style={{fontSize:16,fontWeight:600,color:"#fff",textAlign:"center",marginBottom:16}}>Change Profile Photo</div>
            
            {[
              {Icon:Camera,label:"Take Photo",color:"#C4B5FD",action:()=>{setShowPicker(false);}},
              {Icon:Image,label:"Choose from Gallery",color:"#5DE5A8",action:()=>{fileRef.current?.click();}},
            ].map(({Icon:I,label,color,action},i)=>(
              <button key={i} onClick={action} style={{width:"100%",padding:"14px 20px",border:"none",background:"transparent",display:"flex",alignItems:"center",gap:14,cursor:"pointer",transition:"all 0.15s",fontFamily:"inherit"}}
                onMouseEnter={e=>e.currentTarget.style.background="rgba(255,255,255,0.04)"}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <div style={{width:40,height:40,borderRadius:12,background:`${color}12`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                  <I size={18} color={color} strokeWidth={2}/>
                </div>
                <span style={{fontSize:15,fontWeight:500,color:"#fff"}}>{label}</span>
              </button>
            ))}

            {avatarPreview&&(
              <button onClick={()=>{setAvatarPreview(null);setShowPicker(false);}} style={{width:"100%",padding:"14px 20px",border:"none",background:"transparent",display:"flex",alignItems:"center",gap:14,cursor:"pointer",fontFamily:"inherit",marginTop:4}}
                onMouseEnter={e=>e.currentTarget.style.background="rgba(239,68,68,0.04)"}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <div style={{width:40,height:40,borderRadius:12,background:"rgba(239,68,68,0.08)",display:"flex",alignItems:"center",justifyContent:"center"}}>
                  <X size={18} color="rgba(239,68,68,0.8)" strokeWidth={2}/>
                </div>
                <span style={{fontSize:15,fontWeight:500,color:"rgba(239,68,68,0.8)"}}>Remove Photo</span>
              </button>
            )}

            <button onClick={()=>setShowPicker(false)} style={{width:"calc(100% - 32px)",margin:"12px 16px 0",padding:"12px",borderRadius:14,border:"1px solid rgba(255,255,255,0.08)",background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.7)",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>Cancel</button>
          </div>
        </div>
      )}

      {/* Hidden file input */}
      <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={handleFileSelect}/>

      {/* ═══ SUCCESS TOAST ═══ */}
      <div style={{position:"fixed",top:80,left:"50%",transform:`translateX(-50%) translateY(${saved?0:-80}px)`,opacity:saved?1:0,transition:"all 0.4s cubic-bezier(0.16,1,0.3,1)",zIndex:400,padding:"10px 20px",borderRadius:14,background:"rgba(93,229,168,0.12)",border:"1px solid rgba(93,229,168,0.2)",backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)",display:"flex",alignItems:"center",gap:8,pointerEvents:"none"}}>
        <Check size={16} color="#5DE5A8" strokeWidth={2.5}/>
        <span style={{fontSize:14,fontWeight:600,color:"#5DE5A8"}}>Profile updated successfully!</span>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        *{margin:0;padding:0;box-sizing:border-box;}::-webkit-scrollbar{width:0;}
        input::placeholder,textarea::placeholder{color:rgba(255,255,255,0.3);}
        .dp-ib{width:40px;height:40px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.05);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;}
        .dp-ib:hover{background:rgba(255,255,255,0.1);}
        .dp-g{background:rgba(255,255,255,0.04);backdrop-filter:blur(40px) saturate(1.3);-webkit-backdrop-filter:blur(40px) saturate(1.3);border-radius:18px;border:1px solid rgba(255,255,255,0.06);box-shadow:0 4px 24px rgba(0,0,0,0.12),inset 0 1px 0 rgba(255,255,255,0.03);}
        .dp-a{opacity:0;transform:translateY(16px);transition:opacity 0.5s cubic-bezier(0.16,1,0.3,1),transform 0.5s cubic-bezier(0.16,1,0.3,1);}
        .dp-a.dp-s{opacity:1;transform:translateY(0);}
        .dp-spin{animation:dpSp 1s linear infinite;}
        @keyframes dpSp{from{transform:rotate(0);}to{transform:rotate(360deg);}}
        @keyframes dpSpin{from{transform:rotate(0);}to{transform:rotate(360deg);}}
        @keyframes dpSlideUp{from{transform:translateY(100%);}to{transform:translateY(0);}}
        ${NEBULAE.map((n,i)=>`
          .dp-n-${i}{animation:dpNF${i} ${n.sp}s ease-in-out infinite;}
          @keyframes dpNF${i}{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:1;}33%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1+Math.random()*0.06});opacity:${0.8+Math.random()*0.2};}66%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1-Math.random()*0.04});opacity:${0.85+Math.random()*0.15};}}
        `).join("")}
      `}</style>
    </div>
  );
}
