import { useState, useEffect, useRef, useCallback } from "react";

/*
 * DreamPlanner — Cosmic Space Background v4
 * 
 * Changes from v3:
 * - Added COSMIC SMOKE system: large soft glowing blobs rendered on a 
 *   separate canvas that travel around the screen in organic looping paths,
 *   rotating through all corners with smooth color morphing
 *   (rose → magenta → violet → indigo → blue → teal → back to rose)
 * - Smoke rendered via canvas for smooth 60fps movement (CSS animations 
 *   were too rigid for this organic feel)
 * - Multiple smoke layers at different speeds/sizes for depth
 * - Smoke blends additively (screen blend) with the star field
 * - Kept: stars, shooting stars (frequent), nebulae at edges, auto-drift
 */

const STAR_LAYERS = [
  { count: 300, sizeRange: [0.3, 1.0], opacity: 0.35, parallax: 0.008 },
  { count: 200, sizeRange: [0.8, 1.8], opacity: 0.55, parallax: 0.02 },
  { count: 100, sizeRange: [1.2, 2.8], opacity: 0.85, parallax: 0.045 },
];

const STAR_COLORS = [
  [230, 225, 255], [200, 210, 255], [255, 220, 200],
  [180, 200, 255], [255, 200, 220], [220, 240, 255], [255, 240, 230],
];

// Color cycle for cosmic smoke: rose → magenta → violet → indigo → blue → teal → pink → back
const SMOKE_COLOR_CYCLE = [
  [255, 120, 160],  // rose
  [255, 80, 180],   // hot pink
  [220, 60, 220],   // magenta
  [180, 70, 255],   // violet
  [130, 80, 255],   // purple
  [80, 100, 255],   // indigo
  [60, 140, 255],   // blue
  [80, 180, 240],   // sky blue
  [100, 200, 220],  // teal
  [160, 120, 255],  // lavender
  [220, 100, 200],  // pink-purple
  [255, 120, 160],  // back to rose
];

// Smoke entities — each one travels a unique looping path through the viewport
const SMOKE_CONFIGS = [
  {
    // Large primary smoke — slow grand tour
    size: 350,
    opacity: 0.09,
    speedMult: 1.0,
    colorSpeed: 0.015,
    colorOffset: 0,
    pathFreqX: [0.13, 0.31],
    pathFreqY: [0.17, 0.23],
    pathAmpX: [0.38, 0.12],
    pathAmpY: [0.35, 0.10],
  },
  {
    // Second smoke — offset path, different rhythm
    size: 300,
    opacity: 0.07,
    speedMult: 1.3,
    colorSpeed: 0.02,
    colorOffset: 3,
    pathFreqX: [0.19, 0.41],
    pathFreqY: [0.23, 0.29],
    pathAmpX: [0.35, 0.15],
    pathAmpY: [0.32, 0.08],
  },
  {
    // Third smoke — smaller, faster, more erratic
    size: 250,
    opacity: 0.06,
    speedMult: 1.7,
    colorSpeed: 0.025,
    colorOffset: 6,
    pathFreqX: [0.29, 0.53],
    pathFreqY: [0.31, 0.37],
    pathAmpX: [0.33, 0.18],
    pathAmpY: [0.30, 0.12],
  },
  {
    // Fourth — large but faint, very slow background layer
    size: 420,
    opacity: 0.05,
    speedMult: 0.6,
    colorSpeed: 0.01,
    colorOffset: 9,
    pathFreqX: [0.07, 0.19],
    pathFreqY: [0.11, 0.17],
    pathAmpX: [0.40, 0.10],
    pathAmpY: [0.38, 0.14],
  },
  {
    // Fifth — mid-size, medium speed
    size: 280,
    opacity: 0.065,
    speedMult: 1.1,
    colorSpeed: 0.018,
    colorOffset: 4.5,
    pathFreqX: [0.17, 0.37],
    pathFreqY: [0.21, 0.43],
    pathAmpX: [0.36, 0.14],
    pathAmpY: [0.33, 0.11],
  },
];

const NEBULAE = [
  { x: "8%",  y: "15%", color1: "rgba(80, 120, 255, 0.06)", color2: "rgba(60, 80, 200, 0.015)", size: 500, blur: 90, speed: 35 },
  { x: "88%", y: "20%", color1: "rgba(100, 140, 255, 0.05)", color2: "rgba(70, 100, 220, 0.015)", size: 450, blur: 85, speed: 28 },
  { x: "12%", y: "75%", color1: "rgba(140, 80, 220, 0.06)", color2: "rgba(100, 50, 180, 0.015)", size: 430, blur: 80, speed: 32 },
  { x: "82%", y: "78%", color1: "rgba(120, 70, 200, 0.05)", color2: "rgba(90, 40, 170, 0.015)", size: 410, blur: 85, speed: 26 },
  { x: "50%", y: "92%", color1: "rgba(60, 100, 200, 0.04)", color2: "rgba(40, 70, 160, 0.01)", size: 550, blur: 100, speed: 40 },
  { x: "50%", y: "5%",  color1: "rgba(90, 60, 180, 0.04)", color2: "rgba(70, 40, 150, 0.01)", size: 500, blur: 90, speed: 22 },
];

function lerpColor(colorA, colorB, t) {
  return [
    colorA[0] + (colorB[0] - colorA[0]) * t,
    colorA[1] + (colorB[1] - colorA[1]) * t,
    colorA[2] + (colorB[2] - colorA[2]) * t,
  ];
}

function getSmokeColor(timeOffset) {
  const len = SMOKE_COLOR_CYCLE.length;
  const idx = timeOffset % len;
  const floor = Math.floor(idx);
  const frac = idx - floor;
  const colorA = SMOKE_COLOR_CYCLE[floor % len];
  const colorB = SMOKE_COLOR_CYCLE[(floor + 1) % len];
  return lerpColor(colorA, colorB, frac);
}

function generateStars(layer, width, height) {
  const stars = [];
  for (let i = 0; i < layer.count; i++) {
    const colorIdx = Math.floor(Math.random() * STAR_COLORS.length);
    stars.push({
      x: Math.random() * width,
      y: Math.random() * height,
      size: layer.sizeRange[0] + Math.random() * (layer.sizeRange[1] - layer.sizeRange[0]),
      baseOpacity: layer.opacity * (0.4 + Math.random() * 0.6),
      twinkleSpeed: 0.3 + Math.random() * 2.5,
      twinkleOffset: Math.random() * Math.PI * 2,
      color: STAR_COLORS[colorIdx],
    });
  }
  return stars;
}

function generateShootingStar(width, height) {
  const edge = Math.floor(Math.random() * 3);
  let x, y, angle;
  if (edge === 0) {
    x = Math.random() * width;
    y = -20;
    angle = Math.PI * 0.3 + Math.random() * Math.PI * 0.4;
  } else if (edge === 1) {
    x = -20;
    y = Math.random() * height * 0.6;
    angle = Math.PI * 0.05 + Math.random() * Math.PI * 0.3;
  } else {
    x = width * 0.5 + Math.random() * width * 0.5;
    y = -20;
    angle = Math.PI * 0.4 + Math.random() * Math.PI * 0.3;
  }
  const speed = 5 + Math.random() * 8;
  return {
    x, y,
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    length: 80 + Math.random() * 140,
    life: 1.0,
    decay: 0.005 + Math.random() * 0.01,
    size: 0.8 + Math.random() * 1.8,
    warmth: Math.random(),
  };
}

export default function CosmicBackground() {
  const starCanvasRef = useRef(null);
  const smokeCanvasRef = useRef(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const driftRef = useRef({ x: 0, y: 0, angle: 0 });
  const starsRef = useRef([]);
  const shootingStarsRef = useRef([]);
  const animFrameRef = useRef(null);
  const timeRef = useRef(0);
  const sizeRef = useRef({ w: 0, h: 0 });

  const initStars = useCallback((w, h) => {
    starsRef.current = STAR_LAYERS.map((layer) => ({
      config: layer,
      stars: generateStars(layer, w * 1.3, h * 1.3),
    }));
  }, []);

  useEffect(() => {
    const starCanvas = starCanvasRef.current;
    const smokeCanvas = smokeCanvasRef.current;
    if (!starCanvas || !smokeCanvas) return;
    const starCtx = starCanvas.getContext("2d");
    const smokeCtx = smokeCanvas.getContext("2d");
    const dpr = window.devicePixelRatio || 1;

    const resize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      [starCanvas, smokeCanvas].forEach((c) => {
        c.width = w * dpr;
        c.height = h * dpr;
        c.style.width = w + "px";
        c.style.height = h + "px";
      });
      starCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      smokeCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      sizeRef.current = { w, h };
      initStars(w, h);
    };

    resize();
    window.addEventListener("resize", resize);

    const handleMouse = (e) => {
      const cx = window.innerWidth / 2;
      const cy = window.innerHeight / 2;
      mouseRef.current.targetX = (e.clientX - cx) / cx;
      mouseRef.current.targetY = (e.clientY - cy) / cy;
    };
    const handleTouch = (e) => {
      if (e.touches.length > 0) {
        const cx = window.innerWidth / 2;
        const cy = window.innerHeight / 2;
        mouseRef.current.targetX = (e.touches[0].clientX - cx) / cx * 0.5;
        mouseRef.current.targetY = (e.touches[0].clientY - cy) / cy * 0.5;
      }
    };
    const handleTouchEnd = () => {
      mouseRef.current.targetX = 0;
      mouseRef.current.targetY = 0;
    };

    window.addEventListener("mousemove", handleMouse);
    window.addEventListener("touchmove", handleTouch, { passive: true });
    window.addEventListener("touchend", handleTouchEnd);

    const animate = () => {
      const { w, h } = sizeRef.current;
      timeRef.current += 0.016;
      const t = timeRef.current;

      // Auto-drift
      const drift = driftRef.current;
      drift.angle += 0.0008;
      drift.x = Math.sin(drift.angle * 0.7) * 0.15 + Math.sin(drift.angle * 1.3) * 0.08;
      drift.y = Math.cos(drift.angle * 0.5) * 0.12 + Math.cos(drift.angle * 1.1) * 0.06;

      const m = mouseRef.current;
      m.x += (m.targetX - m.x) * 0.03;
      m.y += (m.targetY - m.y) * 0.03;

      const moveX = drift.x + m.x * 0.4;
      const moveY = drift.y + m.y * 0.4;

      // ═══════════════════════════════════════════
      // SMOKE CANVAS — cosmic fog / colored smoke
      // ═══════════════════════════════════════════
      smokeCtx.clearRect(0, 0, w, h);

      SMOKE_CONFIGS.forEach((cfg) => {
        const st = t * cfg.speedMult;
        
        // Lissajous-like path that sweeps through corners
        const px = 0.5 + cfg.pathAmpX[0] * Math.sin(st * cfg.pathFreqX[0]) 
                       + cfg.pathAmpX[1] * Math.sin(st * cfg.pathFreqX[1]);
        const py = 0.5 + cfg.pathAmpY[0] * Math.cos(st * cfg.pathFreqY[0]) 
                       + cfg.pathAmpY[1] * Math.cos(st * cfg.pathFreqY[1]);

        const sx = px * w;
        const sy = py * h;

        // Color morphing
        const colorTime = cfg.colorOffset + t * cfg.colorSpeed;
        const [cr, cg, cb] = getSmokeColor(colorTime);

        // Draw soft radial glow
        const outerRadius = cfg.size;
        const gradient = smokeCtx.createRadialGradient(sx, sy, 0, sx, sy, outerRadius);
        gradient.addColorStop(0, `rgba(${cr|0}, ${cg|0}, ${cb|0}, ${cfg.opacity})`);
        gradient.addColorStop(0.3, `rgba(${cr|0}, ${cg|0}, ${cb|0}, ${cfg.opacity * 0.6})`);
        gradient.addColorStop(0.6, `rgba(${cr|0}, ${cg|0}, ${cb|0}, ${cfg.opacity * 0.2})`);
        gradient.addColorStop(1, `rgba(${cr|0}, ${cg|0}, ${cb|0}, 0)`);

        smokeCtx.fillStyle = gradient;
        smokeCtx.beginPath();
        smokeCtx.arc(sx, sy, outerRadius, 0, Math.PI * 2);
        smokeCtx.fill();

        // Secondary inner glow — brighter core
        const innerRadius = cfg.size * 0.4;
        const innerGrad = smokeCtx.createRadialGradient(sx, sy, 0, sx, sy, innerRadius);
        innerGrad.addColorStop(0, `rgba(${Math.min(cr + 40, 255)|0}, ${Math.min(cg + 30, 255)|0}, ${Math.min(cb + 30, 255)|0}, ${cfg.opacity * 0.8})`);
        innerGrad.addColorStop(1, `rgba(${cr|0}, ${cg|0}, ${cb|0}, 0)`);

        smokeCtx.fillStyle = innerGrad;
        smokeCtx.beginPath();
        smokeCtx.arc(sx, sy, innerRadius, 0, Math.PI * 2);
        smokeCtx.fill();
      });

      // ═══════════════════════════════════════════
      // STAR CANVAS — stars + shooting stars
      // ═══════════════════════════════════════════
      starCtx.clearRect(0, 0, w, h);

      starsRef.current.forEach(({ config, stars }) => {
        const offsetX = moveX * config.parallax * w + (w * 0.15);
        const offsetY = moveY * config.parallax * h + (h * 0.15);
        const fieldW = w * 1.3;
        const fieldH = h * 1.3;

        stars.forEach((star) => {
          const twinkle = Math.sin(t * star.twinkleSpeed + star.twinkleOffset) * 0.35 + 0.65;
          const alpha = star.baseOpacity * twinkle;
          const sx = ((star.x - offsetX) % fieldW + fieldW) % fieldW - w * 0.15;
          const sy = ((star.y - offsetY) % fieldH + fieldH) % fieldH - h * 0.15;

          if (sx < -10 || sx > w + 10 || sy < -10 || sy > h + 10) return;

          const [r, g, b] = star.color;

          if (star.size > 1.5) {
            const gradient = starCtx.createRadialGradient(sx, sy, 0, sx, sy, star.size * 4);
            gradient.addColorStop(0, `rgba(${r}, ${g}, ${b}, ${alpha * 0.25})`);
            gradient.addColorStop(1, `rgba(${r}, ${g}, ${b}, 0)`);
            starCtx.fillStyle = gradient;
            starCtx.beginPath();
            starCtx.arc(sx, sy, star.size * 4, 0, Math.PI * 2);
            starCtx.fill();
          }

          if (star.size > 2.2) {
            starCtx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${alpha * 0.15})`;
            starCtx.lineWidth = 0.5;
            const flareLen = star.size * 6 * twinkle;
            starCtx.beginPath();
            starCtx.moveTo(sx - flareLen, sy);
            starCtx.lineTo(sx + flareLen, sy);
            starCtx.moveTo(sx, sy - flareLen);
            starCtx.lineTo(sx, sy + flareLen);
            starCtx.stroke();
          }

          starCtx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
          starCtx.beginPath();
          starCtx.arc(sx, sy, star.size, 0, Math.PI * 2);
          starCtx.fill();
        });
      });

      // Shooting stars
      if (Math.random() < 0.025) {
        shootingStarsRef.current.push(generateShootingStar(w, h));
      }
      if (Math.random() < 0.003) {
        const burst = 2 + Math.floor(Math.random() * 2);
        for (let i = 0; i < burst; i++) {
          shootingStarsRef.current.push(generateShootingStar(w, h));
        }
      }

      shootingStarsRef.current = shootingStarsRef.current.filter((s) => {
        s.x += s.vx;
        s.y += s.vy;
        s.life -= s.decay;
        if (s.life <= 0) return false;

        const alpha = s.life * s.life;
        const mag = Math.sqrt(s.vx * s.vx + s.vy * s.vy);
        const dx = s.vx / mag;
        const dy = s.vy / mag;
        const tailX = s.x - dx * s.length * alpha;
        const tailY = s.y - dy * s.length * alpha;

        const cr = s.warmth > 0.5 ? 255 : 200;
        const cg = s.warmth > 0.5 ? 220 : 210;
        const cb = s.warmth > 0.5 ? 200 : 255;

        const gradient = starCtx.createLinearGradient(tailX, tailY, s.x, s.y);
        gradient.addColorStop(0, `rgba(${cr}, ${cg}, ${cb}, 0)`);
        gradient.addColorStop(0.5, `rgba(${cr}, ${cg}, ${cb}, ${alpha * 0.25})`);
        gradient.addColorStop(1, `rgba(255, 255, 255, ${alpha * 0.9})`);

        starCtx.strokeStyle = gradient;
        starCtx.lineWidth = s.size;
        starCtx.lineCap = "round";
        starCtx.beginPath();
        starCtx.moveTo(tailX, tailY);
        starCtx.lineTo(s.x, s.y);
        starCtx.stroke();

        const headGlow = starCtx.createRadialGradient(s.x, s.y, 0, s.x, s.y, 5);
        headGlow.addColorStop(0, `rgba(255, 255, 255, ${alpha * 0.9})`);
        headGlow.addColorStop(0.5, `rgba(${cr}, ${cg}, ${cb}, ${alpha * 0.3})`);
        headGlow.addColorStop(1, `rgba(${cr}, ${cg}, ${cb}, 0)`);
        starCtx.fillStyle = headGlow;
        starCtx.beginPath();
        starCtx.arc(s.x, s.y, 5, 0, Math.PI * 2);
        starCtx.fill();

        return true;
      });

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", handleMouse);
      window.removeEventListener("touchmove", handleTouch);
      window.removeEventListener("touchend", handleTouchEnd);
    };
  }, [initStars]);

  return (
    <div style={{
      position: "fixed",
      inset: 0,
      overflow: "hidden",
      background: "radial-gradient(ellipse at 50% 50%, #0c081a 0%, #070412 35%, #03010a 70%, #000005 100%)",
      zIndex: 0,
    }}>
      {/* Static nebulae — subtle edge atmosphere */}
      {NEBULAE.map((neb, i) => (
        <div
          key={i}
          className={`dp-neb-${i}`}
          style={{
            position: "absolute",
            left: neb.x,
            top: neb.y,
            width: neb.size,
            height: neb.size,
            transform: "translate(-50%, -50%)",
            background: `radial-gradient(circle, ${neb.color1} 0%, ${neb.color2} 40%, transparent 70%)`,
            filter: `blur(${neb.blur}px)`,
            pointerEvents: "none",
          }}
        />
      ))}

      {/* Smoke canvas — colored cosmic fog, rendered below stars */}
      <canvas
        ref={smokeCanvasRef}
        style={{
          position: "absolute",
          inset: 0,
          pointerEvents: "none",
          mixBlendMode: "screen",
        }}
      />

      {/* Star canvas — stars + shooting stars, on top */}
      <canvas
        ref={starCanvasRef}
        style={{
          position: "absolute",
          inset: 0,
          pointerEvents: "none",
        }}
      />

      {/* Cosmic dust texture */}
      <div style={{
        position: "absolute",
        inset: 0,
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.035'/%3E%3C/svg%3E")`,
        opacity: 0.5,
        pointerEvents: "none",
        mixBlendMode: "screen",
      }} />

      {/* Vignette */}
      <div style={{
        position: "absolute",
        inset: 0,
        background: "radial-gradient(ellipse at center, transparent 30%, rgba(3, 1, 10, 0.5) 70%, rgba(0, 0, 5, 0.8) 100%)",
        pointerEvents: "none",
      }} />

      {/* Nebula float animations */}
      <style>{`
        ${NEBULAE.map((neb, i) => {
          const dx1 = (Math.random() - 0.5) * 10;
          const dy1 = (Math.random() - 0.5) * 10;
          const dx2 = (Math.random() - 0.5) * 10;
          const dy2 = (Math.random() - 0.5) * 10;
          return `
            .dp-neb-${i} {
              animation: dpNF${i} ${neb.speed}s ease-in-out infinite;
            }
            @keyframes dpNF${i} {
              0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
              33% { transform: translate(calc(-50% + ${dx1}px), calc(-50% + ${dy1}px)) scale(${1 + Math.random() * 0.06}); opacity: ${0.8 + Math.random() * 0.2}; }
              66% { transform: translate(calc(-50% + ${dx2}px), calc(-50% + ${dy2}px)) scale(${1 - Math.random() * 0.04}); opacity: ${0.85 + Math.random() * 0.15}; }
            }
          `;
        }).join("\n")}
      `}</style>
    </div>
  );
}
