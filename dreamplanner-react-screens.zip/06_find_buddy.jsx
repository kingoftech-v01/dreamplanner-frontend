import { useState, useEffect, useRef, useCallback } from "react";
import {
  ArrowLeft, Target, Heart, MessageCircle, Users, Star,
  Zap, ChevronRight, UserPlus, RefreshCw, Sparkles,
  Send, X, Check, Flame, Trophy, Brain, Briefcase,
  Palette, Wallet, Search
} from "lucide-react";

/* ═══════════════════════════════════════════════════════════════════
 * DreamPlanner — Find My Buddy Screen v1
 * 
 * From Flutter:
 * - Current buddy card (if paired)
 * - Find match CTA (if not paired)
 * - Suggested buddies list
 * - Compatibility score, shared categories
 * - Request buddy, encourage dialog
 *
 * UX Upgrades:
 * - Animated compatibility ring (SVG)
 * - Card-based suggested buddies (not list)
 * - Shared dreams displayed with category icons
 * - Match animation when requesting
 * - Encourage modal with preset messages
 * - Stats comparison between you and buddy
 * - "How matching works" section
 * - All 9:1+ contrast
 * ═══════════════════════════════════════════════════════════════════ */

const ME = { name:"Stephane", initial:"S", level:12, xp:2450, streak:7, dreams:["Launch SaaS","Learn Piano","Run Half Marathon","Save $15K"] };

const CURRENT_BUDDY = {
  id:"b1", name:"Alex", initial:"A", color:"#14B8A6", online:true,
  level:10, xp:2100, streak:12, compatibility:87,
  sharedDreams:["Run Half Marathon"],
  sharedCategories:["health","personal"],
  joinedDate:"3 weeks ago",
  encouragements:5,
};

const SUGGESTIONS = [
  { id:"s1", name:"Sophie", initial:"S", color:"#EC4899", level:9, xp:1850, compatibility:82, sharedCategories:["career","finance"], sharedDreams:["Launch SaaS"], bio:"Full-stack dev building side projects", streak:8, dreams:["Launch SaaS","Travel to Japan","Build an audience"], achievements:["7-day streak","First Dream","10 Tasks Done"], joined:"2 months ago", mutualFriends:2 },
  { id:"s2", name:"Liam", initial:"L", color:"#3B82F6", level:14, xp:3100, compatibility:76, sharedCategories:["health","personal"], sharedDreams:["Run Half Marathon"], bio:"Marathon runner training for first ultra", streak:21, dreams:["Run Half Marathon","Complete a Triathlon","Meditate Daily"], achievements:["21-day streak","Level 10","Dream Master"], joined:"4 months ago", mutualFriends:1 },
  { id:"s3", name:"Nina", initial:"N", color:"#F59E0B", level:7, xp:1100, compatibility:71, sharedCategories:["hobbies"], sharedDreams:["Learn Piano"], bio:"Music lover, just started learning keys", streak:4, dreams:["Learn Piano","Write 12 Songs","Play at Open Mic"], achievements:["First Dream","3-day streak"], joined:"3 weeks ago", mutualFriends:0 },
  { id:"s4", name:"Kai", initial:"K", color:"#8B5CF6", level:11, xp:2200, compatibility:68, sharedCategories:["finance","career"], sharedDreams:["Save $15K"], bio:"Budgeting nerd on a savings mission", streak:14, dreams:["Save $15K","Start Investing","Side Hustle to $5K/mo"], achievements:["14-day streak","Level 10","Finance Pro"], joined:"3 months ago", mutualFriends:3 },
];

const CAT_ICONS = { career:Briefcase, hobbies:Palette, health:Heart, finance:Wallet, personal:Brain };
const CAT_COLORS = { career:"#C4B5FD", hobbies:"#FCD34D", health:"#5DE5A8", finance:"#5EEAD4", personal:"#F69A9A" };

const ENCOURAGE_PRESETS = [
  "Keep going, you're crushing it! 💪",
  "One step at a time — you've got this!",
  "Your streak is inspiring! Don't stop now 🔥",
  "Remember why you started. You're doing great!",
  "Proud of your progress this week! ⭐",
];

// ─── COSMIC BG ───────────────────────────────────────────────────
const STAR_LAYERS=[{count:300,sizeRange:[0.3,1.0],opacity:0.35,parallax:0.008},{count:200,sizeRange:[0.8,1.8],opacity:0.55,parallax:0.02},{count:100,sizeRange:[1.2,2.8],opacity:0.85,parallax:0.045}];
const STAR_COLORS=[[230,225,255],[200,210,255],[255,220,200],[180,200,255],[255,200,220],[220,240,255],[255,240,230]];
const SMOKE_CYCLE=[[255,120,160],[255,80,180],[220,60,220],[180,70,255],[130,80,255],[80,100,255],[60,140,255],[80,180,240],[100,200,220],[160,120,255],[220,100,200],[255,120,160]];
const SMOKE_CONFIGS=[{size:350,opacity:0.09,speedMult:1.0,colorSpeed:0.015,colorOffset:0,pfx:[0.13,0.31],pfy:[0.17,0.23],pax:[0.38,0.12],pay:[0.35,0.10]},{size:300,opacity:0.07,speedMult:1.3,colorSpeed:0.02,colorOffset:3,pfx:[0.19,0.41],pfy:[0.23,0.29],pax:[0.35,0.15],pay:[0.32,0.08]},{size:250,opacity:0.06,speedMult:1.7,colorSpeed:0.025,colorOffset:6,pfx:[0.29,0.53],pfy:[0.31,0.37],pax:[0.33,0.18],pay:[0.30,0.12]},{size:420,opacity:0.05,speedMult:0.6,colorSpeed:0.01,colorOffset:9,pfx:[0.07,0.19],pfy:[0.11,0.17],pax:[0.40,0.10],pay:[0.38,0.14]},{size:280,opacity:0.065,speedMult:1.1,colorSpeed:0.018,colorOffset:4.5,pfx:[0.17,0.37],pfy:[0.21,0.43],pax:[0.36,0.14],pay:[0.33,0.11]}];
const NEBULAE=[{x:"8%",y:"15%",c1:"rgba(80,120,255,0.06)",c2:"rgba(60,80,200,0.015)",s:500,b:90,sp:35},{x:"88%",y:"20%",c1:"rgba(100,140,255,0.05)",c2:"rgba(70,100,220,0.015)",s:450,b:85,sp:28},{x:"12%",y:"75%",c1:"rgba(140,80,220,0.06)",c2:"rgba(100,50,180,0.015)",s:430,b:80,sp:32},{x:"82%",y:"78%",c1:"rgba(120,70,200,0.05)",c2:"rgba(90,40,170,0.015)",s:410,b:85,sp:26},{x:"50%",y:"92%",c1:"rgba(60,100,200,0.04)",c2:"rgba(40,70,160,0.01)",s:550,b:100,sp:40},{x:"50%",y:"5%",c1:"rgba(90,60,180,0.04)",c2:"rgba(70,40,150,0.01)",s:500,b:90,sp:22}];
function lerp(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}function smokeCol(t){const l=SMOKE_CYCLE.length,i=t%l,f=Math.floor(i);return lerp(SMOKE_CYCLE[f%l],SMOKE_CYCLE[(f+1)%l],i-f);}function mkStars(layer,w,h){const s=[];for(let i=0;i<layer.count;i++)s.push({x:Math.random()*w,y:Math.random()*h,sz:layer.sizeRange[0]+Math.random()*(layer.sizeRange[1]-layer.sizeRange[0]),op:layer.opacity*(0.4+Math.random()*0.6),ts:0.3+Math.random()*2.5,to:Math.random()*Math.PI*2,c:STAR_COLORS[Math.floor(Math.random()*STAR_COLORS.length)]});return s;}function mkShoot(w,h){const e=Math.floor(Math.random()*3);let x,y,a;if(e===0){x=Math.random()*w;y=-20;a=Math.PI*0.3+Math.random()*Math.PI*0.4;}else if(e===1){x=-20;y=Math.random()*h*0.6;a=Math.PI*0.05+Math.random()*Math.PI*0.3;}else{x=w*0.5+Math.random()*w*0.5;y=-20;a=Math.PI*0.4+Math.random()*Math.PI*0.3;}const sp=5+Math.random()*8;return{x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,ln:80+Math.random()*140,life:1,dc:0.005+Math.random()*0.01,sz:0.8+Math.random()*1.8,w:Math.random()};}

// ═══════════════════════════════════════════════════════════════════
export default function FindBuddyScreen(){
  const[mounted,setMounted]=useState(false);
  const[encourage,setEncourage]=useState(false);
  const[encourageMsg,setEncourageMsg]=useState(ENCOURAGE_PRESETS[0]);
  const[sent,setSent]=useState({});
  const[sentEncourage,setSentEncourage]=useState(false);
  const[selectedProfile,setSelectedProfile]=useState(null);
  const scRef=useRef(null);const mkRef=useRef(null);
  const stRef=useRef([]);const shRef=useRef([]);
  const drRef=useRef({x:0,y:0,a:0});const msRef=useRef({x:0,y:0,tx:0,ty:0});
  const tRef=useRef(0);const szRef=useRef({w:0,h:0});const afRef=useRef(null);

  useEffect(()=>{setTimeout(()=>setMounted(true),100);},[]);

  const sendRequest=(id)=>{setSent(p=>({...p,[id]:true}));};
  const sendEncourage=()=>{setSentEncourage(true);setTimeout(()=>{setEncourage(false);setSentEncourage(false);},1500);};

  // BG engine
  const init=useCallback((w,h)=>{stRef.current=STAR_LAYERS.map(l=>({c:l,s:mkStars(l,w*1.3,h*1.3)}));},[]);
  useEffect(()=>{const sc=scRef.current,mk=mkRef.current;if(!sc||!mk)return;const sx=sc.getContext("2d"),mx=mk.getContext("2d"),d=window.devicePixelRatio||1;const rs=()=>{const w=window.innerWidth,h=window.innerHeight;[sc,mk].forEach(c=>{c.width=w*d;c.height=h*d;c.style.width=w+"px";c.style.height=h+"px";});sx.setTransform(d,0,0,d,0,0);mx.setTransform(d,0,0,d,0,0);szRef.current={w,h};init(w,h);};rs();window.addEventListener("resize",rs);const mm=e=>{const cx=window.innerWidth/2,cy=window.innerHeight/2;msRef.current.tx=(e.clientX-cx)/cx;msRef.current.ty=(e.clientY-cy)/cy;};window.addEventListener("mousemove",mm);const go=()=>{const{w,h}=szRef.current;tRef.current+=0.016;const t=tRef.current;const dr=drRef.current;dr.a+=0.0008;dr.x=Math.sin(dr.a*0.7)*0.15+Math.sin(dr.a*1.3)*0.08;dr.y=Math.cos(dr.a*0.5)*0.12+Math.cos(dr.a*1.1)*0.06;const m=msRef.current;m.x+=(m.tx-m.x)*0.03;m.y+=(m.ty-m.y)*0.03;const mvx=dr.x+m.x*0.4,mvy=dr.y+m.y*0.4;mx.clearRect(0,0,w,h);SMOKE_CONFIGS.forEach(c=>{const st=t*c.speedMult;const px=0.5+c.pax[0]*Math.sin(st*c.pfx[0])+c.pax[1]*Math.sin(st*c.pfx[1]);const py=0.5+c.pay[0]*Math.cos(st*c.pfy[0])+c.pay[1]*Math.cos(st*c.pfy[1]);const x=px*w,y=py*h;const[r,g,b]=smokeCol(c.colorOffset+t*c.colorSpeed);const gr=mx.createRadialGradient(x,y,0,x,y,c.size);gr.addColorStop(0,`rgba(${r|0},${g|0},${b|0},${c.opacity})`);gr.addColorStop(0.3,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.6})`);gr.addColorStop(0.6,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.2})`);gr.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=gr;mx.beginPath();mx.arc(x,y,c.size,0,Math.PI*2);mx.fill();const ig=mx.createRadialGradient(x,y,0,x,y,c.size*0.4);ig.addColorStop(0,`rgba(${Math.min(r+40,255)|0},${Math.min(g+30,255)|0},${Math.min(b+30,255)|0},${c.opacity*0.8})`);ig.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=ig;mx.beginPath();mx.arc(x,y,c.size*0.4,0,Math.PI*2);mx.fill();});sx.clearRect(0,0,w,h);stRef.current.forEach(({c:cfg,s:stars})=>{const ox=mvx*cfg.parallax*w+(w*0.15),oy=mvy*cfg.parallax*h+(h*0.15),fw=w*1.3,fh=h*1.3;stars.forEach(s=>{const tw=Math.sin(t*s.ts+s.to)*0.35+0.65,a=s.op*tw,px=((s.x-ox)%fw+fw)%fw-w*0.15,py=((s.y-oy)%fh+fh)%fh-h*0.15;if(px<-10||px>w+10||py<-10||py>h+10)return;const[r,g,b]=s.c;if(s.sz>1.5){const gr=sx.createRadialGradient(px,py,0,px,py,s.sz*4);gr.addColorStop(0,`rgba(${r},${g},${b},${a*0.25})`);gr.addColorStop(1,`rgba(${r},${g},${b},0)`);sx.fillStyle=gr;sx.beginPath();sx.arc(px,py,s.sz*4,0,Math.PI*2);sx.fill();}if(s.sz>2.2){sx.strokeStyle=`rgba(${r},${g},${b},${a*0.15})`;sx.lineWidth=0.5;const fl=s.sz*6*tw;sx.beginPath();sx.moveTo(px-fl,py);sx.lineTo(px+fl,py);sx.moveTo(px,py-fl);sx.lineTo(px,py+fl);sx.stroke();}sx.fillStyle=`rgba(${r},${g},${b},${a})`;sx.beginPath();sx.arc(px,py,s.sz,0,Math.PI*2);sx.fill();});});if(Math.random()<0.025)shRef.current.push(mkShoot(w,h));if(Math.random()<0.003){for(let i=0;i<2+Math.floor(Math.random()*2);i++)shRef.current.push(mkShoot(w,h));}shRef.current=shRef.current.filter(s=>{s.x+=s.vx;s.y+=s.vy;s.life-=s.dc;if(s.life<=0)return false;const a=s.life*s.life,mg=Math.sqrt(s.vx*s.vx+s.vy*s.vy),dx=s.vx/mg,dy=s.vy/mg,tx=s.x-dx*s.ln*a,ty=s.y-dy*s.ln*a;const cr=s.w>0.5?255:200,cg=s.w>0.5?220:210,cb=s.w>0.5?200:255;const gr=sx.createLinearGradient(tx,ty,s.x,s.y);gr.addColorStop(0,`rgba(${cr},${cg},${cb},0)`);gr.addColorStop(0.5,`rgba(${cr},${cg},${cb},${a*0.25})`);gr.addColorStop(1,`rgba(255,255,255,${a*0.9})`);sx.strokeStyle=gr;sx.lineWidth=s.sz;sx.lineCap="round";sx.beginPath();sx.moveTo(tx,ty);sx.lineTo(s.x,s.y);sx.stroke();const hg=sx.createRadialGradient(s.x,s.y,0,s.x,s.y,5);hg.addColorStop(0,`rgba(255,255,255,${a*0.9})`);hg.addColorStop(1,`rgba(${cr},${cg},${cb},0)`);sx.fillStyle=hg;sx.beginPath();sx.arc(s.x,s.y,5,0,Math.PI*2);sx.fill();return true;});afRef.current=requestAnimationFrame(go);};afRef.current=requestAnimationFrame(go);return()=>{cancelAnimationFrame(afRef.current);window.removeEventListener("resize",rs);window.removeEventListener("mousemove",mm);};
  },[init]);

  const b=CURRENT_BUDDY;
  const ringR=40,ringC=2*Math.PI*ringR,ringOff=ringC*(1-b.compatibility/100);

  return(
    <div style={{width:"100%",height:"100vh",overflow:"hidden",fontFamily:"'Inter',-apple-system,BlinkMacSystemFont,sans-serif",display:"flex",flexDirection:"column",position:"relative"}}>
      {/* BG */}
      <div style={{position:"fixed",inset:0,background:"radial-gradient(ellipse at 50% 50%,#0c081a 0%,#070412 35%,#03010a 70%,#000005 100%)",zIndex:0}}>
        {NEBULAE.map((n,i)=><div key={i} className={`dp-n-${i}`} style={{position:"absolute",left:n.x,top:n.y,width:n.s,height:n.s,transform:"translate(-50%,-50%)",background:`radial-gradient(circle,${n.c1} 0%,${n.c2} 40%,transparent 70%)`,filter:`blur(${n.b}px)`,pointerEvents:"none"}}/>)}
        <canvas ref={mkRef} style={{position:"absolute",inset:0,pointerEvents:"none",mixBlendMode:"screen"}}/>
        <canvas ref={scRef} style={{position:"absolute",inset:0,pointerEvents:"none"}}/>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at center,transparent 30%,rgba(3,1,10,0.5) 70%,rgba(0,0,5,0.8) 100%)",pointerEvents:"none"}}/>
      </div>

      {/* APPBAR */}
      <header style={{position:"relative",zIndex:100,height:64,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",background:"rgba(255,255,255,0.03)",backdropFilter:"blur(40px) saturate(1.4)",WebkitBackdropFilter:"blur(40px) saturate(1.4)",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button className="dp-ib"><ArrowLeft size={20} strokeWidth={2}/></button>
          <Target size={20} color="#5EEAD4" strokeWidth={2}/>
          <span style={{fontSize:17,fontWeight:700,color:"#fff",letterSpacing:"-0.3px"}}>Dream Buddy</span>
        </div>
        <button className="dp-ib"><RefreshCw size={17} strokeWidth={2}/></button>
      </header>

      {/* CONTENT */}
      <main style={{flex:1,overflowY:"auto",overflowX:"hidden",zIndex:10,padding:"16px 16px 32px"}}>
        <div style={{maxWidth:480,margin:"0 auto"}}>

          {/* ── Current Buddy Card ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"0ms"}}>
            <div className="dp-g" style={{padding:20,marginBottom:16,border:"1px solid rgba(20,184,166,0.15)"}}>
              <div style={{display:"flex",gap:16,alignItems:"center",marginBottom:16}}>
                {/* Compatibility Ring */}
                <div style={{position:"relative",width:90,height:90,flexShrink:0}}>
                  <svg width={90} height={90} style={{transform:"rotate(-90deg)"}}>
                    <circle cx={45} cy={45} r={ringR} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={5}/>
                    <circle cx={45} cy={45} r={ringR} fill="none" stroke="#5EEAD4" strokeWidth={5} strokeLinecap="round"
                      strokeDasharray={ringC} strokeDashoffset={mounted?ringOff:ringC}
                      style={{transition:"stroke-dashoffset 1.5s cubic-bezier(0.16,1,0.3,1)",filter:"drop-shadow(0 0 6px rgba(94,234,212,0.4))"}}/>
                  </svg>
                  <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                    <div style={{width:52,height:52,borderRadius:16,background:`${b.color}18`,border:`2px solid ${b.color}30`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,fontWeight:700,color:b.color}}>{b.initial}</div>
                  </div>
                  {b.online&&<div style={{position:"absolute",bottom:8,right:8,width:12,height:12,borderRadius:"50%",background:"#5DE5A8",border:"3px solid #0c081a",boxShadow:"0 0 8px rgba(93,229,168,0.5)"}}/>}
                </div>
                <div style={{flex:1}}>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                    <span style={{fontSize:18,fontWeight:700,color:"#fff"}}>{b.name}</span>
                    <span style={{padding:"2px 8px",borderRadius:8,background:"rgba(20,184,166,0.1)",fontSize:11,fontWeight:600,color:"#5EEAD4"}}>Your Buddy</span>
                  </div>
                  <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginBottom:6}}>Paired {b.joinedDate}</div>
                  <div style={{display:"flex",alignItems:"center",gap:4}}>
                    <Heart size={14} color="#F69A9A" strokeWidth={2.5}/>
                    <span style={{fontSize:14,fontWeight:700,color:"#5EEAD4"}}>{b.compatibility}% Match</span>
                  </div>
                </div>
              </div>

              {/* Stats comparison */}
              <div style={{display:"flex",gap:8,marginBottom:16}}>
                {[
                  {label:"Level",me:ME.level,them:b.level,Icon:Star,color:"#FCD34D"},
                  {label:"Streak",me:ME.streak,them:b.streak,Icon:Flame,color:"#F69A9A"},
                  {label:"XP",me:ME.xp,them:b.xp,Icon:Zap,color:"#5DE5A8"},
                ].map(({label,me,them,Icon:I,color},i)=>(
                  <div key={i} style={{flex:1,padding:"10px 8px",borderRadius:12,background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.05)",textAlign:"center"}}>
                    <I size={14} color={color} strokeWidth={2} style={{marginBottom:4}}/>
                    <div style={{fontSize:12,fontWeight:600,color:"#fff"}}>{typeof me==="number"&&me>999?`${(me/1000).toFixed(1)}k`:me}</div>
                    <div style={{fontSize:9,color:"rgba(255,255,255,0.5)",marginBottom:4}}>You</div>
                    <div style={{height:1,background:"rgba(255,255,255,0.06)",margin:"0 8px 4px"}}/>
                    <div style={{fontSize:12,fontWeight:600,color:b.color}}>{typeof them==="number"&&them>999?`${(them/1000).toFixed(1)}k`:them}</div>
                    <div style={{fontSize:9,color:"rgba(255,255,255,0.5)"}}>{b.name}</div>
                  </div>
                ))}
              </div>

              {/* Shared dreams */}
              <div style={{marginBottom:14}}>
                <div style={{fontSize:11,fontWeight:600,color:"rgba(255,255,255,0.5)",textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:6}}>Shared Dreams</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                  {b.sharedDreams.map((d,i)=>(
                    <span key={i} style={{padding:"5px 10px",borderRadius:10,background:"rgba(20,184,166,0.08)",border:"1px solid rgba(20,184,166,0.12)",fontSize:12,fontWeight:500,color:"#5EEAD4"}}>{d}</span>
                  ))}
                  {b.sharedCategories.map((c,i)=>{
                    const CI=CAT_ICONS[c]||Target;const cc=CAT_COLORS[c]||"#C4B5FD";
                    return <span key={`c${i}`} style={{padding:"5px 10px",borderRadius:10,background:`${cc}10`,border:`1px solid ${cc}18`,fontSize:12,fontWeight:500,color:cc,display:"flex",alignItems:"center",gap:4}}><CI size={11} strokeWidth={2.5}/>{c}</span>;
                  })}
                </div>
              </div>

              {/* Action buttons */}
              <div style={{display:"flex",gap:8}}>
                <button style={{flex:1,padding:"11px 0",borderRadius:14,border:"none",background:"linear-gradient(135deg,#14B8A6,#0D9488)",color:"#fff",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:"0 4px 16px rgba(20,184,166,0.25)",transition:"all 0.2s"}}
                  onMouseEnter={e=>e.currentTarget.style.transform="translateY(-1px)"}
                  onMouseLeave={e=>e.currentTarget.style.transform="translateY(0)"}>
                  <MessageCircle size={16} strokeWidth={2}/>Chat
                </button>
                <button onClick={()=>setEncourage(true)} style={{flex:1,padding:"11px 0",borderRadius:14,border:"1px solid rgba(246,154,154,0.2)",background:"rgba(246,154,154,0.08)",color:"#F69A9A",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:8,transition:"all 0.2s"}}
                  onMouseEnter={e=>e.currentTarget.style.background="rgba(246,154,154,0.15)"}
                  onMouseLeave={e=>e.currentTarget.style.background="rgba(246,154,154,0.08)"}>
                  <Heart size={16} strokeWidth={2}/>Encourage
                </button>
              </div>
            </div>
          </div>

          {/* ── Suggested Buddies ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"150ms"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}>
                <Sparkles size={15} color="#C4B5FD" strokeWidth={2.5}/>
                <span style={{fontSize:15,fontWeight:700,color:"#fff"}}>Suggested Matches</span>
              </div>
              <span style={{fontSize:12,color:"rgba(255,255,255,0.5)"}}>{SUGGESTIONS.length} found</span>
            </div>
          </div>

          {SUGGESTIONS.map((s,i)=>{
            const isSent=sent[s.id];
            return(
              <div key={s.id} className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${230+i*80}ms`}}>
                <div className="dp-g dp-gh" style={{padding:16,marginBottom:10,cursor:"pointer"}} onClick={()=>setSelectedProfile(s)}>
                  <div style={{display:"flex",gap:14,alignItems:"flex-start"}}>
                    {/* Avatar + score */}
                    <div style={{position:"relative",flexShrink:0}}>
                      <div style={{width:50,height:50,borderRadius:16,background:`${s.color}15`,border:`2px solid ${s.color}25`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,fontWeight:700,color:s.color}}>{s.initial}</div>
                      <div style={{position:"absolute",bottom:-4,left:"50%",transform:"translateX(-50%)",padding:"1px 6px",borderRadius:6,background:"rgba(12,8,26,0.9)",border:"1px solid rgba(93,229,168,0.25)",fontSize:10,fontWeight:700,color:"#5DE5A8",whiteSpace:"nowrap"}}>{s.compatibility}%</div>
                    </div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:2}}>
                        <span style={{fontSize:15,fontWeight:600,color:"#fff"}}>{s.name}</span>
                        <span style={{fontSize:11,color:"rgba(255,255,255,0.5)"}}>Lv.{s.level}</span>
                        {isSent&&<span style={{padding:"2px 7px",borderRadius:6,background:"rgba(93,229,168,0.1)",fontSize:10,fontWeight:600,color:"#5DE5A8"}}>Sent ✓</span>}
                      </div>
                      <div style={{fontSize:12,color:"rgba(255,255,255,0.7)",marginBottom:8,lineHeight:1.4}}>{s.bio}</div>
                      {/* Shared */}
                      <div style={{display:"flex",flexWrap:"wrap",gap:4,marginBottom:10}}>
                        {s.sharedDreams.map((d,j)=>(
                          <span key={j} style={{padding:"3px 8px",borderRadius:8,background:"rgba(20,184,166,0.08)",fontSize:11,fontWeight:500,color:"#5EEAD4"}}>{d}</span>
                        ))}
                        {s.sharedCategories.map((c,j)=>{
                          const cc=CAT_COLORS[c]||"#C4B5FD";
                          return <span key={`c${j}`} style={{padding:"3px 8px",borderRadius:8,background:`${cc}10`,fontSize:11,fontWeight:500,color:cc}}>{c}</span>;
                        })}
                      </div>
                      {/* Stats row */}
                      <div style={{display:"flex",alignItems:"center",gap:12,fontSize:11,color:"rgba(255,255,255,0.5)"}}>
                        <span style={{display:"flex",alignItems:"center",gap:3}}><Flame size={12} color="#F69A9A" strokeWidth={2}/>{s.streak}d streak</span>
                        <span style={{display:"flex",alignItems:"center",gap:3}}><Star size={12} color="#FCD34D" strokeWidth={2}/>Lv.{s.level}</span>
                        <span style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:3,color:"#C4B5FD",fontSize:12,fontWeight:500}}>View Profile<ChevronRight size={14} strokeWidth={2}/></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {/* ── How it works ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${230+SUGGESTIONS.length*80+80}ms`}}>
            <div className="dp-g" style={{padding:20,marginTop:8}}>
              <div style={{fontSize:14,fontWeight:600,color:"#fff",marginBottom:12}}>How Buddy Matching Works</div>
              {[
                {icon:Target,color:"#5EEAD4",title:"Shared Dreams",desc:"We match you with people who have similar goals and dream categories"},
                {icon:Star,color:"#FCD34D",title:"Similar Level",desc:"Buddies are close to your experience level for balanced motivation"},
                {icon:Heart,color:"#F69A9A",title:"Mutual Support",desc:"Send encouragements, share progress, and keep each other accountable"},
              ].map(({icon:I,color,title,desc},i)=>(
                <div key={i} style={{display:"flex",gap:12,marginBottom:i<2?14:0}}>
                  <div style={{width:36,height:36,borderRadius:12,flexShrink:0,background:`${color}10`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                    <I size={18} color={color} strokeWidth={2}/>
                  </div>
                  <div>
                    <div style={{fontSize:13,fontWeight:600,color:"#fff",marginBottom:2}}>{title}</div>
                    <div style={{fontSize:12,color:"rgba(255,255,255,0.7)",lineHeight:1.4}}>{desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </main>

      {/* ═══ PROFILE DETAIL PANEL ═══ */}
      {selectedProfile&&(()=>{
        const s=selectedProfile;const isSent=sent[s.id];
        const sRingR=44,sRingC=2*Math.PI*sRingR,sRingOff=sRingC*(1-s.compatibility/100);
        return(
          <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",flexDirection:"column"}}>
            <div onClick={()=>setSelectedProfile(null)} style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.5)",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)"}}/>
            <div style={{position:"absolute",top:0,right:0,bottom:0,width:"100%",maxWidth:420,background:"rgba(12,8,26,0.97)",backdropFilter:"blur(40px)",WebkitBackdropFilter:"blur(40px)",borderLeft:"1px solid rgba(255,255,255,0.06)",display:"flex",flexDirection:"column",animation:"dpSI 0.3s cubic-bezier(0.16,1,0.3,1)",overflowY:"auto"}}>
              
              {/* Header */}
              <div style={{padding:"16px",borderBottom:"1px solid rgba(255,255,255,0.06)",display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
                <span style={{fontSize:16,fontWeight:600,color:"#fff"}}>Profile</span>
                <button className="dp-ib" style={{width:34,height:34}} onClick={()=>setSelectedProfile(null)}><X size={16} strokeWidth={2}/></button>
              </div>

              {/* Profile hero */}
              <div style={{padding:"28px 20px 20px",textAlign:"center"}}>
                {/* Compat ring + avatar */}
                <div style={{position:"relative",width:100,height:100,margin:"0 auto 16px"}}>
                  <svg width={100} height={100} style={{transform:"rotate(-90deg)"}}>
                    <circle cx={50} cy={50} r={sRingR} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={5}/>
                    <circle cx={50} cy={50} r={sRingR} fill="none" stroke="#5EEAD4" strokeWidth={5} strokeLinecap="round"
                      strokeDasharray={sRingC} strokeDashoffset={sRingOff}
                      style={{transition:"stroke-dashoffset 1s cubic-bezier(0.16,1,0.3,1)",filter:"drop-shadow(0 0 8px rgba(94,234,212,0.4))"}}/>
                  </svg>
                  <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center"}}>
                    <div style={{width:62,height:62,borderRadius:20,background:`${s.color}18`,border:`2px solid ${s.color}30`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,fontWeight:700,color:s.color}}>{s.initial}</div>
                  </div>
                </div>
                <div style={{fontSize:20,fontWeight:700,color:"#fff",marginBottom:4}}>{s.name}</div>
                <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginBottom:6}}>{s.bio}</div>
                <div style={{display:"inline-flex",alignItems:"center",gap:5,padding:"4px 12px",borderRadius:10,background:"rgba(94,234,212,0.08)",border:"1px solid rgba(94,234,212,0.12)"}}>
                  <Heart size={13} color="#5EEAD4" strokeWidth={2.5}/>
                  <span style={{fontSize:14,fontWeight:700,color:"#5EEAD4"}}>{s.compatibility}% Match</span>
                </div>
                <div style={{fontSize:11,color:"rgba(255,255,255,0.5)",marginTop:6}}>Joined {s.joined}{s.mutualFriends>0?` · ${s.mutualFriends} mutual friend${s.mutualFriends>1?"s":""}`:""}</div>
              </div>

              {/* Stats */}
              <div style={{display:"flex",gap:8,padding:"0 20px",marginBottom:18}}>
                {[
                  {Icon:Star,val:s.level,label:"Level",color:"#FCD34D"},
                  {Icon:Zap,val:s.xp>999?`${(s.xp/1000).toFixed(1)}k`:s.xp,label:"XP",color:"#5DE5A8"},
                  {Icon:Flame,val:s.streak,label:"Streak",color:"#F69A9A"},
                ].map(({Icon:I,val,label,color},i)=>(
                  <div key={i} style={{flex:1,padding:"12px 8px",borderRadius:14,background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.05)",textAlign:"center"}}>
                    <I size={16} color={color} strokeWidth={2} style={{marginBottom:4}}/>
                    <div style={{fontSize:16,fontWeight:700,color:"#fff"}}>{val}</div>
                    <div style={{fontSize:10,color:"rgba(255,255,255,0.5)"}}>{label}</div>
                  </div>
                ))}
              </div>

              {/* Dreams */}
              <div style={{padding:"0 20px",marginBottom:18}}>
                <div style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.5)",textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:8}}>Dreams</div>
                {s.dreams.map((d,i)=>{
                  const isShared=s.sharedDreams.includes(d);
                  return(
                    <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",marginBottom:4,borderRadius:12,background:isShared?"rgba(20,184,166,0.06)":"rgba(255,255,255,0.02)",border:isShared?"1px solid rgba(20,184,166,0.1)":"1px solid rgba(255,255,255,0.04)"}}>
                      <Target size={14} color={isShared?"#5EEAD4":"rgba(255,255,255,0.4)"} strokeWidth={2}/>
                      <span style={{fontSize:13,color:isShared?"#5EEAD4":"rgba(255,255,255,0.85)",fontWeight:isShared?600:400}}>{d}</span>
                      {isShared&&<span style={{marginLeft:"auto",fontSize:10,fontWeight:600,color:"#5EEAD4",background:"rgba(20,184,166,0.1)",padding:"2px 6px",borderRadius:6}}>Shared!</span>}
                    </div>
                  );
                })}
              </div>

              {/* Categories */}
              <div style={{padding:"0 20px",marginBottom:18}}>
                <div style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.5)",textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:8}}>Interests</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                  {s.sharedCategories.map((c,i)=>{
                    const CI=CAT_ICONS[c]||Target;const cc=CAT_COLORS[c]||"#C4B5FD";
                    return <span key={i} style={{padding:"6px 12px",borderRadius:10,background:`${cc}10`,border:`1px solid ${cc}18`,fontSize:12,fontWeight:500,color:cc,display:"flex",alignItems:"center",gap:5}}><CI size={13} strokeWidth={2}/>{c[0].toUpperCase()+c.slice(1)}</span>;
                  })}
                </div>
              </div>

              {/* Achievements */}
              <div style={{padding:"0 20px",marginBottom:24}}>
                <div style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.5)",textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:8}}>Achievements</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                  {s.achievements.map((a,i)=>(
                    <span key={i} style={{padding:"5px 10px",borderRadius:10,background:"rgba(252,211,77,0.06)",border:"1px solid rgba(252,211,77,0.1)",fontSize:12,fontWeight:500,color:"#FCD34D",display:"flex",alignItems:"center",gap:4}}>
                      <Trophy size={11} strokeWidth={2.5}/>{a}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action buttons (sticky bottom) */}
              <div style={{padding:"16px 20px",borderTop:"1px solid rgba(255,255,255,0.06)",background:"rgba(12,8,26,0.95)",marginTop:"auto",flexShrink:0}}>
                {isSent?(
                  <div style={{padding:"14px 0",borderRadius:14,background:"rgba(93,229,168,0.08)",border:"1px solid rgba(93,229,168,0.15)",textAlign:"center",display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
                    <Check size={18} color="#5DE5A8" strokeWidth={2.5}/>
                    <span style={{fontSize:15,fontWeight:600,color:"#5DE5A8"}}>Buddy Request Sent!</span>
                  </div>
                ):(
                  <div style={{display:"flex",gap:8}}>
                    <button onClick={()=>setSelectedProfile(null)} style={{flex:1,padding:"13px 0",borderRadius:14,border:"1px solid rgba(255,255,255,0.08)",background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.85)",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit",transition:"all 0.2s"}}
                      onMouseEnter={e=>e.currentTarget.style.background="rgba(255,255,255,0.08)"}
                      onMouseLeave={e=>e.currentTarget.style.background="rgba(255,255,255,0.04)"}>
                      Maybe Later
                    </button>
                    <button onClick={(e)=>{e.stopPropagation();sendRequest(s.id);}} style={{flex:1.2,padding:"13px 0",borderRadius:14,border:"none",background:"linear-gradient(135deg,#8B5CF6,#6D28D9)",color:"#fff",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:"0 4px 16px rgba(139,92,246,0.3)",transition:"all 0.2s"}}
                      onMouseEnter={e=>e.currentTarget.style.transform="translateY(-1px)"}
                      onMouseLeave={e=>e.currentTarget.style.transform="translateY(0)"}>
                      <UserPlus size={16} strokeWidth={2}/>Send Request
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* ═══ ENCOURAGE MODAL ═══ */}
      {encourage&&(
        <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div onClick={()=>setEncourage(false)} style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.6)",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)"}}/>
          <div style={{position:"relative",width:"90%",maxWidth:380,background:"rgba(12,8,26,0.97)",backdropFilter:"blur(40px)",WebkitBackdropFilter:"blur(40px)",borderRadius:22,border:"1px solid rgba(255,255,255,0.08)",boxShadow:"0 20px 60px rgba(0,0,0,0.5)",padding:24,animation:"dpFS 0.25s ease-out"}}>
            {sentEncourage?(
              <div style={{textAlign:"center",padding:"20px 0"}}>
                <div style={{width:56,height:56,borderRadius:18,margin:"0 auto 14px",background:"rgba(93,229,168,0.1)",display:"flex",alignItems:"center",justifyContent:"center"}}>
                  <Check size={28} color="#5DE5A8" strokeWidth={2.5}/>
                </div>
                <div style={{fontSize:16,fontWeight:600,color:"#fff"}}>Encouragement Sent!</div>
                <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginTop:4}}>{b.name} will appreciate it</div>
              </div>
            ):(
              <>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <Heart size={18} color="#F69A9A" strokeWidth={2}/>
                    <span style={{fontSize:16,fontWeight:600,color:"#fff"}}>Encourage {b.name}</span>
                  </div>
                  <button onClick={()=>setEncourage(false)} className="dp-ib" style={{width:32,height:32}}><X size={16} strokeWidth={2}/></button>
                </div>
                {/* Preset messages */}
                <div style={{display:"flex",flexDirection:"column",gap:6,marginBottom:14}}>
                  {ENCOURAGE_PRESETS.map((p,i)=>(
                    <button key={i} onClick={()=>setEncourageMsg(p)} style={{padding:"10px 14px",borderRadius:12,border:encourageMsg===p?"1px solid rgba(246,154,154,0.25)":"1px solid rgba(255,255,255,0.06)",background:encourageMsg===p?"rgba(246,154,154,0.08)":"rgba(255,255,255,0.03)",color:encourageMsg===p?"#fff":"rgba(255,255,255,0.7)",fontSize:13,textAlign:"left",cursor:"pointer",fontFamily:"inherit",transition:"all 0.15s"}}>{p}</button>
                  ))}
                </div>
                {/* Custom input */}
                <div style={{display:"flex",gap:8}}>
                  <input value={encourageMsg} onChange={e=>setEncourageMsg(e.target.value)} style={{flex:1,padding:"10px 14px",borderRadius:12,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.06)",color:"#fff",fontSize:13,fontFamily:"inherit",outline:"none"}}/>
                  <button onClick={sendEncourage} style={{padding:"10px 18px",borderRadius:12,border:"none",background:"linear-gradient(135deg,#F69A9A,#EC4899)",color:"#fff",fontWeight:600,fontSize:13,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:6,boxShadow:"0 4px 12px rgba(246,154,154,0.25)"}}>
                    <Send size={14} strokeWidth={2}/>Send
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        *{margin:0;padding:0;box-sizing:border-box;}::-webkit-scrollbar{width:0;}
        input::placeholder{color:rgba(255,255,255,0.35);}
        .dp-ib{width:40px;height:40px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.05);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;}
        .dp-ib:hover{background:rgba(255,255,255,0.1);}
        .dp-g{background:rgba(255,255,255,0.04);backdrop-filter:blur(40px) saturate(1.3);-webkit-backdrop-filter:blur(40px) saturate(1.3);border-radius:18px;border:1px solid rgba(255,255,255,0.06);box-shadow:0 4px 24px rgba(0,0,0,0.12),inset 0 1px 0 rgba(255,255,255,0.03);transition:all 0.3s cubic-bezier(0.16,1,0.3,1);}
        .dp-gh:hover{background:rgba(255,255,255,0.07);border-color:rgba(255,255,255,0.1);box-shadow:0 8px 32px rgba(0,0,0,0.18),inset 0 1px 0 rgba(255,255,255,0.05);transform:translateY(-2px);}
        .dp-a{opacity:0;transform:translateY(16px);transition:opacity 0.5s cubic-bezier(0.16,1,0.3,1),transform 0.5s cubic-bezier(0.16,1,0.3,1);}
        .dp-a.dp-s{opacity:1;transform:translateY(0);}
        @keyframes dpFS{from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);}}
        @keyframes dpSI{from{transform:translateX(100%);}to{transform:translateX(0);}}
        ${NEBULAE.map((n,i)=>`
          .dp-n-${i}{animation:dpNF${i} ${n.sp}s ease-in-out infinite;}
          @keyframes dpNF${i}{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:1;}33%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1+Math.random()*0.06});opacity:${0.8+Math.random()*0.2};}66%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1-Math.random()*0.04});opacity:${0.85+Math.random()*0.15};}}
        `).join("")}
      `}</style>
    </div>
  );
}
