import { useState, useEffect, useRef, useCallback } from "react";
import {
  ArrowLeft, Settings, Star, Zap, Flame, ChevronRight,
  MessageCircle, Crown, ShoppingBag, Trophy, Bell, Eye,
  Calendar, LogOut, Heart, Briefcase, Brain, Palette,
  Edit3, Shield, Award, Target, TrendingUp
} from "lucide-react";

/* ═══════════════════════════════════════════════════════════════════
 * DreamPlanner — Profile Screen v1
 *
 * From Flutter:
 * - Avatar with gradient glow ring
 * - Name, email, premium badge
 * - Level / XP / Streak stats
 * - Skill levels with progress bars (Health, Career, Relations, Growth)
 * - Menu tiles (Conversations, Subscription, Store, etc.)
 * - Sign out
 *
 * UX Upgrades:
 * - SVG level ring around avatar
 * - XP progress to next level
 * - Animated skill bars on mount
 * - Achievement badges row
 * - Edit profile button overlay on avatar
 * - All 9:1+ contrast
 * ═══════════════════════════════════════════════════════════════════ */

const USER = {
  name:"Stephane", initial:"S", email:"stephane@rhematek.com",
  level:12, xp:2450, xpToNext:3000, streak:7,
  isPremium:true, subscription:"PRO", renewDate:"Mar 15, 2026",
  joined:"Nov 2025",
};

const SKILLS = [
  { label:"Health & Fitness", level:8, xp:780, color:"#5DE5A8", Icon:Heart },
  { label:"Career & Work", level:11, xp:420, color:"#C4B5FD", Icon:Briefcase },
  { label:"Relationships", level:6, xp:550, color:"#F69A9A", Icon:Heart },
  { label:"Personal Growth", level:9, xp:310, color:"#FCD34D", Icon:Brain },
  { label:"Hobbies & Creativity", level:5, xp:680, color:"#5EEAD4", Icon:Palette },
];

const ACHIEVEMENTS = [
  { label:"7-Day Streak", icon:Flame, color:"#F69A9A" },
  { label:"Level 10", icon:Star, color:"#FCD34D" },
  { label:"Dream Master", icon:Target, color:"#C4B5FD" },
  { label:"50 Tasks", icon:Award, color:"#5DE5A8" },
  { label:"Social Butterfly", icon:Heart, color:"#5EEAD4" },
];

const MENU = [
  { icon:MessageCircle, label:"Conversations", color:"#C4B5FD" },
  { icon:Crown, label:"Subscription", color:"#FCD34D" },
  { icon:ShoppingBag, label:"Store", color:"#5EEAD4" },
  { icon:Trophy, label:"Leaderboard", color:"#F69A9A" },
  { icon:Bell, label:"Notifications", color:"#C4B5FD", badge:3 },
  { icon:Eye, label:"Vision Board", color:"#5DE5A8" },
  { icon:Calendar, label:"Calendar Sync", color:"#93C5FD" },
];

// ─── COSMIC BG ───────────────────────────────────────────────────
const STAR_LAYERS=[{count:300,sizeRange:[0.3,1.0],opacity:0.35,parallax:0.008},{count:200,sizeRange:[0.8,1.8],opacity:0.55,parallax:0.02},{count:100,sizeRange:[1.2,2.8],opacity:0.85,parallax:0.045}];
const STAR_COLORS=[[230,225,255],[200,210,255],[255,220,200],[180,200,255],[255,200,220],[220,240,255],[255,240,230]];
const SMOKE_CYCLE=[[255,120,160],[255,80,180],[220,60,220],[180,70,255],[130,80,255],[80,100,255],[60,140,255],[80,180,240],[100,200,220],[160,120,255],[220,100,200],[255,120,160]];
const SMOKE_CONFIGS=[{size:350,opacity:0.09,speedMult:1.0,colorSpeed:0.015,colorOffset:0,pfx:[0.13,0.31],pfy:[0.17,0.23],pax:[0.38,0.12],pay:[0.35,0.10]},{size:300,opacity:0.07,speedMult:1.3,colorSpeed:0.02,colorOffset:3,pfx:[0.19,0.41],pfy:[0.23,0.29],pax:[0.35,0.15],pay:[0.32,0.08]},{size:250,opacity:0.06,speedMult:1.7,colorSpeed:0.025,colorOffset:6,pfx:[0.29,0.53],pfy:[0.31,0.37],pax:[0.33,0.18],pay:[0.30,0.12]},{size:420,opacity:0.05,speedMult:0.6,colorSpeed:0.01,colorOffset:9,pfx:[0.07,0.19],pfy:[0.11,0.17],pax:[0.40,0.10],pay:[0.38,0.14]},{size:280,opacity:0.065,speedMult:1.1,colorSpeed:0.018,colorOffset:4.5,pfx:[0.17,0.37],pfy:[0.21,0.43],pax:[0.36,0.14],pay:[0.33,0.11]}];
const NEBULAE=[{x:"8%",y:"15%",c1:"rgba(80,120,255,0.06)",c2:"rgba(60,80,200,0.015)",s:500,b:90,sp:35},{x:"88%",y:"20%",c1:"rgba(100,140,255,0.05)",c2:"rgba(70,100,220,0.015)",s:450,b:85,sp:28},{x:"12%",y:"75%",c1:"rgba(140,80,220,0.06)",c2:"rgba(100,50,180,0.015)",s:430,b:80,sp:32},{x:"82%",y:"78%",c1:"rgba(120,70,200,0.05)",c2:"rgba(90,40,170,0.015)",s:410,b:85,sp:26},{x:"50%",y:"92%",c1:"rgba(60,100,200,0.04)",c2:"rgba(40,70,160,0.01)",s:550,b:100,sp:40},{x:"50%",y:"5%",c1:"rgba(90,60,180,0.04)",c2:"rgba(70,40,150,0.01)",s:500,b:90,sp:22}];
function lerp(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}function smokeCol(t){const l=SMOKE_CYCLE.length,i=t%l,f=Math.floor(i);return lerp(SMOKE_CYCLE[f%l],SMOKE_CYCLE[(f+1)%l],i-f);}function mkStars(layer,w,h){const s=[];for(let i=0;i<layer.count;i++)s.push({x:Math.random()*w,y:Math.random()*h,sz:layer.sizeRange[0]+Math.random()*(layer.sizeRange[1]-layer.sizeRange[0]),op:layer.opacity*(0.4+Math.random()*0.6),ts:0.3+Math.random()*2.5,to:Math.random()*Math.PI*2,c:STAR_COLORS[Math.floor(Math.random()*STAR_COLORS.length)]});return s;}function mkShoot(w,h){const e=Math.floor(Math.random()*3);let x,y,a;if(e===0){x=Math.random()*w;y=-20;a=Math.PI*0.3+Math.random()*Math.PI*0.4;}else if(e===1){x=-20;y=Math.random()*h*0.6;a=Math.PI*0.05+Math.random()*Math.PI*0.3;}else{x=w*0.5+Math.random()*w*0.5;y=-20;a=Math.PI*0.4+Math.random()*Math.PI*0.3;}const sp=5+Math.random()*8;return{x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,ln:80+Math.random()*140,life:1,dc:0.005+Math.random()*0.01,sz:0.8+Math.random()*1.8,w:Math.random()};}

// ═══════════════════════════════════════════════════════════════════
export default function ProfileScreen(){
  const[mounted,setMounted]=useState(false);
  const scRef=useRef(null);const mkRef=useRef(null);
  const stRef=useRef([]);const shRef=useRef([]);
  const drRef=useRef({x:0,y:0,a:0});const msRef=useRef({x:0,y:0,tx:0,ty:0});
  const tRef=useRef(0);const szRef=useRef({w:0,h:0});const afRef=useRef(null);

  useEffect(()=>{setTimeout(()=>setMounted(true),100);},[]);

  const init=useCallback((w,h)=>{stRef.current=STAR_LAYERS.map(l=>({c:l,s:mkStars(l,w*1.3,h*1.3)}));},[]);
  useEffect(()=>{const sc=scRef.current,mk=mkRef.current;if(!sc||!mk)return;const sx=sc.getContext("2d"),mx=mk.getContext("2d"),d=window.devicePixelRatio||1;const rs=()=>{const w=window.innerWidth,h=window.innerHeight;[sc,mk].forEach(c=>{c.width=w*d;c.height=h*d;c.style.width=w+"px";c.style.height=h+"px";});sx.setTransform(d,0,0,d,0,0);mx.setTransform(d,0,0,d,0,0);szRef.current={w,h};init(w,h);};rs();window.addEventListener("resize",rs);const mm=e=>{const cx=window.innerWidth/2,cy=window.innerHeight/2;msRef.current.tx=(e.clientX-cx)/cx;msRef.current.ty=(e.clientY-cy)/cy;};window.addEventListener("mousemove",mm);const go=()=>{const{w,h}=szRef.current;tRef.current+=0.016;const t=tRef.current;const dr=drRef.current;dr.a+=0.0008;dr.x=Math.sin(dr.a*0.7)*0.15+Math.sin(dr.a*1.3)*0.08;dr.y=Math.cos(dr.a*0.5)*0.12+Math.cos(dr.a*1.1)*0.06;const m=msRef.current;m.x+=(m.tx-m.x)*0.03;m.y+=(m.ty-m.y)*0.03;const mvx=dr.x+m.x*0.4,mvy=dr.y+m.y*0.4;mx.clearRect(0,0,w,h);SMOKE_CONFIGS.forEach(c=>{const st=t*c.speedMult;const px=0.5+c.pax[0]*Math.sin(st*c.pfx[0])+c.pax[1]*Math.sin(st*c.pfx[1]);const py=0.5+c.pay[0]*Math.cos(st*c.pfy[0])+c.pay[1]*Math.cos(st*c.pfy[1]);const x=px*w,y=py*h;const[r,g,b]=smokeCol(c.colorOffset+t*c.colorSpeed);const gr=mx.createRadialGradient(x,y,0,x,y,c.size);gr.addColorStop(0,`rgba(${r|0},${g|0},${b|0},${c.opacity})`);gr.addColorStop(0.3,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.6})`);gr.addColorStop(0.6,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.2})`);gr.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=gr;mx.beginPath();mx.arc(x,y,c.size,0,Math.PI*2);mx.fill();const ig=mx.createRadialGradient(x,y,0,x,y,c.size*0.4);ig.addColorStop(0,`rgba(${Math.min(r+40,255)|0},${Math.min(g+30,255)|0},${Math.min(b+30,255)|0},${c.opacity*0.8})`);ig.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=ig;mx.beginPath();mx.arc(x,y,c.size*0.4,0,Math.PI*2);mx.fill();});sx.clearRect(0,0,w,h);stRef.current.forEach(({c:cfg,s:stars})=>{const ox=mvx*cfg.parallax*w+(w*0.15),oy=mvy*cfg.parallax*h+(h*0.15),fw=w*1.3,fh=h*1.3;stars.forEach(s=>{const tw=Math.sin(t*s.ts+s.to)*0.35+0.65,a=s.op*tw,px=((s.x-ox)%fw+fw)%fw-w*0.15,py=((s.y-oy)%fh+fh)%fh-h*0.15;if(px<-10||px>w+10||py<-10||py>h+10)return;const[r,g,b]=s.c;if(s.sz>1.5){const gr=sx.createRadialGradient(px,py,0,px,py,s.sz*4);gr.addColorStop(0,`rgba(${r},${g},${b},${a*0.25})`);gr.addColorStop(1,`rgba(${r},${g},${b},0)`);sx.fillStyle=gr;sx.beginPath();sx.arc(px,py,s.sz*4,0,Math.PI*2);sx.fill();}if(s.sz>2.2){sx.strokeStyle=`rgba(${r},${g},${b},${a*0.15})`;sx.lineWidth=0.5;const fl=s.sz*6*tw;sx.beginPath();sx.moveTo(px-fl,py);sx.lineTo(px+fl,py);sx.moveTo(px,py-fl);sx.lineTo(px,py+fl);sx.stroke();}sx.fillStyle=`rgba(${r},${g},${b},${a})`;sx.beginPath();sx.arc(px,py,s.sz,0,Math.PI*2);sx.fill();});});if(Math.random()<0.025)shRef.current.push(mkShoot(w,h));if(Math.random()<0.003){for(let i=0;i<2+Math.floor(Math.random()*2);i++)shRef.current.push(mkShoot(w,h));}shRef.current=shRef.current.filter(s=>{s.x+=s.vx;s.y+=s.vy;s.life-=s.dc;if(s.life<=0)return false;const a=s.life*s.life,mg=Math.sqrt(s.vx*s.vx+s.vy*s.vy),dx=s.vx/mg,dy=s.vy/mg,tx=s.x-dx*s.ln*a,ty=s.y-dy*s.ln*a;const cr=s.w>0.5?255:200,cg=s.w>0.5?220:210,cb=s.w>0.5?200:255;const gr=sx.createLinearGradient(tx,ty,s.x,s.y);gr.addColorStop(0,`rgba(${cr},${cg},${cb},0)`);gr.addColorStop(0.5,`rgba(${cr},${cg},${cb},${a*0.25})`);gr.addColorStop(1,`rgba(255,255,255,${a*0.9})`);sx.strokeStyle=gr;sx.lineWidth=s.sz;sx.lineCap="round";sx.beginPath();sx.moveTo(tx,ty);sx.lineTo(s.x,s.y);sx.stroke();const hg=sx.createRadialGradient(s.x,s.y,0,s.x,s.y,5);hg.addColorStop(0,`rgba(255,255,255,${a*0.9})`);hg.addColorStop(1,`rgba(${cr},${cg},${cb},0)`);sx.fillStyle=hg;sx.beginPath();sx.arc(s.x,s.y,5,0,Math.PI*2);sx.fill();return true;});afRef.current=requestAnimationFrame(go);};afRef.current=requestAnimationFrame(go);return()=>{cancelAnimationFrame(afRef.current);window.removeEventListener("resize",rs);window.removeEventListener("mousemove",mm);};
  },[init]);

  const lvlProgress=USER.xp/USER.xpToNext;
  const ringR=48,ringC=2*Math.PI*ringR,ringOff=ringC*(1-lvlProgress);

  return(
    <div style={{width:"100%",height:"100vh",overflow:"hidden",fontFamily:"'Inter',-apple-system,BlinkMacSystemFont,sans-serif",display:"flex",flexDirection:"column",position:"relative"}}>
      <div style={{position:"fixed",inset:0,background:"radial-gradient(ellipse at 50% 50%,#0c081a 0%,#070412 35%,#03010a 70%,#000005 100%)",zIndex:0}}>
        {NEBULAE.map((n,i)=><div key={i} className={`dp-n-${i}`} style={{position:"absolute",left:n.x,top:n.y,width:n.s,height:n.s,transform:"translate(-50%,-50%)",background:`radial-gradient(circle,${n.c1} 0%,${n.c2} 40%,transparent 70%)`,filter:`blur(${n.b}px)`,pointerEvents:"none"}}/>)}
        <canvas ref={mkRef} style={{position:"absolute",inset:0,pointerEvents:"none",mixBlendMode:"screen"}}/>
        <canvas ref={scRef} style={{position:"absolute",inset:0,pointerEvents:"none"}}/>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at center,transparent 30%,rgba(3,1,10,0.5) 70%,rgba(0,0,5,0.8) 100%)",pointerEvents:"none"}}/>
      </div>

      {/* APPBAR */}
      <header style={{position:"relative",zIndex:100,height:64,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",background:"rgba(255,255,255,0.03)",backdropFilter:"blur(40px) saturate(1.4)",WebkitBackdropFilter:"blur(40px) saturate(1.4)",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button className="dp-ib"><ArrowLeft size={20} strokeWidth={2}/></button>
          <span style={{fontSize:17,fontWeight:700,color:"#fff",letterSpacing:"-0.3px"}}>Profile</span>
        </div>
        <button className="dp-ib"><Settings size={18} strokeWidth={2}/></button>
      </header>

      <main style={{flex:1,overflowY:"auto",overflowX:"hidden",zIndex:10,padding:"20px 16px 32px"}}>
        <div style={{maxWidth:480,margin:"0 auto"}}>

          {/* ── Profile Header ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"0ms"}}>
            <div className="dp-g" style={{padding:28,textAlign:"center",marginBottom:16}}>
              {/* Avatar with level ring */}
              <div style={{position:"relative",width:110,height:110,margin:"0 auto 16px"}}>
                <svg width={110} height={110} style={{transform:"rotate(-90deg)",position:"absolute",inset:0}}>
                  <circle cx={55} cy={55} r={ringR} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={4.5}/>
                  <circle cx={55} cy={55} r={ringR} fill="none" stroke="url(#lvlGrad)" strokeWidth={4.5} strokeLinecap="round"
                    strokeDasharray={ringC} strokeDashoffset={mounted?ringOff:ringC}
                    style={{transition:"stroke-dashoffset 1.5s cubic-bezier(0.16,1,0.3,1)",filter:"drop-shadow(0 0 8px rgba(139,92,246,0.4))"}}/>
                  <defs><linearGradient id="lvlGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#8B5CF6"/><stop offset="50%" stopColor="#C4B5FD"/><stop offset="100%" stopColor="#5DE5A8"/></linearGradient></defs>
                </svg>
                <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center"}}>
                  <div style={{width:80,height:80,borderRadius:26,background:"rgba(139,92,246,0.1)",border:"3px solid rgba(139,92,246,0.2)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,fontWeight:700,color:"#C4B5FD"}}>{USER.initial}</div>
                </div>
                {/* Edit overlay */}
                <button style={{position:"absolute",bottom:2,right:2,width:30,height:30,borderRadius:10,background:"rgba(139,92,246,0.3)",border:"2px solid rgba(139,92,246,0.4)",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",backdropFilter:"blur(10px)",WebkitBackdropFilter:"blur(10px)"}}>
                  <Edit3 size={13} strokeWidth={2.5}/>
                </button>
                {/* Level badge */}
                <div style={{position:"absolute",top:0,right:0,padding:"2px 8px",borderRadius:8,background:"linear-gradient(135deg,#8B5CF6,#6D28D9)",fontSize:11,fontWeight:700,color:"#fff",boxShadow:"0 2px 8px rgba(139,92,246,0.4)"}}>Lv.{USER.level}</div>
              </div>

              {/* Name + badge */}
              <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginBottom:4}}>
                <span style={{fontSize:22,fontWeight:700,color:"#fff"}}>{USER.name}</span>
                {USER.isPremium&&(
                  <span className="dp-shim" style={{padding:"3px 10px",borderRadius:10,background:"linear-gradient(135deg,rgba(252,211,77,0.15),rgba(252,211,77,0.08))",border:"1px solid rgba(252,211,77,0.25)",fontSize:11,fontWeight:700,color:"#FCD34D",display:"flex",alignItems:"center",gap:4}}>
                    <Crown size={12} strokeWidth={2.5}/>{USER.subscription}
                  </span>
                )}
              </div>
              <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",marginBottom:4}}>{USER.email}</div>
              {USER.isPremium&&<div style={{fontSize:11,color:"rgba(255,255,255,0.5)"}}>Renews {USER.renewDate}</div>}

              {/* XP Progress */}
              <div style={{marginTop:16,padding:"12px 16px",borderRadius:14,background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.05)"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                  <span style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.7)"}}>Level {USER.level} Progress</span>
                  <span style={{fontSize:12,fontWeight:600,color:"#C4B5FD"}}>{USER.xp} / {USER.xpToNext} XP</span>
                </div>
                <div style={{height:6,borderRadius:3,background:"rgba(255,255,255,0.06)",overflow:"hidden"}}>
                  <div className="dp-bar" style={{height:"100%",borderRadius:3,background:"linear-gradient(90deg,#8B5CF6,#C4B5FD,#5DE5A8)",width:mounted?`${lvlProgress*100}%`:"0%",transition:"width 1.2s cubic-bezier(0.16,1,0.3,1)",boxShadow:"0 0 8px rgba(139,92,246,0.4)"}}/>
                </div>
                <div style={{fontSize:11,color:"rgba(255,255,255,0.5)",marginTop:4}}>{USER.xpToNext-USER.xp} XP to Level {USER.level+1}</div>
              </div>
            </div>
          </div>

          {/* ── Stats Row ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"100ms"}}>
            <div style={{display:"flex",gap:8,marginBottom:16}}>
              {[
                {Icon:Star,val:USER.level,label:"Level",color:"#FCD34D"},
                {Icon:Zap,val:`${(USER.xp/1000).toFixed(1)}k`,label:"Total XP",color:"#5DE5A8"},
                {Icon:Flame,val:USER.streak,label:"Streak",color:"#F69A9A"},
                {Icon:TrendingUp,val:"#4",label:"Rank",color:"#C4B5FD"},
              ].map(({Icon:I,val,label,color},i)=>(
                <div key={i} className="dp-g" style={{flex:1,padding:"14px 8px",textAlign:"center"}}>
                  <I size={18} color={color} strokeWidth={2} style={{marginBottom:6,filter:`drop-shadow(0 0 6px ${color}40)`}}/>
                  <div style={{fontSize:18,fontWeight:700,color:"#fff"}}>{val}</div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,0.7)"}}>{label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* ── Skill Levels ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"200ms"}}>
            <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:10}}>
              <Shield size={15} color="#C4B5FD" strokeWidth={2.5}/>
              <span style={{fontSize:15,fontWeight:700,color:"#fff"}}>Skill Levels</span>
            </div>
            <div className="dp-g" style={{padding:16,marginBottom:16}}>
              {SKILLS.map((s,i)=>{
                const prog=s.xp/1000;
                return(
                  <div key={i} style={{marginBottom:i<SKILLS.length-1?14:0}}>
                    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:5}}>
                      <div style={{display:"flex",alignItems:"center",gap:6}}>
                        <s.Icon size={13} color={s.color} strokeWidth={2.5}/>
                        <span style={{fontSize:13,fontWeight:600,color:"#fff"}}>{s.label}</span>
                      </div>
                      <div style={{display:"flex",alignItems:"center",gap:8}}>
                        <span style={{padding:"2px 7px",borderRadius:6,background:`${s.color}15`,fontSize:10,fontWeight:700,color:s.color}}>Lv.{s.level}</span>
                        <span style={{fontSize:11,color:"rgba(255,255,255,0.5)"}}>{s.xp}/1000</span>
                      </div>
                    </div>
                    <div style={{height:5,borderRadius:3,background:"rgba(255,255,255,0.06)",overflow:"hidden"}}>
                      <div style={{height:"100%",borderRadius:3,background:`linear-gradient(90deg,${s.color}90,${s.color})`,width:mounted?`${prog*100}%`:"0%",transition:`width 1s cubic-bezier(0.16,1,0.3,1) ${200+i*100}ms`,boxShadow:`0 0 6px ${s.color}40`}}/>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── Achievements ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"300ms"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}>
                <Award size={15} color="#FCD34D" strokeWidth={2.5}/>
                <span style={{fontSize:15,fontWeight:700,color:"#fff"}}>Achievements</span>
              </div>
              <span style={{fontSize:12,color:"#C4B5FD",cursor:"pointer",fontWeight:500}}>See All</span>
            </div>
            <div style={{display:"flex",gap:8,overflowX:"auto",paddingBottom:8,marginBottom:12}}>
              {ACHIEVEMENTS.map((a,i)=>(
                <div key={i} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:6,minWidth:72}}>
                  <div style={{width:48,height:48,borderRadius:16,background:`${a.color}10`,border:`1px solid ${a.color}18`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                    <a.icon size={22} color={a.color} strokeWidth={1.8}/>
                  </div>
                  <span style={{fontSize:10,fontWeight:500,color:"rgba(255,255,255,0.7)",textAlign:"center",maxWidth:72}}>{a.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ── Menu Items ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"400ms"}}>
            {MENU.map((item,i)=>(
              <div key={i} className="dp-g dp-gh" style={{padding:"12px 16px",marginBottom:8,cursor:"pointer",display:"flex",alignItems:"center",gap:14}}>
                <div style={{width:38,height:38,borderRadius:12,background:`${item.color}10`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  <item.icon size={18} color={item.color} strokeWidth={2}/>
                </div>
                <span style={{flex:1,fontSize:14,fontWeight:500,color:"#fff"}}>{item.label}</span>
                {item.badge&&<span style={{padding:"2px 8px",borderRadius:8,background:"rgba(246,154,154,0.12)",fontSize:11,fontWeight:600,color:"#F69A9A"}}>{item.badge}</span>}
                <ChevronRight size={16} color="rgba(255,255,255,0.3)" strokeWidth={2}/>
              </div>
            ))}
          </div>

          {/* ── Sign Out ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"500ms"}}>
            <button style={{width:"100%",marginTop:8,padding:"14px 0",borderRadius:16,border:"1px solid rgba(246,154,154,0.15)",background:"rgba(246,154,154,0.06)",color:"#F69A9A",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:8,transition:"all 0.2s"}}
              onMouseEnter={e=>e.currentTarget.style.background="rgba(246,154,154,0.12)"}
              onMouseLeave={e=>e.currentTarget.style.background="rgba(246,154,154,0.06)"}>
              <LogOut size={16} strokeWidth={2}/>Sign Out
            </button>
          </div>

        </div>
      </main>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        *{margin:0;padding:0;box-sizing:border-box;}::-webkit-scrollbar{width:0;}
        .dp-ib{width:40px;height:40px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.05);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;}
        .dp-ib:hover{background:rgba(255,255,255,0.1);}
        .dp-g{background:rgba(255,255,255,0.04);backdrop-filter:blur(40px) saturate(1.3);-webkit-backdrop-filter:blur(40px) saturate(1.3);border-radius:18px;border:1px solid rgba(255,255,255,0.06);box-shadow:0 4px 24px rgba(0,0,0,0.12),inset 0 1px 0 rgba(255,255,255,0.03);transition:all 0.3s cubic-bezier(0.16,1,0.3,1);}
        .dp-gh:hover{background:rgba(255,255,255,0.07);border-color:rgba(255,255,255,0.1);box-shadow:0 8px 32px rgba(0,0,0,0.18),inset 0 1px 0 rgba(255,255,255,0.05);transform:translateY(-2px);}
        .dp-a{opacity:0;transform:translateY(16px);transition:opacity 0.5s cubic-bezier(0.16,1,0.3,1),transform 0.5s cubic-bezier(0.16,1,0.3,1);}
        .dp-a.dp-s{opacity:1;transform:translateY(0);}
        .dp-shim{animation:dpShim 3s ease-in-out infinite;}
        @keyframes dpShim{0%,100%{filter:brightness(1);}50%{filter:brightness(1.3);}}
        ${NEBULAE.map((n,i)=>`
          .dp-n-${i}{animation:dpNF${i} ${n.sp}s ease-in-out infinite;}
          @keyframes dpNF${i}{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:1;}33%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1+Math.random()*0.06});opacity:${0.8+Math.random()*0.2};}66%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1-Math.random()*0.04});opacity:${0.85+Math.random()*0.15};}}
        `).join("")}
      `}</style>
    </div>
  );
}
