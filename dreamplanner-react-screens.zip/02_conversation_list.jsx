import { useState, useEffect, useRef, useCallback } from "react";
import {
  ArrowLeft, Search, Bot, Sparkles, Flag, Heart, Brain,
  Users, MessageCircle, ChevronRight, Trash2, Plus, X,
  Clock, MoreVertical, Pin, Archive
} from "lucide-react";

/* ═══════════════════════════════════════════════════════════════════
 * DreamPlanner — Conversation List Screen v1
 * 
 * Elements from Flutter original:
 * - GlassAppBar with title "Conversations"
 * - List of conversation cards with type icon, title, message count
 * - Conversation types: dream_creation, planning, motivation, check_in, buddy_chat
 * - Swipe to delete
 * - Empty state
 * 
 * UX Improvements:
 * - Search bar (glass) to filter conversations
 * - Filter tabs (All, AI Coach, Planning, Check-in, Buddy)
 * - Last message preview + time ago
 * - Unread indicator dot
 * - Pinned conversations section
 * - Context menu on long-press/right-click (Pin, Archive, Delete)
 * - New conversation button in header
 * - Staggered mount animations
 * - All text 9:1+ contrast
 * ═══════════════════════════════════════════════════════════════════ */

// ─── MOCK DATA ───────────────────────────────────────────────────
const MOCK_CONVERSATIONS = [
  {
    id: "1", title: "Launch SaaS Platform — Coaching",
    type: "dream_coaching", messageCount: 24, unread: 2, pinned: true,
    lastMessage: "Great progress on the deployment pipeline! Let's focus on the monitoring setup next.",
    updatedAt: new Date(Date.now() - 1000 * 60 * 12), // 12 min ago
    dreamTitle: "Launch my SaaS Platform",
  },
  {
    id: "2", title: "Piano Practice Plan",
    type: "planning", messageCount: 15, unread: 0, pinned: true,
    lastMessage: "I've structured your weekly practice into 30-minute blocks focusing on chord transitions.",
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2h ago
    dreamTitle: "Learn Piano in 6 Months",
  },
  {
    id: "3", title: "Morning Motivation",
    type: "motivation", messageCount: 8, unread: 1, pinned: false,
    lastMessage: "You've completed 3 tasks this week already — that's momentum building! 🔥",
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 5), // 5h ago
    dreamTitle: "Run a Half Marathon",
  },
  {
    id: "4", title: "Weekly Check-in",
    type: "check_in", messageCount: 12, unread: 0, pinned: false,
    lastMessage: "Your savings rate improved by 8% this month. Let's review your budget allocation.",
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    dreamTitle: "Save $15,000 Emergency Fund",
  },
  {
    id: "5", title: "Chat with Alex",
    type: "buddy_chat", messageCount: 31, unread: 0, pinned: false,
    lastMessage: "Hey! How's the marathon training going? I just finished my 10k today 💪",
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 48), // 2 days ago
    dreamTitle: null,
  },
  {
    id: "6", title: "New Dream Brainstorm",
    type: "dream_creation", messageCount: 6, unread: 0, pinned: false,
    lastMessage: "Let's explore what skills you'd need to start a YouTube channel about tech reviews.",
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 72), // 3 days ago
    dreamTitle: null,
  },
];

// ─── CONVERSATION TYPE CONFIG ────────────────────────────────────
const CONV_TYPES = {
  dream_coaching:  { Icon: Bot,      color: "#C4B5FD", bg: "#8B5CF6", label: "AI Coach" },
  dream_creation:  { Icon: Sparkles, color: "#FCD34D", bg: "#F59E0B", label: "Creation" },
  planning:        { Icon: Flag,     color: "#5DE5A8", bg: "#10B981", label: "Planning" },
  motivation:      { Icon: Heart,    color: "#F69A9A", bg: "#EF4444", label: "Motivation" },
  check_in:        { Icon: Brain,    color: "#93C5FD", bg: "#3B82F6", label: "Check-in" },
  buddy_chat:      { Icon: Users,    color: "#5EEAD4", bg: "#14B8A6", label: "Buddy" },
};

const FILTER_TABS = [
  { key: "all", label: "All" },
  { key: "dream_coaching", label: "AI Coach" },
  { key: "planning", label: "Planning" },
  { key: "check_in", label: "Check-in" },
  { key: "buddy_chat", label: "Buddy" },
];

// ─── COSMIC BACKGROUND (compact — same as homescreen v4) ─────────
const STAR_LAYERS=[{count:300,sizeRange:[0.3,1.0],opacity:0.35,parallax:0.008},{count:200,sizeRange:[0.8,1.8],opacity:0.55,parallax:0.02},{count:100,sizeRange:[1.2,2.8],opacity:0.85,parallax:0.045}];
const STAR_COLORS=[[230,225,255],[200,210,255],[255,220,200],[180,200,255],[255,200,220],[220,240,255],[255,240,230]];
const SMOKE_CYCLE=[[255,120,160],[255,80,180],[220,60,220],[180,70,255],[130,80,255],[80,100,255],[60,140,255],[80,180,240],[100,200,220],[160,120,255],[220,100,200],[255,120,160]];
const SMOKE_CONFIGS=[{size:350,opacity:0.09,speedMult:1.0,colorSpeed:0.015,colorOffset:0,pfx:[0.13,0.31],pfy:[0.17,0.23],pax:[0.38,0.12],pay:[0.35,0.10]},{size:300,opacity:0.07,speedMult:1.3,colorSpeed:0.02,colorOffset:3,pfx:[0.19,0.41],pfy:[0.23,0.29],pax:[0.35,0.15],pay:[0.32,0.08]},{size:250,opacity:0.06,speedMult:1.7,colorSpeed:0.025,colorOffset:6,pfx:[0.29,0.53],pfy:[0.31,0.37],pax:[0.33,0.18],pay:[0.30,0.12]},{size:420,opacity:0.05,speedMult:0.6,colorSpeed:0.01,colorOffset:9,pfx:[0.07,0.19],pfy:[0.11,0.17],pax:[0.40,0.10],pay:[0.38,0.14]},{size:280,opacity:0.065,speedMult:1.1,colorSpeed:0.018,colorOffset:4.5,pfx:[0.17,0.37],pfy:[0.21,0.43],pax:[0.36,0.14],pay:[0.33,0.11]}];
const NEBULAE=[{x:"8%",y:"15%",c1:"rgba(80,120,255,0.06)",c2:"rgba(60,80,200,0.015)",s:500,b:90,sp:35},{x:"88%",y:"20%",c1:"rgba(100,140,255,0.05)",c2:"rgba(70,100,220,0.015)",s:450,b:85,sp:28},{x:"12%",y:"75%",c1:"rgba(140,80,220,0.06)",c2:"rgba(100,50,180,0.015)",s:430,b:80,sp:32},{x:"82%",y:"78%",c1:"rgba(120,70,200,0.05)",c2:"rgba(90,40,170,0.015)",s:410,b:85,sp:26},{x:"50%",y:"92%",c1:"rgba(60,100,200,0.04)",c2:"rgba(40,70,160,0.01)",s:550,b:100,sp:40},{x:"50%",y:"5%",c1:"rgba(90,60,180,0.04)",c2:"rgba(70,40,150,0.01)",s:500,b:90,sp:22}];
function lerp(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}
function smokeCol(t){const l=SMOKE_CYCLE.length,i=t%l,f=Math.floor(i);return lerp(SMOKE_CYCLE[f%l],SMOKE_CYCLE[(f+1)%l],i-f);}
function mkStars(layer,w,h){const s=[];for(let i=0;i<layer.count;i++)s.push({x:Math.random()*w,y:Math.random()*h,sz:layer.sizeRange[0]+Math.random()*(layer.sizeRange[1]-layer.sizeRange[0]),op:layer.opacity*(0.4+Math.random()*0.6),ts:0.3+Math.random()*2.5,to:Math.random()*Math.PI*2,c:STAR_COLORS[Math.floor(Math.random()*STAR_COLORS.length)]});return s;}
function mkShoot(w,h){const e=Math.floor(Math.random()*3);let x,y,a;if(e===0){x=Math.random()*w;y=-20;a=Math.PI*0.3+Math.random()*Math.PI*0.4;}else if(e===1){x=-20;y=Math.random()*h*0.6;a=Math.PI*0.05+Math.random()*Math.PI*0.3;}else{x=w*0.5+Math.random()*w*0.5;y=-20;a=Math.PI*0.4+Math.random()*Math.PI*0.3;}const sp=5+Math.random()*8;return{x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,ln:80+Math.random()*140,life:1,dc:0.005+Math.random()*0.01,sz:0.8+Math.random()*1.8,w:Math.random()};}

// ─── HELPERS ─────────────────────────────────────────────────────
function timeAgo(date) {
  const s = Math.floor((Date.now() - date.getTime()) / 1000);
  if (s < 60) return "now";
  if (s < 3600) return `${Math.floor(s/60)}m`;
  if (s < 86400) return `${Math.floor(s/3600)}h`;
  if (s < 604800) return `${Math.floor(s/86400)}d`;
  return `${Math.floor(s/604800)}w`;
}

// ═══════════════════════════════════════════════════════════════════
export default function ConversationListScreen() {
  const [mounted, setMounted] = useState(false);
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [contextMenu, setContextMenu] = useState(null); // {id, x, y}
  const scRef = useRef(null);
  const mkRef = useRef(null);
  const stRef = useRef([]);
  const shRef = useRef([]);
  const drRef = useRef({x:0,y:0,a:0});
  const msRef = useRef({x:0,y:0,tx:0,ty:0});
  const tRef = useRef(0);
  const szRef = useRef({w:0,h:0});
  const afRef = useRef(null);

  useEffect(()=>{setTimeout(()=>setMounted(true),100);},[]);

  // Close context menu on outside click
  useEffect(()=>{
    const close = ()=>setContextMenu(null);
    if(contextMenu) window.addEventListener("click",close);
    return()=>window.removeEventListener("click",close);
  },[contextMenu]);

  // ─── Background engine (same as homescreen) ───
  const init=useCallback((w,h)=>{stRef.current=STAR_LAYERS.map(l=>({c:l,s:mkStars(l,w*1.3,h*1.3)}));},[]);
  useEffect(()=>{
    const sc=scRef.current,mk=mkRef.current;if(!sc||!mk)return;
    const sx=sc.getContext("2d"),mx=mk.getContext("2d"),d=window.devicePixelRatio||1;
    const rs=()=>{const w=window.innerWidth,h=window.innerHeight;[sc,mk].forEach(c=>{c.width=w*d;c.height=h*d;c.style.width=w+"px";c.style.height=h+"px";});sx.setTransform(d,0,0,d,0,0);mx.setTransform(d,0,0,d,0,0);szRef.current={w,h};init(w,h);};
    rs();window.addEventListener("resize",rs);
    const mm=e=>{const cx=window.innerWidth/2,cy=window.innerHeight/2;msRef.current.tx=(e.clientX-cx)/cx;msRef.current.ty=(e.clientY-cy)/cy;};
    window.addEventListener("mousemove",mm);
    const go=()=>{
      const{w,h}=szRef.current;tRef.current+=0.016;const t=tRef.current;
      const dr=drRef.current;dr.a+=0.0008;dr.x=Math.sin(dr.a*0.7)*0.15+Math.sin(dr.a*1.3)*0.08;dr.y=Math.cos(dr.a*0.5)*0.12+Math.cos(dr.a*1.1)*0.06;
      const m=msRef.current;m.x+=(m.tx-m.x)*0.03;m.y+=(m.ty-m.y)*0.03;
      const mvx=dr.x+m.x*0.4,mvy=dr.y+m.y*0.4;
      mx.clearRect(0,0,w,h);
      SMOKE_CONFIGS.forEach(c=>{const st=t*c.speedMult;const px=0.5+c.pax[0]*Math.sin(st*c.pfx[0])+c.pax[1]*Math.sin(st*c.pfx[1]);const py=0.5+c.pay[0]*Math.cos(st*c.pfy[0])+c.pay[1]*Math.cos(st*c.pfy[1]);const x=px*w,y=py*h;const[r,g,b]=smokeCol(c.colorOffset+t*c.colorSpeed);const gr=mx.createRadialGradient(x,y,0,x,y,c.size);gr.addColorStop(0,`rgba(${r|0},${g|0},${b|0},${c.opacity})`);gr.addColorStop(0.3,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.6})`);gr.addColorStop(0.6,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.2})`);gr.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=gr;mx.beginPath();mx.arc(x,y,c.size,0,Math.PI*2);mx.fill();const ig=mx.createRadialGradient(x,y,0,x,y,c.size*0.4);ig.addColorStop(0,`rgba(${Math.min(r+40,255)|0},${Math.min(g+30,255)|0},${Math.min(b+30,255)|0},${c.opacity*0.8})`);ig.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=ig;mx.beginPath();mx.arc(x,y,c.size*0.4,0,Math.PI*2);mx.fill();});
      sx.clearRect(0,0,w,h);
      stRef.current.forEach(({c:cfg,s:stars})=>{const ox=mvx*cfg.parallax*w+(w*0.15),oy=mvy*cfg.parallax*h+(h*0.15),fw=w*1.3,fh=h*1.3;stars.forEach(s=>{const tw=Math.sin(t*s.ts+s.to)*0.35+0.65,a=s.op*tw,px=((s.x-ox)%fw+fw)%fw-w*0.15,py=((s.y-oy)%fh+fh)%fh-h*0.15;if(px<-10||px>w+10||py<-10||py>h+10)return;const[r,g,b]=s.c;if(s.sz>1.5){const gr=sx.createRadialGradient(px,py,0,px,py,s.sz*4);gr.addColorStop(0,`rgba(${r},${g},${b},${a*0.25})`);gr.addColorStop(1,`rgba(${r},${g},${b},0)`);sx.fillStyle=gr;sx.beginPath();sx.arc(px,py,s.sz*4,0,Math.PI*2);sx.fill();}if(s.sz>2.2){sx.strokeStyle=`rgba(${r},${g},${b},${a*0.15})`;sx.lineWidth=0.5;const fl=s.sz*6*tw;sx.beginPath();sx.moveTo(px-fl,py);sx.lineTo(px+fl,py);sx.moveTo(px,py-fl);sx.lineTo(px,py+fl);sx.stroke();}sx.fillStyle=`rgba(${r},${g},${b},${a})`;sx.beginPath();sx.arc(px,py,s.sz,0,Math.PI*2);sx.fill();});});
      if(Math.random()<0.025)shRef.current.push(mkShoot(w,h));if(Math.random()<0.003){for(let i=0;i<2+Math.floor(Math.random()*2);i++)shRef.current.push(mkShoot(w,h));}
      shRef.current=shRef.current.filter(s=>{s.x+=s.vx;s.y+=s.vy;s.life-=s.dc;if(s.life<=0)return false;const a=s.life*s.life,mg=Math.sqrt(s.vx*s.vx+s.vy*s.vy),dx=s.vx/mg,dy=s.vy/mg,tx=s.x-dx*s.ln*a,ty=s.y-dy*s.ln*a;const cr=s.w>0.5?255:200,cg=s.w>0.5?220:210,cb=s.w>0.5?200:255;const gr=sx.createLinearGradient(tx,ty,s.x,s.y);gr.addColorStop(0,`rgba(${cr},${cg},${cb},0)`);gr.addColorStop(0.5,`rgba(${cr},${cg},${cb},${a*0.25})`);gr.addColorStop(1,`rgba(255,255,255,${a*0.9})`);sx.strokeStyle=gr;sx.lineWidth=s.sz;sx.lineCap="round";sx.beginPath();sx.moveTo(tx,ty);sx.lineTo(s.x,s.y);sx.stroke();const hg=sx.createRadialGradient(s.x,s.y,0,s.x,s.y,5);hg.addColorStop(0,`rgba(255,255,255,${a*0.9})`);hg.addColorStop(1,`rgba(${cr},${cg},${cb},0)`);sx.fillStyle=hg;sx.beginPath();sx.arc(s.x,s.y,5,0,Math.PI*2);sx.fill();return true;});
      afRef.current=requestAnimationFrame(go);
    };
    afRef.current=requestAnimationFrame(go);
    return()=>{cancelAnimationFrame(afRef.current);window.removeEventListener("resize",rs);window.removeEventListener("mousemove",mm);};
  },[init]);

  // ─── Filter & Search ───
  const filtered = MOCK_CONVERSATIONS.filter(c => {
    if (activeFilter !== "all" && c.type !== activeFilter) return false;
    if (searchQuery && !c.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });
  const pinned = filtered.filter(c => c.pinned);
  const unpinned = filtered.filter(c => !c.pinned);
  const totalUnread = MOCK_CONVERSATIONS.reduce((sum, c) => sum + c.unread, 0);

  return (
    <div style={{ position:"fixed", inset:0, overflow:"hidden", fontFamily:"'Inter',-apple-system,BlinkMacSystemFont,sans-serif" }}>
      {/* ═══ BACKGROUND ═══ */}
      <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at 50% 50%,#0c081a 0%,#070412 35%,#03010a 70%,#000005 100%)",zIndex:0}}>
        {NEBULAE.map((n,i)=><div key={i} className={`dp-n-${i}`} style={{position:"absolute",left:n.x,top:n.y,width:n.s,height:n.s,transform:"translate(-50%,-50%)",background:`radial-gradient(circle,${n.c1} 0%,${n.c2} 40%,transparent 70%)`,filter:`blur(${n.b}px)`,pointerEvents:"none"}}/>)}
        <canvas ref={mkRef} style={{position:"absolute",inset:0,pointerEvents:"none",mixBlendMode:"screen"}}/>
        <canvas ref={scRef} style={{position:"absolute",inset:0,pointerEvents:"none"}}/>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at center,transparent 30%,rgba(3,1,10,0.5) 70%,rgba(0,0,5,0.8) 100%)",pointerEvents:"none"}}/>
      </div>

      {/* ═══ APP BAR ═══ */}
      <header style={{
        position:"fixed",top:0,left:0,right:0,zIndex:100,
        background:"rgba(255,255,255,0.03)",backdropFilter:"blur(40px) saturate(1.4)",WebkitBackdropFilter:"blur(40px) saturate(1.4)",
        borderBottom:"1px solid rgba(255,255,255,0.05)",
      }}>
        {/* Top row */}
        <div style={{ height:64, display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 16px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <button className="dp-icon-btn" style={iconBtnStyle}><ArrowLeft size={20} strokeWidth={2} /></button>
            <div>
              <div style={{ fontSize:17, fontWeight:700, color:"#fff", letterSpacing:"-0.3px" }}>Conversations</div>
              {totalUnread > 0 && <div style={{ fontSize:11, color:"rgba(255,255,255,0.7)" }}>{totalUnread} unread</div>}
            </div>
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <button className="dp-icon-btn" style={iconBtnStyle} onClick={()=>{setSearchOpen(!searchOpen);setSearchQuery("");}}>
              {searchOpen ? <X size={18} strokeWidth={2}/> : <Search size={18} strokeWidth={2}/>}
            </button>
            <button className="dp-icon-btn" style={{...iconBtnStyle, background:"linear-gradient(135deg,rgba(139,92,246,0.2),rgba(109,40,217,0.2))", borderColor:"rgba(139,92,246,0.25)"}}>
              <Plus size={18} strokeWidth={2.5} color="#C4B5FD" />
            </button>
          </div>
        </div>

        {/* Search bar (collapsible) */}
        <div style={{
          overflow:"hidden", transition:"all 0.3s cubic-bezier(0.16,1,0.3,1)",
          maxHeight: searchOpen ? 56 : 0, opacity: searchOpen ? 1 : 0,
          padding: searchOpen ? "0 16px 12px" : "0 16px 0",
        }}>
          <div style={{
            display:"flex", alignItems:"center", gap:10, padding:"10px 14px",
            borderRadius:14, background:"rgba(255,255,255,0.05)",
            border:"1px solid rgba(255,255,255,0.06)",
          }}>
            <Search size={16} color="rgba(255,255,255,0.4)" strokeWidth={2} />
            <input
              value={searchQuery}
              onChange={e=>setSearchQuery(e.target.value)}
              placeholder="Search conversations..."
              style={{
                flex:1, background:"none", border:"none", outline:"none",
                color:"#fff", fontSize:14, fontFamily:"inherit",
              }}
            />
          </div>
        </div>

        {/* Filter tabs */}
        <div style={{
          display:"flex", gap:6, padding:"0 16px 12px", overflowX:"auto",
        }}>
          {FILTER_TABS.map(tab => {
            const active = activeFilter === tab.key;
            return (
              <button
                key={tab.key}
                onClick={()=>setActiveFilter(tab.key)}
                style={{
                  padding:"6px 14px", borderRadius:20, border:"none", cursor:"pointer",
                  fontSize:12, fontWeight:active ? 600 : 500, whiteSpace:"nowrap",
                  background: active ? "rgba(139,92,246,0.18)" : "rgba(255,255,255,0.04)",
                  color: active ? "#C4B5FD" : "rgba(255,255,255,0.7)",
                  transition:"all 0.25s",
                  outline: active ? "1px solid rgba(139,92,246,0.25)" : "1px solid transparent",
                }}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* ═══ CONTENT ═══ */}
      <main style={{ position:"absolute", inset:0, overflowY:"auto", overflowX:"hidden", zIndex:10, paddingTop: searchOpen ? 170 : 128, paddingBottom:32, transition:"padding-top 0.3s" }}>
        <div style={{ maxWidth:480, margin:"0 auto", padding:"0 16px" }}>

          {filtered.length === 0 ? (
            /* ── Empty State ── */
            <div className={`dp-a ${mounted?"dp-s":""}`} style={{ animationDelay:"0ms", textAlign:"center", paddingTop:60 }}>
              <div style={{
                width:80, height:80, borderRadius:"50%", margin:"0 auto 20px",
                background:"rgba(139,92,246,0.08)", display:"flex", alignItems:"center", justifyContent:"center",
              }}>
                <MessageCircle size={36} color="rgba(255,255,255,0.7)" strokeWidth={1.5} />
              </div>
              <div style={{ fontSize:17, fontWeight:600, color:"#fff", marginBottom:8 }}>No conversations yet</div>
              <div style={{ fontSize:14, color:"rgba(255,255,255,0.7)", lineHeight:1.5, maxWidth:280, margin:"0 auto" }}>
                Start a conversation from a dream's AI Coach or connect with a buddy
              </div>
            </div>
          ) : (
            <>
              {/* ── Pinned Section ── */}
              {pinned.length > 0 && (
                <>
                  <div className={`dp-a ${mounted?"dp-s":""}`} style={{ animationDelay:"0ms" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:10 }}>
                      <Pin size={13} color="rgba(255,255,255,0.7)" strokeWidth={2.5} />
                      <span style={{ fontSize:12, fontWeight:600, color:"rgba(255,255,255,0.7)", textTransform:"uppercase", letterSpacing:"0.5px" }}>Pinned</span>
                    </div>
                  </div>
                  {pinned.map((conv, i) => (
                    <ConvCard key={conv.id} conv={conv} index={i} mounted={mounted} delay={80+i*70} onContext={(e)=>{e.preventDefault();setContextMenu({id:conv.id,x:e.clientX,y:e.clientY});}} />
                  ))}
                  <div style={{ height:16 }} />
                </>
              )}

              {/* ── All / Recent ── */}
              {unpinned.length > 0 && (
                <>
                  {pinned.length > 0 && (
                    <div className={`dp-a ${mounted?"dp-s":""}`} style={{ animationDelay:`${80+pinned.length*70+50}ms` }}>
                      <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:10 }}>
                        <Clock size={13} color="rgba(255,255,255,0.7)" strokeWidth={2.5} />
                        <span style={{ fontSize:12, fontWeight:600, color:"rgba(255,255,255,0.7)", textTransform:"uppercase", letterSpacing:"0.5px" }}>Recent</span>
                      </div>
                    </div>
                  )}
                  {unpinned.map((conv, i) => (
                    <ConvCard key={conv.id} conv={conv} index={i} mounted={mounted} delay={80+(pinned.length+i)*70+100} onContext={(e)=>{e.preventDefault();setContextMenu({id:conv.id,x:e.clientX,y:e.clientY});}} />
                  ))}
                </>
              )}
            </>
          )}
        </div>
      </main>

      {/* ═══ CONTEXT MENU ═══ */}
      {contextMenu && (
        <div style={{
          position:"fixed", left:contextMenu.x, top:contextMenu.y, zIndex:200,
          background:"rgba(20,16,35,0.95)", backdropFilter:"blur(30px)", WebkitBackdropFilter:"blur(30px)",
          borderRadius:14, border:"1px solid rgba(255,255,255,0.08)",
          boxShadow:"0 12px 40px rgba(0,0,0,0.5)", padding:6, minWidth:160,
          animation:"dpFadeScale 0.15s ease-out",
        }}>
          {[
            { Icon: Pin, label:"Pin conversation", color:"rgba(255,255,255,0.85)" },
            { Icon: Archive, label:"Archive", color:"rgba(255,255,255,0.85)" },
            { Icon: Trash2, label:"Delete", color:"#F69A9A" },
          ].map(({Icon:I, label, color}, i) => (
            <button key={i} onClick={()=>setContextMenu(null)} style={{
              display:"flex", alignItems:"center", gap:10, width:"100%", padding:"10px 14px",
              background:"none", border:"none", borderRadius:10, cursor:"pointer", color,
              fontSize:13, fontWeight:500, fontFamily:"inherit", transition:"background 0.15s",
            }}
              onMouseEnter={e=>e.currentTarget.style.background="rgba(255,255,255,0.06)"}
              onMouseLeave={e=>e.currentTarget.style.background="none"}
            >
              <I size={16} strokeWidth={2} /> {label}
            </button>
          ))}
        </div>
      )}

      {/* ═══ STYLES ═══ */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        *{margin:0;padding:0;box-sizing:border-box;}
        ::-webkit-scrollbar{width:0;}
        input::placeholder{color:rgba(255,255,255,0.35);}

        .dp-g{background:rgba(255,255,255,0.04);backdrop-filter:blur(40px) saturate(1.3);-webkit-backdrop-filter:blur(40px) saturate(1.3);border-radius:18px;border:1px solid rgba(255,255,255,0.06);box-shadow:0 4px 24px rgba(0,0,0,0.12),inset 0 1px 0 rgba(255,255,255,0.03);transition:all 0.3s cubic-bezier(0.16,1,0.3,1);}
        .dp-gh:hover{background:rgba(255,255,255,0.07);border-color:rgba(255,255,255,0.1);box-shadow:0 8px 32px rgba(0,0,0,0.18),inset 0 1px 0 rgba(255,255,255,0.05);transform:translateY(-2px);}
        .dp-gh:active{transform:scale(0.985);}

        .dp-a{opacity:0;transform:translateY(16px);transition:opacity 0.5s cubic-bezier(0.16,1,0.3,1),transform 0.5s cubic-bezier(0.16,1,0.3,1);}
        .dp-a.dp-s{opacity:1;transform:translateY(0);}

        .dp-icon-btn{width:40px;height:40px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.05);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;}
        .dp-icon-btn:hover{background:rgba(255,255,255,0.1);}

        .dp-unread-dot{animation:dpPulse 2s ease-in-out infinite;}
        @keyframes dpPulse{0%,100%{opacity:1;box-shadow:0 0 6px rgba(139,92,246,0.5);}50%{opacity:0.7;box-shadow:0 0 10px rgba(139,92,246,0.3);}}
        @keyframes dpFadeScale{from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);}}

        ${NEBULAE.map((n,i)=>`
          .dp-n-${i}{animation:dpNF${i} ${n.sp}s ease-in-out infinite;}
          @keyframes dpNF${i}{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:1;}33%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1+Math.random()*0.06});opacity:${0.8+Math.random()*0.2};}66%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1-Math.random()*0.04});opacity:${0.85+Math.random()*0.15};}}
        `).join("")}
      `}</style>
    </div>
  );
}

// ─── CONVERSATION CARD ───────────────────────────────────────────
function ConvCard({ conv, index, mounted, delay, onContext }) {
  const type = CONV_TYPES[conv.type] || CONV_TYPES.dream_coaching;
  const TypeIcon = type.Icon;

  return (
    <div className={`dp-a ${mounted?"dp-s":""}`} style={{ animationDelay:`${delay}ms` }}>
      <div
        className="dp-g dp-gh"
        style={{ padding:14, marginBottom:10, cursor:"pointer", position:"relative" }}
        onContextMenu={onContext}
      >
        <div style={{ display:"flex", gap:12 }}>
          {/* Type icon */}
          <div style={{
            width:44, height:44, borderRadius:14, flexShrink:0,
            display:"flex", alignItems:"center", justifyContent:"center",
            background:`${type.bg}15`, border:`1px solid ${type.bg}20`,
          }}>
            <TypeIcon size={20} color={type.color} strokeWidth={2} />
          </div>

          {/* Content */}
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:4 }}>
              <div style={{
                fontSize:14, fontWeight:600, color:"#fff",
                overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap",
                flex:1, marginRight:8,
              }}>
                {conv.title}
              </div>
              <div style={{ display:"flex", alignItems:"center", gap:6, flexShrink:0 }}>
                <span style={{ fontSize:11, color:"rgba(255,255,255,0.7)" }}>{timeAgo(conv.updatedAt)}</span>
                {conv.unread > 0 && (
                  <div className="dp-unread-dot" style={{
                    minWidth:18, height:18, borderRadius:9, padding:"0 5px",
                    background:"#8B5CF6", display:"flex", alignItems:"center", justifyContent:"center",
                    fontSize:10, fontWeight:700, color:"#fff",
                  }}>{conv.unread}</div>
                )}
              </div>
            </div>

            {/* Last message preview */}
            <div style={{
              fontSize:13, color: conv.unread > 0 ? "rgba(255,255,255,0.85)" : "rgba(255,255,255,0.7)",
              fontWeight: conv.unread > 0 ? 500 : 400,
              overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap",
              marginBottom:6, lineHeight:1.4,
            }}>
              {conv.lastMessage}
            </div>

            {/* Meta row */}
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{
                fontSize:11, fontWeight:500, color:type.color,
                padding:"2px 8px", borderRadius:8,
                background:`${type.bg}10`,
              }}>
                {type.label}
              </span>
              {conv.dreamTitle && (
                <span style={{ fontSize:11, color:"rgba(255,255,255,0.7)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                  {conv.dreamTitle}
                </span>
              )}
            </div>
          </div>

          {/* Chevron */}
          <div style={{ display:"flex", alignItems:"center", flexShrink:0 }}>
            <ChevronRight size={16} color="rgba(255,255,255,0.7)" />
          </div>
        </div>

        {/* Pin indicator */}
        {conv.pinned && (
          <div style={{ position:"absolute", top:6, right:6 }}>
            <Pin size={11} color="rgba(255,255,255,0.7)" strokeWidth={2.5} style={{ transform:"rotate(45deg)" }} />
          </div>
        )}
      </div>
    </div>
  );
}

const iconBtnStyle = {
  width:40,height:40,borderRadius:12,
  border:"1px solid rgba(255,255,255,0.08)",
  background:"rgba(255,255,255,0.05)",
  color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",
  cursor:"pointer",transition:"all 0.2s",
};
