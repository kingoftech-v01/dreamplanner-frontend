import { useState, useEffect, useRef, useCallback } from "react";
import {
  Home, CalendarDays, Users, User, Bell, Plus, Sparkles,
  Bot, MessageCircle, Trophy, ShoppingBag, Briefcase,
  Palette, Heart, Wallet, Brain, Target, Clock, Flame,
  Star, Zap, ChevronRight, MoreHorizontal, Share2, Pencil
} from "lucide-react";

/* ═══════════════════════════════════════════════════════════════════
 * DreamPlanner — Home Screen v2
 * 
 * Changes from v1:
 * - Lucide React icons everywhere (clean, consistent, colorable)
 * - Removed duplicate "New Dream" pill button from dreams header
 * - Added rank badge + level progress bar in welcome card
 * - Dream cards: pulsing status dot, hover action bar (Coach/Edit/Share)
 * - Notification bell with badge count
 * - Better visual hierarchy and spacing
 * - Bottom nav with proper Lucide icons + active glow
 * - Dreams header now shows count + filter hint
 * - FAB is the single entry point for creating dreams
 * ═══════════════════════════════════════════════════════════════════ */

// ─── MOCK DATA ───────────────────────────────────────────────────
const MOCK_USER = {
  displayName: "Stephane",
  email: "stephane@rhematek.com",
  level: 12,
  xp: 2450,
  xpToNext: 3000,
  streakDays: 7,
  rank: "Achiever",
  notificationCount: 3,
};

const MOCK_DREAMS = [
  { id:"1", title:"Launch my SaaS Platform", description:"Build and deploy a production-grade multi-tenant HR platform with 10k users", category:"career", progress:62, goalCount:8, completedGoalCount:5, status:"active", daysLeft: 45 },
  { id:"2", title:"Learn Piano in 6 Months", description:"Master 10 worship songs and be able to play in church by summer", category:"hobbies", progress:35, goalCount:6, completedGoalCount:2, status:"active", daysLeft: 120 },
  { id:"3", title:"Run a Half Marathon", description:"Train progressively and complete a 21km race in under 2 hours", category:"health", progress:18, goalCount:5, completedGoalCount:1, status:"active", daysLeft: 90 },
  { id:"4", title:"Save $15,000 Emergency Fund", description:"Build a solid financial safety net within 12 months", category:"finance", progress:88, goalCount:4, completedGoalCount:3, status:"active", daysLeft: 30 },
];

// ─── COSMIC BACKGROUND ENGINE ────────────────────────────────────
const STAR_LAYERS = [
  { count:300, sizeRange:[0.3,1.0], opacity:0.35, parallax:0.008 },
  { count:200, sizeRange:[0.8,1.8], opacity:0.55, parallax:0.02 },
  { count:100, sizeRange:[1.2,2.8], opacity:0.85, parallax:0.045 },
];
const STAR_COLORS = [[230,225,255],[200,210,255],[255,220,200],[180,200,255],[255,200,220],[220,240,255],[255,240,230]];
const SMOKE_CYCLE = [[255,120,160],[255,80,180],[220,60,220],[180,70,255],[130,80,255],[80,100,255],[60,140,255],[80,180,240],[100,200,220],[160,120,255],[220,100,200],[255,120,160]];
const SMOKE_CONFIGS = [
  {size:350,opacity:0.09,speedMult:1.0,colorSpeed:0.015,colorOffset:0,pfx:[0.13,0.31],pfy:[0.17,0.23],pax:[0.38,0.12],pay:[0.35,0.10]},
  {size:300,opacity:0.07,speedMult:1.3,colorSpeed:0.02,colorOffset:3,pfx:[0.19,0.41],pfy:[0.23,0.29],pax:[0.35,0.15],pay:[0.32,0.08]},
  {size:250,opacity:0.06,speedMult:1.7,colorSpeed:0.025,colorOffset:6,pfx:[0.29,0.53],pfy:[0.31,0.37],pax:[0.33,0.18],pay:[0.30,0.12]},
  {size:420,opacity:0.05,speedMult:0.6,colorSpeed:0.01,colorOffset:9,pfx:[0.07,0.19],pfy:[0.11,0.17],pax:[0.40,0.10],pay:[0.38,0.14]},
  {size:280,opacity:0.065,speedMult:1.1,colorSpeed:0.018,colorOffset:4.5,pfx:[0.17,0.37],pfy:[0.21,0.43],pax:[0.36,0.14],pay:[0.33,0.11]},
];
const NEBULAE = [
  {x:"8%",y:"15%",c1:"rgba(80,120,255,0.06)",c2:"rgba(60,80,200,0.015)",s:500,b:90,sp:35},
  {x:"88%",y:"20%",c1:"rgba(100,140,255,0.05)",c2:"rgba(70,100,220,0.015)",s:450,b:85,sp:28},
  {x:"12%",y:"75%",c1:"rgba(140,80,220,0.06)",c2:"rgba(100,50,180,0.015)",s:430,b:80,sp:32},
  {x:"82%",y:"78%",c1:"rgba(120,70,200,0.05)",c2:"rgba(90,40,170,0.015)",s:410,b:85,sp:26},
  {x:"50%",y:"92%",c1:"rgba(60,100,200,0.04)",c2:"rgba(40,70,160,0.01)",s:550,b:100,sp:40},
  {x:"50%",y:"5%",c1:"rgba(90,60,180,0.04)",c2:"rgba(70,40,150,0.01)",s:500,b:90,sp:22},
];

function lerp(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}
function smokeCol(t){const l=SMOKE_CYCLE.length,i=t%l,f=Math.floor(i);return lerp(SMOKE_CYCLE[f%l],SMOKE_CYCLE[(f+1)%l],i-f);}
function mkStars(layer,w,h){const s=[];for(let i=0;i<layer.count;i++)s.push({x:Math.random()*w,y:Math.random()*h,sz:layer.sizeRange[0]+Math.random()*(layer.sizeRange[1]-layer.sizeRange[0]),op:layer.opacity*(0.4+Math.random()*0.6),ts:0.3+Math.random()*2.5,to:Math.random()*Math.PI*2,c:STAR_COLORS[Math.floor(Math.random()*STAR_COLORS.length)]});return s;}
function mkShoot(w,h){const e=Math.floor(Math.random()*3);let x,y,a;if(e===0){x=Math.random()*w;y=-20;a=Math.PI*0.3+Math.random()*Math.PI*0.4;}else if(e===1){x=-20;y=Math.random()*h*0.6;a=Math.PI*0.05+Math.random()*Math.PI*0.3;}else{x=w*0.5+Math.random()*w*0.5;y=-20;a=Math.PI*0.4+Math.random()*Math.PI*0.3;}const sp=5+Math.random()*8;return{x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,ln:80+Math.random()*140,life:1,dc:0.005+Math.random()*0.01,sz:0.8+Math.random()*1.8,w:Math.random()};}

// ─── CATEGORY CONFIG ─────────────────────────────────────────────
const CATS = {
  career:   { Icon: Briefcase, color:"#8B5CF6", label:"Career" },
  hobbies:  { Icon: Palette,   color:"#EC4899", label:"Hobbies" },
  health:   { Icon: Heart,     color:"#10B981", label:"Health" },
  finance:  { Icon: Wallet,    color:"#FCD34D", label:"Finance" },
  personal: { Icon: Brain,     color:"#6366F1", label:"Growth" },
  relationships: { Icon: Users, color:"#14B8A6", label:"Social" },
};

const ACTIONS = [
  { Icon: Bot,            label:"AI Coach",       color:"#8B5CF6" },
  { Icon: MessageCircle,  label:"Conversations",  color:"#14B8A6" },
  { Icon: Trophy,         label:"Leaderboard",    color:"#FCD34D" },
  { Icon: ShoppingBag,    label:"Store",          color:"#10B981" },
];

const NAV = [
  { Icon: Home, ActiveIcon: Home, label:"Home" },
  { Icon: CalendarDays, ActiveIcon: CalendarDays, label:"Calendar" },
  { Icon: Users, ActiveIcon: Users, label:"Social" },
  { Icon: User, ActiveIcon: User, label:"Profile" },
];

// ═══════════════════════════════════════════════════════════════════
export default function DreamPlannerHome() {
  const [activeNav, setActiveNav] = useState(0);
  const [mounted, setMounted] = useState(false);
  const [hoveredDream, setHoveredDream] = useState(null);
  const scRef = useRef(null);
  const mkRef = useRef(null);
  const stRef = useRef([]);
  const shRef = useRef([]);
  const drRef = useRef({x:0,y:0,a:0});
  const msRef = useRef({x:0,y:0,tx:0,ty:0});
  const tRef = useRef(0);
  const szRef = useRef({w:0,h:0});
  const afRef = useRef(null);

  useEffect(()=>{setTimeout(()=>setMounted(true),100);},[]);

  const init = useCallback((w,h)=>{
    stRef.current = STAR_LAYERS.map(l=>({c:l,s:mkStars(l,w*1.3,h*1.3)}));
  },[]);

  useEffect(()=>{
    const sc=scRef.current,mk=mkRef.current;if(!sc||!mk)return;
    const sx=sc.getContext("2d"),mx=mk.getContext("2d"),d=window.devicePixelRatio||1;
    const rs=()=>{const w=window.innerWidth,h=window.innerHeight;[sc,mk].forEach(c=>{c.width=w*d;c.height=h*d;c.style.width=w+"px";c.style.height=h+"px";});sx.setTransform(d,0,0,d,0,0);mx.setTransform(d,0,0,d,0,0);szRef.current={w,h};init(w,h);};
    rs();window.addEventListener("resize",rs);
    const mm=e=>{const cx=window.innerWidth/2,cy=window.innerHeight/2;msRef.current.tx=(e.clientX-cx)/cx;msRef.current.ty=(e.clientY-cy)/cy;};
    window.addEventListener("mousemove",mm);
    const go=()=>{
      const{w,h}=szRef.current;tRef.current+=0.016;const t=tRef.current;
      const dr=drRef.current;dr.a+=0.0008;dr.x=Math.sin(dr.a*0.7)*0.15+Math.sin(dr.a*1.3)*0.08;dr.y=Math.cos(dr.a*0.5)*0.12+Math.cos(dr.a*1.1)*0.06;
      const m=msRef.current;m.x+=(m.tx-m.x)*0.03;m.y+=(m.ty-m.y)*0.03;
      const mvx=dr.x+m.x*0.4,mvy=dr.y+m.y*0.4;
      mx.clearRect(0,0,w,h);
      SMOKE_CONFIGS.forEach(c=>{const st=t*c.speedMult;const px=0.5+c.pax[0]*Math.sin(st*c.pfx[0])+c.pax[1]*Math.sin(st*c.pfx[1]);const py=0.5+c.pay[0]*Math.cos(st*c.pfy[0])+c.pay[1]*Math.cos(st*c.pfy[1]);const x=px*w,y=py*h;const[r,g,b]=smokeCol(c.colorOffset+t*c.colorSpeed);const gr=mx.createRadialGradient(x,y,0,x,y,c.size);gr.addColorStop(0,`rgba(${r|0},${g|0},${b|0},${c.opacity})`);gr.addColorStop(0.3,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.6})`);gr.addColorStop(0.6,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.2})`);gr.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=gr;mx.beginPath();mx.arc(x,y,c.size,0,Math.PI*2);mx.fill();const ig=mx.createRadialGradient(x,y,0,x,y,c.size*0.4);ig.addColorStop(0,`rgba(${Math.min(r+40,255)|0},${Math.min(g+30,255)|0},${Math.min(b+30,255)|0},${c.opacity*0.8})`);ig.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=ig;mx.beginPath();mx.arc(x,y,c.size*0.4,0,Math.PI*2);mx.fill();});
      sx.clearRect(0,0,w,h);
      stRef.current.forEach(({c:cfg,s:stars})=>{const ox=mvx*cfg.parallax*w+(w*0.15),oy=mvy*cfg.parallax*h+(h*0.15),fw=w*1.3,fh=h*1.3;stars.forEach(s=>{const tw=Math.sin(t*s.ts+s.to)*0.35+0.65,a=s.op*tw,px=((s.x-ox)%fw+fw)%fw-w*0.15,py=((s.y-oy)%fh+fh)%fh-h*0.15;if(px<-10||px>w+10||py<-10||py>h+10)return;const[r,g,b]=s.c;if(s.sz>1.5){const gr=sx.createRadialGradient(px,py,0,px,py,s.sz*4);gr.addColorStop(0,`rgba(${r},${g},${b},${a*0.25})`);gr.addColorStop(1,`rgba(${r},${g},${b},0)`);sx.fillStyle=gr;sx.beginPath();sx.arc(px,py,s.sz*4,0,Math.PI*2);sx.fill();}if(s.sz>2.2){sx.strokeStyle=`rgba(${r},${g},${b},${a*0.15})`;sx.lineWidth=0.5;const fl=s.sz*6*tw;sx.beginPath();sx.moveTo(px-fl,py);sx.lineTo(px+fl,py);sx.moveTo(px,py-fl);sx.lineTo(px,py+fl);sx.stroke();}sx.fillStyle=`rgba(${r},${g},${b},${a})`;sx.beginPath();sx.arc(px,py,s.sz,0,Math.PI*2);sx.fill();});});
      if(Math.random()<0.025)shRef.current.push(mkShoot(w,h));if(Math.random()<0.003){for(let i=0;i<2+Math.floor(Math.random()*2);i++)shRef.current.push(mkShoot(w,h));}
      shRef.current=shRef.current.filter(s=>{s.x+=s.vx;s.y+=s.vy;s.life-=s.dc;if(s.life<=0)return false;const a=s.life*s.life,mg=Math.sqrt(s.vx*s.vx+s.vy*s.vy),dx=s.vx/mg,dy=s.vy/mg,tx=s.x-dx*s.ln*a,ty=s.y-dy*s.ln*a;const cr=s.w>0.5?255:200,cg=s.w>0.5?220:210,cb=s.w>0.5?200:255;const gr=sx.createLinearGradient(tx,ty,s.x,s.y);gr.addColorStop(0,`rgba(${cr},${cg},${cb},0)`);gr.addColorStop(0.5,`rgba(${cr},${cg},${cb},${a*0.25})`);gr.addColorStop(1,`rgba(255,255,255,${a*0.9})`);sx.strokeStyle=gr;sx.lineWidth=s.sz;sx.lineCap="round";sx.beginPath();sx.moveTo(tx,ty);sx.lineTo(s.x,s.y);sx.stroke();const hg=sx.createRadialGradient(s.x,s.y,0,s.x,s.y,5);hg.addColorStop(0,`rgba(255,255,255,${a*0.9})`);hg.addColorStop(1,`rgba(${cr},${cg},${cb},0)`);sx.fillStyle=hg;sx.beginPath();sx.arc(s.x,s.y,5,0,Math.PI*2);sx.fill();return true;});
      afRef.current=requestAnimationFrame(go);
    };
    afRef.current=requestAnimationFrame(go);
    return()=>{cancelAnimationFrame(afRef.current);window.removeEventListener("resize",rs);window.removeEventListener("mousemove",mm);};
  },[init]);

  const u = MOCK_USER;
  const levelPct = Math.round((u.xp / u.xpToNext) * 100);

  return (
    <div style={{ position:"fixed", inset:0, overflow:"hidden", fontFamily:"'Inter', -apple-system, BlinkMacSystemFont, sans-serif" }}>
      {/* ═══ BACKGROUND ═══ */}
      <div style={{ position:"absolute",inset:0,background:"radial-gradient(ellipse at 50% 50%,#0c081a 0%,#070412 35%,#03010a 70%,#000005 100%)",zIndex:0 }}>
        {NEBULAE.map((n,i)=><div key={i} className={`dp-n-${i}`} style={{position:"absolute",left:n.x,top:n.y,width:n.s,height:n.s,transform:"translate(-50%,-50%)",background:`radial-gradient(circle,${n.c1} 0%,${n.c2} 40%,transparent 70%)`,filter:`blur(${n.b}px)`,pointerEvents:"none"}}/>)}
        <canvas ref={mkRef} style={{position:"absolute",inset:0,pointerEvents:"none",mixBlendMode:"screen"}}/>
        <canvas ref={scRef} style={{position:"absolute",inset:0,pointerEvents:"none"}}/>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at center,transparent 30%,rgba(3,1,10,0.5) 70%,rgba(0,0,5,0.8) 100%)",pointerEvents:"none"}}/>
      </div>

      {/* ═══ APP BAR ═══ */}
      <header style={{
        position:"fixed",top:0,left:0,right:0,zIndex:100,height:64,
        display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 20px",
        background:"rgba(255,255,255,0.03)",backdropFilter:"blur(40px) saturate(1.4)",WebkitBackdropFilter:"blur(40px) saturate(1.4)",
        borderBottom:"1px solid rgba(255,255,255,0.05)",
      }}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <Sparkles size={20} color="#C4B5FD" strokeWidth={2.5} />
          <span style={{fontSize:17,fontWeight:700,color:"#fff",letterSpacing:"-0.3px"}}>DreamPlanner</span>
        </div>
        <button style={{
          position:"relative",width:40,height:40,borderRadius:12,
          border:"1px solid rgba(255,255,255,0.08)",background:"rgba(255,255,255,0.05)",
          color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",
          backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)",transition:"all 0.2s",
        }}
          onMouseEnter={e=>e.currentTarget.style.background="rgba(255,255,255,0.1)"}
          onMouseLeave={e=>e.currentTarget.style.background="rgba(255,255,255,0.05)"}
        >
          <Bell size={18} strokeWidth={2} />
          {u.notificationCount > 0 && (
            <span style={{
              position:"absolute",top:-4,right:-4,width:18,height:18,borderRadius:"50%",
              background:"#EF4444",color:"#fff",fontSize:10,fontWeight:700,
              display:"flex",alignItems:"center",justifyContent:"center",
              boxShadow:"0 2px 8px rgba(239,68,68,0.5)",border:"2px solid #0c081a",
            }}>{u.notificationCount}</span>
          )}
        </button>
      </header>

      {/* ═══ CONTENT ═══ */}
      <main style={{position:"absolute",inset:0,overflowY:"auto",overflowX:"hidden",zIndex:10,paddingTop:80,paddingBottom:108}}>
        <div style={{maxWidth:480,margin:"0 auto",padding:"0 16px"}}>

          {/* ── Welcome Card ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"0ms"}}>
            <div className="dp-g" style={{padding:20,marginBottom:20}}>
              {/* User row */}
              <div style={{display:"flex",alignItems:"center",gap:14,marginBottom:18}}>
                <div style={{
                  width:52,height:52,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",
                  background:"linear-gradient(135deg,rgba(139,92,246,0.35),rgba(109,40,217,0.35))",
                  border:"2px solid rgba(139,92,246,0.4)",fontSize:22,fontWeight:700,color:"#fff",
                  boxShadow:"0 0 20px rgba(139,92,246,0.15)",
                }}>
                  {u.displayName[0]}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,color:"rgba(255,255,255,0.75)",marginBottom:2}}>Welcome back!</div>
                  <div style={{fontSize:19,fontWeight:700,color:"#fff",letterSpacing:"-0.3px"}}>{u.displayName}</div>
                </div>
                {/* Rank badge */}
                <div style={{
                  padding:"5px 12px",borderRadius:20,
                  background:"linear-gradient(135deg,rgba(139,92,246,0.15),rgba(236,72,153,0.1))",
                  border:"1px solid rgba(139,92,246,0.2)",
                  display:"flex",alignItems:"center",gap:5,
                }}>
                  <Target size={13} color="#C4B5FD" strokeWidth={2.5} />
                  <span style={{fontSize:12,fontWeight:600,color:"#C4B5FD"}}>{u.rank}</span>
                </div>
              </div>

              {/* Level progress */}
              <div style={{marginBottom:18,padding:"0 4px"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                  <span style={{fontSize:12,color:"rgba(255,255,255,0.72)"}}>Level {u.level}</span>
                  <span style={{fontSize:11,color:"rgba(255,255,255,0.7)"}}>{u.xp.toLocaleString()} / {u.xpToNext.toLocaleString()} XP</span>
                </div>
                <div style={{height:4,borderRadius:2,background:"rgba(255,255,255,0.06)",overflow:"hidden"}}>
                  <div className="dp-level-bar" style={{
                    height:"100%",borderRadius:2,width:`${levelPct}%`,
                    background:"linear-gradient(90deg,#8B5CF6,#C4B5FD)",
                    boxShadow:"0 0 10px rgba(139,92,246,0.3)",
                  }}/>
                </div>
              </div>

              {/* Stats row */}
              <div style={{display:"flex",justifyContent:"space-around",alignItems:"center"}}>
                <StatBlock Icon={Star} value={u.level} label="Level" color="#FCD34D" />
                <Divider />
                <StatBlock Icon={Zap} value={u.xp.toLocaleString()} label="XP" color="#C4B5FD" />
                <Divider />
                <StatBlock Icon={Flame} value={u.streakDays} label="Streak" color="#F69A9A" />
              </div>
            </div>
          </div>

          {/* ── Quick Actions ── */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:28}}>
            {ACTIONS.map((a,i)=>(
              <div key={i} className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${150+i*80}ms`}}>
                <button className="dp-g dp-gh" style={{
                  width:"100%",padding:"20px 12px",display:"flex",flexDirection:"column",
                  alignItems:"center",gap:10,cursor:"pointer",border:"none",textAlign:"center",
                }}>
                  <div style={{
                    width:46,height:46,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",
                    background:`${a.color}15`,border:`1px solid ${a.color}20`,
                    transition:"all 0.3s",
                  }}>
                    <a.Icon size={22} color={a.color} strokeWidth={2} />
                  </div>
                  <span style={{fontSize:13,fontWeight:600,color:"rgba(255,255,255,0.85)"}}>{a.label}</span>
                </button>
              </div>
            ))}
          </div>

          {/* ── Dreams Section ── */}
          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"500ms"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:19,fontWeight:700,color:"#fff",letterSpacing:"-0.3px"}}>Your Dreams</span>
                <span style={{
                  padding:"2px 8px",borderRadius:10,fontSize:11,fontWeight:600,
                  background:"rgba(255,255,255,0.06)",color:"rgba(255,255,255,0.72)",
                }}>{MOCK_DREAMS.length}</span>
              </div>
              <button className="dp-gh" style={{
                display:"flex",alignItems:"center",gap:5,padding:"7px 14px",
                borderRadius:20,border:"1px solid rgba(139,92,246,0.25)",
                background:"rgba(139,92,246,0.1)",color:"#C4B5FD",
                fontSize:13,fontWeight:600,cursor:"pointer",transition:"all 0.25s",
              }}
                onMouseEnter={e=>{e.currentTarget.style.background="rgba(139,92,246,0.22)";e.currentTarget.style.borderColor="rgba(139,92,246,0.4)";}}
                onMouseLeave={e=>{e.currentTarget.style.background="rgba(139,92,246,0.1)";e.currentTarget.style.borderColor="rgba(139,92,246,0.25)";}}
              >
                <Plus size={15} strokeWidth={2.5} /> New Dream
              </button>
            </div>
          </div>

          {/* ── Dream Cards ── */}
          {MOCK_DREAMS.map((dream,i)=>{
            const cat = CATS[dream.category] || {Icon:Sparkles,color:"#8B5CF6",label:"Other"};
            const CatIcon = cat.Icon;
            const isHovered = hoveredDream === dream.id;
            return(
              <div key={dream.id} className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${600+i*100}ms`}}>
                <div
                  className="dp-g dp-gh"
                  style={{padding:16,marginBottom:12,cursor:"pointer",position:"relative",overflow:"hidden"}}
                  onMouseEnter={()=>setHoveredDream(dream.id)}
                  onMouseLeave={()=>setHoveredDream(null)}
                >
                  {/* Top row */}
                  <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:10}}>
                    <div style={{
                      width:40,height:40,borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",
                      background:`${cat.color}12`,border:`1px solid ${cat.color}18`,
                    }}>
                      <CatIcon size={20} color={cat.color} strokeWidth={2} />
                    </div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:15,fontWeight:600,color:"#fff",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{dream.title}</div>
                    </div>
                    {/* Status dot */}
                    <div style={{display:"flex",alignItems:"center",gap:6}}>
                      <div className="dp-pulse" style={{width:7,height:7,borderRadius:"50%",background:"#10B981",boxShadow:"0 0 6px rgba(16,185,129,0.5)"}}/>
                      <span style={{fontSize:11,color:"rgba(255,255,255,0.7)",fontWeight:500}}>Active</span>
                    </div>
                  </div>

                  {/* Description */}
                  <div style={{fontSize:13,color:"rgba(255,255,255,0.72)",marginBottom:14,lineHeight:1.5,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{dream.description}</div>

                  {/* Progress */}
                  <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                    <div style={{flex:1,height:5,borderRadius:3,background:"rgba(255,255,255,0.06)",overflow:"hidden"}}>
                      <div style={{
                        height:"100%",borderRadius:3,width:`${dream.progress}%`,
                        background:dream.progress>=80?`linear-gradient(90deg,#10B981,#34D399)`:`linear-gradient(90deg,${cat.color},${cat.color}bb)`,
                        transition:"width 1.2s cubic-bezier(0.16,1,0.3,1)",
                        boxShadow:`0 0 8px ${dream.progress>=80?"rgba(16,185,129,0.3)":`${cat.color}30`}`,
                      }}/>
                    </div>
                    <span style={{fontSize:13,fontWeight:700,color:dream.progress>=80?"#5DE5A8":"rgba(255,255,255,0.85)",minWidth:36,textAlign:"right"}}>{dream.progress}%</span>
                  </div>

                  {/* Meta row */}
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                    <div style={{display:"flex",alignItems:"center",gap:14,fontSize:12,color:"rgba(255,255,255,0.7)"}}>
                      <span style={{display:"flex",alignItems:"center",gap:4}}>
                        <Target size={12} strokeWidth={2.5} /> {dream.completedGoalCount}/{dream.goalCount} goals
                      </span>
                      <span style={{display:"flex",alignItems:"center",gap:4}}>
                        <Clock size={12} strokeWidth={2.5} /> {dream.daysLeft}d left
                      </span>
                    </div>
                    <ChevronRight size={16} color="rgba(255,255,255,0.7)" />
                  </div>

                  {/* Hover action bar */}
                  <div style={{
                    position:"absolute",top:12,right:12,display:"flex",gap:6,
                    opacity:isHovered?1:0,transform:isHovered?"translateX(0)":"translateX(8px)",
                    transition:"all 0.25s cubic-bezier(0.16,1,0.3,1)",pointerEvents:isHovered?"auto":"none",
                  }}>
                    {[{I:Bot,t:"Coach"},{I:Pencil,t:"Edit"},{I:Share2,t:"Share"}].map(({I,t},j)=>(
                      <button key={j} title={t} style={{
                        width:32,height:32,borderRadius:10,border:"1px solid rgba(255,255,255,0.1)",
                        background:"rgba(255,255,255,0.08)",backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)",
                        color:"rgba(255,255,255,0.75)",display:"flex",alignItems:"center",justifyContent:"center",
                        cursor:"pointer",transition:"all 0.2s",
                      }}
                        onMouseEnter={e=>{e.currentTarget.style.background="rgba(139,92,246,0.2)";e.currentTarget.style.color="#C4B5FD";e.currentTarget.style.borderColor="rgba(139,92,246,0.3)";}}
                        onMouseLeave={e=>{e.currentTarget.style.background="rgba(255,255,255,0.08)";e.currentTarget.style.color="rgba(255,255,255,0.6)";e.currentTarget.style.borderColor="rgba(255,255,255,0.1)";}}
                        onClick={e=>e.stopPropagation()}
                      >
                        <I size={14} strokeWidth={2} />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* ═══ BOTTOM NAV ═══ */}
      <nav style={{
        position:"fixed",bottom:14,left:16,right:16,zIndex:100,
        height:68,borderRadius:24,display:"flex",alignItems:"center",justifyContent:"space-around",
        background:"rgba(255,255,255,0.04)",backdropFilter:"blur(40px) saturate(1.5)",WebkitBackdropFilter:"blur(40px) saturate(1.5)",
        border:"1px solid rgba(255,255,255,0.06)",boxShadow:"0 8px 32px rgba(0,0,0,0.3),inset 0 1px 0 rgba(255,255,255,0.04)",
      }}>
        {NAV.map((item,i)=>{
          const active=activeNav===i;
          const NIcon=item.Icon;
          return(
            <button key={i} onClick={()=>setActiveNav(i)} style={{
              display:"flex",flexDirection:"column",alignItems:"center",gap:4,
              background:"none",border:"none",cursor:"pointer",padding:"8px 18px",
              transition:"all 0.25s",
            }}>
              <div style={{
                transition:"all 0.25s cubic-bezier(0.16,1,0.3,1)",
                transform:active?"scale(1.15)":"scale(1)",
                filter:active?"drop-shadow(0 0 8px rgba(139,92,246,0.5))":"none",
              }}>
                <NIcon size={22} color={active?"#C4B5FD":"rgba(255,255,255,0.72)"} strokeWidth={active?2.5:1.8} fill={active?"rgba(167,139,250,0.1)":"none"} />
              </div>
              <span style={{fontSize:11,fontWeight:active?600:400,color:active?"#C4B5FD":"rgba(255,255,255,0.72)",transition:"all 0.25s"}}>{item.label}</span>
              <div style={{width:active?4:0,height:4,borderRadius:"50%",background:"#8B5CF6",transition:"all 0.25s",boxShadow:active?"0 0 8px rgba(139,92,246,0.6)":"none"}}/>
            </button>
          );
        })}
      </nav>

      {/* ═══ STYLES ═══ */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        *{margin:0;padding:0;box-sizing:border-box;}
        ::-webkit-scrollbar{width:0;}

        .dp-g{
          background:rgba(255,255,255,0.04);
          backdrop-filter:blur(40px) saturate(1.3);
          -webkit-backdrop-filter:blur(40px) saturate(1.3);
          border-radius:18px;
          border:1px solid rgba(255,255,255,0.06);
          box-shadow:0 4px 24px rgba(0,0,0,0.12),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s cubic-bezier(0.16,1,0.3,1);
        }
        .dp-gh:hover{
          background:rgba(255,255,255,0.07);
          border-color:rgba(255,255,255,0.1);
          box-shadow:0 8px 32px rgba(0,0,0,0.18),inset 0 1px 0 rgba(255,255,255,0.05);
          transform:translateY(-2px);
        }
        .dp-gh:active{transform:scale(0.985);}

        .dp-a{opacity:0;transform:translateY(20px);transition:opacity 0.6s cubic-bezier(0.16,1,0.3,1),transform 0.6s cubic-bezier(0.16,1,0.3,1);}
        .dp-a.dp-s{opacity:1;transform:translateY(0);}

        .dp-pulse{animation:dpPulse 2s ease-in-out infinite;}
        @keyframes dpPulse{0%,100%{opacity:1;box-shadow:0 0 6px rgba(16,185,129,0.5);}50%{opacity:0.6;box-shadow:0 0 12px rgba(16,185,129,0.3);}}

        .dp-level-bar{animation:dpLevelGrow 1.5s cubic-bezier(0.16,1,0.3,1) forwards;}
        @keyframes dpLevelGrow{from{width:0;}}

        ${NEBULAE.map((n,i)=>`
          .dp-n-${i}{animation:dpNF${i} ${n.sp}s ease-in-out infinite;}
          @keyframes dpNF${i}{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:1;}33%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1+Math.random()*0.06});opacity:${0.8+Math.random()*0.2};}66%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1-Math.random()*0.04});opacity:${0.85+Math.random()*0.15};}}
        `).join("")}
      `}</style>
    </div>
  );
}

// ─── SUB-COMPONENTS ──────────────────────────────────────────────
function StatBlock({Icon,value,label,color}){
  return(
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:5}}>
      <div style={{filter:`drop-shadow(0 0 6px ${color}40)`}}>
        <Icon size={22} color={color} strokeWidth={2.5} />
      </div>
      <span style={{fontSize:18,fontWeight:700,color:"#fff"}}>{value}</span>
      <span style={{fontSize:11,color:"rgba(255,255,255,0.7)"}}>{label}</span>
    </div>
  );
}

function Divider(){
  return <div style={{width:1,height:40,background:"rgba(255,255,255,0.06)"}}/>;
}
