import { useState, useEffect, useRef, useCallback } from "react";
import {
  ArrowLeft, User, Mail, Lock, Sun, Moon, Monitor,
  Globe, Clock, Bell, Calendar, Crown, ShoppingBag,
  Info, FileText, Shield, LogOut, Trash2, X, Check,
  ChevronRight, AlertTriangle, BellOff, BellRing
} from "lucide-react";

/* ═══════════════════════════════════════════════════════════════════
 * DreamPlanner — Settings Screen v1
 *
 * Sections: Account, Appearance, Preferences, Subscription, About
 * Interactive: theme picker, language selector, notification toggles,
 *              delete account confirmation with "DELETE" typing
 * ═══════════════════════════════════════════════════════════════════ */

const USER = { name:"Stephane", email:"stephane@rhematek.com", subscription:"PRO", timezone:"America/Toronto" };

const LANGUAGES = [
  {code:"en",label:"English"},{code:"fr",label:"Français"},{code:"es",label:"Español"},
  {code:"de",label:"Deutsch"},{code:"it",label:"Italiano"},{code:"pt",label:"Português"},
  {code:"nl",label:"Nederlands"},{code:"ru",label:"Русский"},{code:"zh",label:"中文"},
  {code:"ja",label:"日本語"},{code:"ko",label:"한국어"},{code:"ar",label:"العربية"},
];

// ─── COSMIC BG ───
const STAR_LAYERS=[{count:300,sizeRange:[0.3,1.0],opacity:0.35,parallax:0.008},{count:200,sizeRange:[0.8,1.8],opacity:0.55,parallax:0.02},{count:100,sizeRange:[1.2,2.8],opacity:0.85,parallax:0.045}];
const STAR_COLORS=[[230,225,255],[200,210,255],[255,220,200],[180,200,255],[255,200,220],[220,240,255],[255,240,230]];
const SMOKE_CYCLE=[[255,120,160],[255,80,180],[220,60,220],[180,70,255],[130,80,255],[80,100,255],[60,140,255],[80,180,240],[100,200,220],[160,120,255],[220,100,200],[255,120,160]];
const SMOKE_CONFIGS=[{size:350,opacity:0.09,speedMult:1.0,colorSpeed:0.015,colorOffset:0,pfx:[0.13,0.31],pfy:[0.17,0.23],pax:[0.38,0.12],pay:[0.35,0.10]},{size:300,opacity:0.07,speedMult:1.3,colorSpeed:0.02,colorOffset:3,pfx:[0.19,0.41],pfy:[0.23,0.29],pax:[0.35,0.15],pay:[0.32,0.08]},{size:250,opacity:0.06,speedMult:1.7,colorSpeed:0.025,colorOffset:6,pfx:[0.29,0.53],pfy:[0.31,0.37],pax:[0.33,0.18],pay:[0.30,0.12]},{size:420,opacity:0.05,speedMult:0.6,colorSpeed:0.01,colorOffset:9,pfx:[0.07,0.19],pfy:[0.11,0.17],pax:[0.40,0.10],pay:[0.38,0.14]},{size:280,opacity:0.065,speedMult:1.1,colorSpeed:0.018,colorOffset:4.5,pfx:[0.17,0.37],pfy:[0.21,0.43],pax:[0.36,0.14],pay:[0.33,0.11]}];
const NEBULAE=[{x:"8%",y:"15%",c1:"rgba(80,120,255,0.06)",c2:"rgba(60,80,200,0.015)",s:500,b:90,sp:35},{x:"88%",y:"20%",c1:"rgba(100,140,255,0.05)",c2:"rgba(70,100,220,0.015)",s:450,b:85,sp:28},{x:"12%",y:"75%",c1:"rgba(140,80,220,0.06)",c2:"rgba(100,50,180,0.015)",s:430,b:80,sp:32},{x:"82%",y:"78%",c1:"rgba(120,70,200,0.05)",c2:"rgba(90,40,170,0.015)",s:410,b:85,sp:26},{x:"50%",y:"92%",c1:"rgba(60,100,200,0.04)",c2:"rgba(40,70,160,0.01)",s:550,b:100,sp:40},{x:"50%",y:"5%",c1:"rgba(90,60,180,0.04)",c2:"rgba(70,40,150,0.01)",s:500,b:90,sp:22}];
function lerp(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}function smokeCol(t){const l=SMOKE_CYCLE.length,i=t%l,f=Math.floor(i);return lerp(SMOKE_CYCLE[f%l],SMOKE_CYCLE[(f+1)%l],i-f);}function mkStars(layer,w,h){const s=[];for(let i=0;i<layer.count;i++)s.push({x:Math.random()*w,y:Math.random()*h,sz:layer.sizeRange[0]+Math.random()*(layer.sizeRange[1]-layer.sizeRange[0]),op:layer.opacity*(0.4+Math.random()*0.6),ts:0.3+Math.random()*2.5,to:Math.random()*Math.PI*2,c:STAR_COLORS[Math.floor(Math.random()*STAR_COLORS.length)]});return s;}function mkShoot(w,h){const e=Math.floor(Math.random()*3);let x,y,a;if(e===0){x=Math.random()*w;y=-20;a=Math.PI*0.3+Math.random()*Math.PI*0.4;}else if(e===1){x=-20;y=Math.random()*h*0.6;a=Math.PI*0.05+Math.random()*Math.PI*0.3;}else{x=w*0.5+Math.random()*w*0.5;y=-20;a=Math.PI*0.4+Math.random()*Math.PI*0.3;}const sp=5+Math.random()*8;return{x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,ln:80+Math.random()*140,life:1,dc:0.005+Math.random()*0.01,sz:0.8+Math.random()*1.8,w:Math.random()};}

// ═══════════════════════════════════════════════════════════════════
export default function SettingsScreen(){
  const[mounted,setMounted]=useState(false);
  const[theme,setTheme]=useState("dark");
  const[lang,setLang]=useState("fr");
  const[notifs,setNotifs]=useState({push:true,email:true,buddy:true,streak:true});
  const[showLang,setShowLang]=useState(false);
  const[showDelete,setShowDelete]=useState(false);
  const[deleteText,setDeleteText]=useState("");
  const scRef=useRef(null);const mkRef=useRef(null);
  const stRef=useRef([]);const shRef=useRef([]);
  const drRef=useRef({x:0,y:0,a:0});const msRef=useRef({x:0,y:0,tx:0,ty:0});
  const tRef=useRef(0);const szRef=useRef({w:0,h:0});const afRef=useRef(null);

  useEffect(()=>{setTimeout(()=>setMounted(true),100);},[]);

  // BG
  const init=useCallback((w,h)=>{stRef.current=STAR_LAYERS.map(l=>({c:l,s:mkStars(l,w*1.3,h*1.3)}));},[]);
  useEffect(()=>{const sc=scRef.current,mk=mkRef.current;if(!sc||!mk)return;const sx=sc.getContext("2d"),mx=mk.getContext("2d"),d=window.devicePixelRatio||1;const rs=()=>{const w=window.innerWidth,h=window.innerHeight;[sc,mk].forEach(c=>{c.width=w*d;c.height=h*d;c.style.width=w+"px";c.style.height=h+"px";});sx.setTransform(d,0,0,d,0,0);mx.setTransform(d,0,0,d,0,0);szRef.current={w,h};init(w,h);};rs();window.addEventListener("resize",rs);const mm=e=>{const cx=window.innerWidth/2,cy=window.innerHeight/2;msRef.current.tx=(e.clientX-cx)/cx;msRef.current.ty=(e.clientY-cy)/cy;};window.addEventListener("mousemove",mm);const go=()=>{const{w,h}=szRef.current;tRef.current+=0.016;const t=tRef.current;const dr=drRef.current;dr.a+=0.0008;dr.x=Math.sin(dr.a*0.7)*0.15+Math.sin(dr.a*1.3)*0.08;dr.y=Math.cos(dr.a*0.5)*0.12+Math.cos(dr.a*1.1)*0.06;const m=msRef.current;m.x+=(m.tx-m.x)*0.03;m.y+=(m.ty-m.y)*0.03;const mvx=dr.x+m.x*0.4,mvy=dr.y+m.y*0.4;mx.clearRect(0,0,w,h);SMOKE_CONFIGS.forEach(c=>{const st=t*c.speedMult;const px=0.5+c.pax[0]*Math.sin(st*c.pfx[0])+c.pax[1]*Math.sin(st*c.pfx[1]);const py=0.5+c.pay[0]*Math.cos(st*c.pfy[0])+c.pay[1]*Math.cos(st*c.pfy[1]);const x=px*w,y=py*h;const[r,g,b]=smokeCol(c.colorOffset+t*c.colorSpeed);const gr=mx.createRadialGradient(x,y,0,x,y,c.size);gr.addColorStop(0,`rgba(${r|0},${g|0},${b|0},${c.opacity})`);gr.addColorStop(0.3,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.6})`);gr.addColorStop(0.6,`rgba(${r|0},${g|0},${b|0},${c.opacity*0.2})`);gr.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=gr;mx.beginPath();mx.arc(x,y,c.size,0,Math.PI*2);mx.fill();const ig=mx.createRadialGradient(x,y,0,x,y,c.size*0.4);ig.addColorStop(0,`rgba(${Math.min(r+40,255)|0},${Math.min(g+30,255)|0},${Math.min(b+30,255)|0},${c.opacity*0.8})`);ig.addColorStop(1,`rgba(${r|0},${g|0},${b|0},0)`);mx.fillStyle=ig;mx.beginPath();mx.arc(x,y,c.size*0.4,0,Math.PI*2);mx.fill();});sx.clearRect(0,0,w,h);stRef.current.forEach(({c:cfg,s:stars})=>{const ox=mvx*cfg.parallax*w+(w*0.15),oy=mvy*cfg.parallax*h+(h*0.15),fw=w*1.3,fh=h*1.3;stars.forEach(s=>{const tw=Math.sin(t*s.ts+s.to)*0.35+0.65,a=s.op*tw,px=((s.x-ox)%fw+fw)%fw-w*0.15,py=((s.y-oy)%fh+fh)%fh-h*0.15;if(px<-10||px>w+10||py<-10||py>h+10)return;const[r,g,b]=s.c;if(s.sz>1.5){const gr=sx.createRadialGradient(px,py,0,px,py,s.sz*4);gr.addColorStop(0,`rgba(${r},${g},${b},${a*0.25})`);gr.addColorStop(1,`rgba(${r},${g},${b},0)`);sx.fillStyle=gr;sx.beginPath();sx.arc(px,py,s.sz*4,0,Math.PI*2);sx.fill();}if(s.sz>2.2){sx.strokeStyle=`rgba(${r},${g},${b},${a*0.15})`;sx.lineWidth=0.5;const fl=s.sz*6*tw;sx.beginPath();sx.moveTo(px-fl,py);sx.lineTo(px+fl,py);sx.moveTo(px,py-fl);sx.lineTo(px,py+fl);sx.stroke();}sx.fillStyle=`rgba(${r},${g},${b},${a})`;sx.beginPath();sx.arc(px,py,s.sz,0,Math.PI*2);sx.fill();});});if(Math.random()<0.025)shRef.current.push(mkShoot(w,h));if(Math.random()<0.003){for(let i=0;i<2+Math.floor(Math.random()*2);i++)shRef.current.push(mkShoot(w,h));}shRef.current=shRef.current.filter(s=>{s.x+=s.vx;s.y+=s.vy;s.life-=s.dc;if(s.life<=0)return false;const a=s.life*s.life,mg=Math.sqrt(s.vx*s.vx+s.vy*s.vy),dx=s.vx/mg,dy=s.vy/mg,tx=s.x-dx*s.ln*a,ty=s.y-dy*s.ln*a;const cr=s.w>0.5?255:200,cg=s.w>0.5?220:210,cb=s.w>0.5?200:255;const gr=sx.createLinearGradient(tx,ty,s.x,s.y);gr.addColorStop(0,`rgba(${cr},${cg},${cb},0)`);gr.addColorStop(0.5,`rgba(${cr},${cg},${cb},${a*0.25})`);gr.addColorStop(1,`rgba(255,255,255,${a*0.9})`);sx.strokeStyle=gr;sx.lineWidth=s.sz;sx.lineCap="round";sx.beginPath();sx.moveTo(tx,ty);sx.lineTo(s.x,s.y);sx.stroke();const hg=sx.createRadialGradient(s.x,s.y,0,s.x,s.y,5);hg.addColorStop(0,`rgba(255,255,255,${a*0.9})`);hg.addColorStop(1,`rgba(${cr},${cg},${cb},0)`);sx.fillStyle=hg;sx.beginPath();sx.arc(s.x,s.y,5,0,Math.PI*2);sx.fill();return true;});afRef.current=requestAnimationFrame(go);};afRef.current=requestAnimationFrame(go);return()=>{cancelAnimationFrame(afRef.current);window.removeEventListener("resize",rs);window.removeEventListener("mousemove",mm);};
  },[init]);

  const Toggle=({on,onToggle})=>(
    <button onClick={onToggle} style={{width:44,height:26,borderRadius:13,padding:2,border:"none",cursor:"pointer",background:on?"rgba(93,229,168,0.3)":"rgba(255,255,255,0.08)",transition:"all 0.25s cubic-bezier(0.16,1,0.3,1)"}}>
      <div style={{width:22,height:22,borderRadius:11,background:on?"#5DE5A8":"rgba(255,255,255,0.3)",transform:on?"translateX(18px)":"translateX(0)",transition:"all 0.25s cubic-bezier(0.16,1,0.3,1)",boxShadow:on?"0 0 8px rgba(93,229,168,0.4)":"none"}}/>
    </button>
  );

  const Tile=({icon:I,title,sub,right,onClick,color="#C4B5FD"})=>(
    <div className="dp-g dp-gh" onClick={onClick} style={{padding:"12px 16px",marginBottom:6,cursor:onClick?"pointer":"default",display:"flex",alignItems:"center",gap:14}}>
      <div style={{width:36,height:36,borderRadius:12,background:`${color}10`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
        <I size={17} color={color} strokeWidth={2}/>
      </div>
      <div style={{flex:1,minWidth:0}}>
        <div style={{fontSize:14,fontWeight:500,color:"#fff"}}>{title}</div>
        {sub&&<div style={{fontSize:12,color:"rgba(255,255,255,0.5)",marginTop:1}}>{sub}</div>}
      </div>
      {right||<ChevronRight size={16} color="rgba(255,255,255,0.3)" strokeWidth={2}/>}
    </div>
  );

  const Section=({title,delay,children})=>(
    <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:`${delay}ms`}}>
      <div style={{fontSize:12,fontWeight:700,color:"rgba(255,255,255,0.5)",textTransform:"uppercase",letterSpacing:"0.8px",marginBottom:8,paddingLeft:4}}>{title}</div>
      {children}
      <div style={{height:12}}/>
    </div>
  );

  const langLabel=LANGUAGES.find(l=>l.code===lang)?.label||"English";

  return(
    <div style={{width:"100%",height:"100vh",overflow:"hidden",fontFamily:"'Inter',-apple-system,BlinkMacSystemFont,sans-serif",display:"flex",flexDirection:"column",position:"relative"}}>
      <div style={{position:"fixed",inset:0,background:"radial-gradient(ellipse at 50% 50%,#0c081a 0%,#070412 35%,#03010a 70%,#000005 100%)",zIndex:0}}>
        {NEBULAE.map((n,i)=><div key={i} className={`dp-n-${i}`} style={{position:"absolute",left:n.x,top:n.y,width:n.s,height:n.s,transform:"translate(-50%,-50%)",background:`radial-gradient(circle,${n.c1} 0%,${n.c2} 40%,transparent 70%)`,filter:`blur(${n.b}px)`,pointerEvents:"none"}}/>)}
        <canvas ref={mkRef} style={{position:"absolute",inset:0,pointerEvents:"none",mixBlendMode:"screen"}}/>
        <canvas ref={scRef} style={{position:"absolute",inset:0,pointerEvents:"none"}}/>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at center,transparent 30%,rgba(3,1,10,0.5) 70%,rgba(0,0,5,0.8) 100%)",pointerEvents:"none"}}/>
      </div>

      <header style={{position:"relative",zIndex:100,height:64,flexShrink:0,display:"flex",alignItems:"center",padding:"0 16px",gap:10,background:"rgba(255,255,255,0.03)",backdropFilter:"blur(40px) saturate(1.4)",WebkitBackdropFilter:"blur(40px) saturate(1.4)",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
        <button className="dp-ib"><ArrowLeft size={20} strokeWidth={2}/></button>
        <span style={{fontSize:17,fontWeight:700,color:"#fff",letterSpacing:"-0.3px"}}>Settings</span>
      </header>

      <main style={{flex:1,overflowY:"auto",overflowX:"hidden",zIndex:10,padding:"20px 16px 32px"}}>
        <div style={{maxWidth:480,margin:"0 auto"}}>

          <Section title="Account" delay={0}>
            <Tile icon={User} title="Edit Profile" sub={USER.name}/>
            <Tile icon={Mail} title="Email" sub={USER.email}/>
            <Tile icon={Lock} title="Change Password"/>
          </Section>

          <Section title="Appearance" delay={100}>
            <div className="dp-g" style={{padding:14,marginBottom:6}}>
              <div style={{fontSize:14,fontWeight:500,color:"#fff",marginBottom:12}}>Theme</div>
              <div style={{display:"flex",gap:8}}>
                {[
                  {id:"dark",Icon:Moon,label:"Dark"},
                  {id:"light",Icon:Sun,label:"Light"},
                  {id:"system",Icon:Monitor,label:"System"},
                ].map(t=>(
                  <button key={t.id} onClick={()=>setTheme(t.id)} style={{
                    flex:1,padding:"12px 8px",borderRadius:14,border:theme===t.id?"1px solid rgba(139,92,246,0.3)":"1px solid rgba(255,255,255,0.06)",
                    background:theme===t.id?"rgba(139,92,246,0.1)":"rgba(255,255,255,0.02)",
                    display:"flex",flexDirection:"column",alignItems:"center",gap:6,cursor:"pointer",transition:"all 0.2s",
                  }}>
                    <t.Icon size={20} color={theme===t.id?"#C4B5FD":"rgba(255,255,255,0.5)"} strokeWidth={2}/>
                    <span style={{fontSize:12,fontWeight:theme===t.id?600:400,color:theme===t.id?"#C4B5FD":"rgba(255,255,255,0.7)"}}>{t.label}</span>
                    {theme===t.id&&<div style={{width:6,height:6,borderRadius:3,background:"#C4B5FD",boxShadow:"0 0 6px rgba(196,181,253,0.5)"}}/>}
                  </button>
                ))}
              </div>
            </div>
          </Section>

          <Section title="Preferences" delay={200}>
            <Tile icon={Globe} title="Language" sub={langLabel} onClick={()=>setShowLang(true)}/>
            <Tile icon={Clock} title="Timezone" sub={USER.timezone}/>
            <Tile icon={BellRing} title="Push Notifications" right={<Toggle on={notifs.push} onToggle={()=>setNotifs(p=>({...p,push:!p.push}))}/>}/>
            <Tile icon={Mail} title="Email Notifications" right={<Toggle on={notifs.email} onToggle={()=>setNotifs(p=>({...p,email:!p.email}))}/>}/>
            <Tile icon={User} title="Buddy Reminders" right={<Toggle on={notifs.buddy} onToggle={()=>setNotifs(p=>({...p,buddy:!p.buddy}))}/>} color="#5EEAD4"/>
            <Tile icon={Calendar} title="Google Calendar" sub="Sync your events" color="#93C5FD"/>
          </Section>

          <Section title="Subscription" delay={300}>
            <Tile icon={Crown} title="Manage Subscription" sub={USER.subscription} color="#FCD34D"/>
            <Tile icon={ShoppingBag} title="Store" color="#5EEAD4"/>
          </Section>

          <Section title="About" delay={400}>
            <Tile icon={Info} title="App Version" sub="1.0.0" color="rgba(255,255,255,0.7)"/>
            <Tile icon={FileText} title="Terms of Service" color="rgba(255,255,255,0.7)"/>
            <Tile icon={Shield} title="Privacy Policy" color="rgba(255,255,255,0.7)"/>
          </Section>

          <div className={`dp-a ${mounted?"dp-s":""}`} style={{animationDelay:"500ms"}}>
            <button style={{width:"100%",padding:"14px 0",borderRadius:16,border:"1px solid rgba(246,154,154,0.15)",background:"rgba(246,154,154,0.06)",color:"#F69A9A",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:8,transition:"all 0.2s",marginBottom:10}}
              onMouseEnter={e=>e.currentTarget.style.background="rgba(246,154,154,0.12)"}
              onMouseLeave={e=>e.currentTarget.style.background="rgba(246,154,154,0.06)"}>
              <LogOut size={16} strokeWidth={2}/>Sign Out
            </button>
            <button onClick={()=>{setShowDelete(true);setDeleteText("");}} style={{width:"100%",padding:"14px 0",borderRadius:16,border:"1px solid rgba(239,68,68,0.15)",background:"rgba(239,68,68,0.04)",color:"rgba(239,68,68,0.8)",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:8,transition:"all 0.2s"}}
              onMouseEnter={e=>e.currentTarget.style.background="rgba(239,68,68,0.1)"}
              onMouseLeave={e=>e.currentTarget.style.background="rgba(239,68,68,0.04)"}>
              <Trash2 size={16} strokeWidth={2}/>Delete Account
            </button>
          </div>

        </div>
      </main>

      {/* ═══ LANGUAGE PICKER ═══ */}
      {showLang&&(
        <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",alignItems:"flex-end",justifyContent:"center"}}>
          <div onClick={()=>setShowLang(false)} style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.5)",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)"}}/>
          <div style={{position:"relative",width:"100%",maxWidth:420,maxHeight:"70vh",background:"rgba(12,8,26,0.97)",backdropFilter:"blur(40px)",WebkitBackdropFilter:"blur(40px)",borderRadius:"22px 22px 0 0",border:"1px solid rgba(255,255,255,0.08)",borderBottom:"none",animation:"dpSlideUp 0.3s cubic-bezier(0.16,1,0.3,1)",display:"flex",flexDirection:"column"}}>
            <div style={{padding:"16px 20px",borderBottom:"1px solid rgba(255,255,255,0.06)",display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
              <span style={{fontSize:16,fontWeight:600,color:"#fff"}}>Choose Language</span>
              <button className="dp-ib" style={{width:32,height:32}} onClick={()=>setShowLang(false)}><X size={16} strokeWidth={2}/></button>
            </div>
            <div style={{flex:1,overflowY:"auto",padding:"8px 12px 20px"}}>
              {LANGUAGES.map(l=>(
                <button key={l.code} onClick={()=>{setLang(l.code);setShowLang(false);}} style={{
                  width:"100%",padding:"12px 16px",borderRadius:12,border:"none",marginBottom:4,
                  background:lang===l.code?"rgba(139,92,246,0.1)":"transparent",
                  display:"flex",alignItems:"center",justifyContent:"space-between",cursor:"pointer",
                  transition:"all 0.15s",fontFamily:"inherit",
                }}
                  onMouseEnter={e=>{if(lang!==l.code)e.currentTarget.style.background="rgba(255,255,255,0.04)";}}
                  onMouseLeave={e=>{if(lang!==l.code)e.currentTarget.style.background="transparent";}}>
                  <span style={{fontSize:14,fontWeight:lang===l.code?600:400,color:lang===l.code?"#C4B5FD":"rgba(255,255,255,0.85)"}}>{l.label}</span>
                  {lang===l.code&&<Check size={16} color="#C4B5FD" strokeWidth={2.5}/>}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ═══ DELETE ACCOUNT DIALOG ═══ */}
      {showDelete&&(
        <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div onClick={()=>setShowDelete(false)} style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.6)",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)"}}/>
          <div style={{position:"relative",width:"90%",maxWidth:380,background:"rgba(12,8,26,0.97)",backdropFilter:"blur(40px)",WebkitBackdropFilter:"blur(40px)",borderRadius:22,border:"1px solid rgba(239,68,68,0.15)",boxShadow:"0 20px 60px rgba(0,0,0,0.5)",padding:24,animation:"dpFS 0.25s ease-out"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14}}>
              <div style={{width:40,height:40,borderRadius:12,background:"rgba(239,68,68,0.1)",display:"flex",alignItems:"center",justifyContent:"center"}}>
                <AlertTriangle size={20} color="rgba(239,68,68,0.8)" strokeWidth={2}/>
              </div>
              <div>
                <div style={{fontSize:16,fontWeight:600,color:"#fff"}}>Delete Account</div>
                <div style={{fontSize:12,color:"rgba(255,255,255,0.5)"}}>This cannot be undone</div>
              </div>
            </div>
            <div style={{fontSize:13,color:"rgba(255,255,255,0.7)",lineHeight:1.5,marginBottom:16}}>
              This will permanently delete your account, all dreams, progress, and data. Type <strong style={{color:"rgba(239,68,68,0.9)"}}>DELETE</strong> to confirm.
            </div>
            <input value={deleteText} onChange={e=>setDeleteText(e.target.value)} placeholder="Type DELETE"
              style={{width:"100%",padding:"10px 14px",borderRadius:12,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.06)",color:"#fff",fontSize:14,fontFamily:"inherit",outline:"none",marginBottom:14}}/>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>setShowDelete(false)} style={{flex:1,padding:"12px",borderRadius:12,border:"1px solid rgba(255,255,255,0.08)",background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.85)",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>Cancel</button>
              <button disabled={deleteText!=="DELETE"} style={{flex:1,padding:"12px",borderRadius:12,border:"none",background:deleteText==="DELETE"?"rgba(239,68,68,0.2)":"rgba(255,255,255,0.03)",color:deleteText==="DELETE"?"rgba(239,68,68,0.9)":"rgba(255,255,255,0.2)",fontSize:14,fontWeight:600,cursor:deleteText==="DELETE"?"pointer":"not-allowed",fontFamily:"inherit",transition:"all 0.2s"}}>Delete Forever</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        *{margin:0;padding:0;box-sizing:border-box;}::-webkit-scrollbar{width:0;}
        input::placeholder{color:rgba(255,255,255,0.35);}
        .dp-ib{width:40px;height:40px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.05);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;}
        .dp-ib:hover{background:rgba(255,255,255,0.1);}
        .dp-g{background:rgba(255,255,255,0.04);backdrop-filter:blur(40px) saturate(1.3);-webkit-backdrop-filter:blur(40px) saturate(1.3);border-radius:18px;border:1px solid rgba(255,255,255,0.06);box-shadow:0 4px 24px rgba(0,0,0,0.12),inset 0 1px 0 rgba(255,255,255,0.03);transition:all 0.3s cubic-bezier(0.16,1,0.3,1);}
        .dp-gh:hover{background:rgba(255,255,255,0.07);border-color:rgba(255,255,255,0.1);transform:translateY(-1px);}
        .dp-a{opacity:0;transform:translateY(16px);transition:opacity 0.5s cubic-bezier(0.16,1,0.3,1),transform 0.5s cubic-bezier(0.16,1,0.3,1);}
        .dp-a.dp-s{opacity:1;transform:translateY(0);}
        @keyframes dpFS{from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);}}
        @keyframes dpSlideUp{from{transform:translateY(100%);}to{transform:translateY(0);}}
        ${NEBULAE.map((n,i)=>`
          .dp-n-${i}{animation:dpNF${i} ${n.sp}s ease-in-out infinite;}
          @keyframes dpNF${i}{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:1;}33%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1+Math.random()*0.06});opacity:${0.8+Math.random()*0.2};}66%{transform:translate(calc(-50% + ${(Math.random()-0.5)*10}px),calc(-50% + ${(Math.random()-0.5)*10}px)) scale(${1-Math.random()*0.04});opacity:${0.85+Math.random()*0.15};}}
        `).join("")}
      `}</style>
    </div>
  );
}
